package com.pictionary;

import javax.websocket.Session;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class GameManager {

    private static final String ADMIN_PASSWORD = "admin123";
    private static final Map<String, RoomState> ROOMS = new ConcurrentHashMap<>();
    private static final Map<Session, String> USERNAMES = new ConcurrentHashMap<>();
    private static final Map<Session, String> USER_ROOMS = new ConcurrentHashMap<>();
    private static final ScheduledExecutorService SCHEDULER = Executors.newSingleThreadScheduledExecutor();
    private static final List<String> WORDS = Arrays.asList(
        "rocket", "apple", "bridge", "planet", "guitar", "camera", "satellite", "cricket",
        "pencil", "sunflower", "rainbow", "elephant", "mountain", "notebook", "spaceship",
        "bicycle", "umbrella", "volcano", "telescope", "library", "train", "waterfall",
        "butterfly", "castle", "keyboard", "helicopter", "compass", "pizza", "snowman",
        "ice cream", "traffic light", "hot air balloon", "fire truck", "coffee mug"
    );
    private static final Random RANDOM = new Random();
    private static final int MAX_GUESS_POINTS = 100;
    private static final int MIN_GUESS_POINTS = 50;
    private static final int PICK_SECONDS = 15;

    private GameManager() {
    }

    public static void connect(String username, Session session) {
        USERNAMES.put(session, username);
        send(session, "WELCOME::" + username);
        sendRoomList(session);
    }

    public static void disconnect(Session session) {
        String roomCode = USER_ROOMS.remove(session);
        String username = USERNAMES.remove(session);

        if (roomCode == null || username == null) {
            return;
        }

        RoomState room = ROOMS.get(roomCode);
        if (room == null) {
            return;
        }

        synchronized (room) {
            room.getPlayers().remove(username);
            addStatus(room, username + " left the room.");
            if (room.getPlayers().isEmpty()) {
                ROOMS.remove(roomCode);
            } else {
                reassignHostIfNeeded(room, username);
                if (username.equals(room.getDrawerUsername())) {
                    endRound(room, "Drawer left. Round ended.");
                }
                broadcastRoom(room);
            }
        }

        broadcastPublicRoomList();
    }

    public static void sendRoomList(Session session) {
        send(session, "ROOM_LIST::" + buildRoomList());
    }

    public static void createRoom(Session session, String name, String visibility, String password, String maxPlayers, String totalRounds, String roundSeconds) {
        String username = USERNAMES.get(session);
        if (username == null) {
            return;
        }

        String cleanName = sanitize(name);
        boolean isPublic = "PUBLIC".equalsIgnoreCase(visibility);
        String cleanPassword = sanitize(password);
        int limit = parseMaxPlayers(maxPlayers);
        int rounds = parseTotalRounds(totalRounds);
        int seconds = parseRoundSeconds(roundSeconds);

        if (cleanName.isEmpty()) {
            send(session, "ERROR::Room name is required.");
            return;
        }

        String roomCode = generateCode();
        RoomState room = new RoomState(roomCode, cleanName, isPublic, cleanPassword, limit, rounds, seconds, username);
        room.getPlayers().put(username, new PlayerState(username, session));
        addStatus(room, "Room created by " + username + ". " + rounds + " rounds, " + seconds + " seconds per round.");
        ROOMS.put(roomCode, room);
        USER_ROOMS.put(session, roomCode);

        send(session, "ROOM_JOINED::" + roomCode);
        broadcastRoom(room);
        broadcastPublicRoomList();
    }

    public static void joinRoom(Session session, String roomCode, String password) {
        String username = USERNAMES.get(session);
        if (username == null) {
            return;
        }

        RoomState room = ROOMS.get(sanitize(roomCode).toUpperCase());
        if (room == null) {
            send(session, "ERROR::Room not found.");
            return;
        }

        synchronized (room) {
            if (!room.getPassword().isEmpty() && !room.getPassword().equals(sanitize(password))) {
                send(session, "ERROR::Wrong room password.");
                return;
            }

            if (room.getPlayers().containsKey(username)) {
                room.getPlayers().get(username).setSession(session);
            } else {
                if (room.getPlayers().size() >= room.getMaxPlayers()) {
                    send(session, "ERROR::Room is full.");
                    return;
                }
                room.getPlayers().put(username, new PlayerState(username, session));
                addStatus(room, username + " joined the room.");
                if (!"lobby".equals(room.getStatus()) && !"finished".equals(room.getStatus())) {
                    addStatus(room, username + " will join the active draw order from the next round.");
                }
            }
        }

        USER_ROOMS.put(session, room.getCode());
        send(session, "ROOM_JOINED::" + room.getCode());
        broadcastRoom(room);
        broadcastPublicRoomList();
    }

    public static void leaveRoom(Session session) {
        String roomCode = USER_ROOMS.remove(session);
        String username = USERNAMES.get(session);

        if (roomCode == null || username == null) {
            return;
        }

        RoomState room = ROOMS.get(roomCode);
        if (room == null) {
            return;
        }

        synchronized (room) {
            room.getPlayers().remove(username);
            addStatus(room, username + " left the room.");
            if (room.getPlayers().isEmpty()) {
                ROOMS.remove(roomCode);
            } else {
                reassignHostIfNeeded(room, username);
                if (username.equals(room.getDrawerUsername())) {
                    endRound(room, "Drawer left. Round ended.");
                }
                broadcastRoom(room);
            }
        }

        send(session, "LEFT_ROOM");
        sendRoomList(session);
        broadcastPublicRoomList();
    }

    public static void startGame(Session session) {
        RoomState room = getRoomFor(session);
        String username = USERNAMES.get(session);

        if (room == null || username == null) {
            return;
        }

        synchronized (room) {
            if (!room.getHostUsername().equals(username)) {
                send(session, "ERROR::Only the host can start the game.");
                return;
            }

            if (!"lobby".equals(room.getStatus()) && !"finished".equals(room.getStatus())) {
                send(session, "ERROR::A game is already running.");
                return;
            }

            if (room.getPlayers().size() < 2) {
                send(session, "ERROR::Need at least 2 players to start.");
                return;
            }

            resetScores(room);
            room.setRoundNumber(0);
            room.setTurnNumber(0);
            room.setDrawerIndex(-1);
            addStatus(room, username + " started the game.");
            prepareNextRound(room);
        }
    }

    public static void updateRoomSettings(Session session, String totalRounds, String roundSeconds) {
        RoomState room = getRoomFor(session);
        String username = USERNAMES.get(session);

        if (room == null || username == null) {
            return;
        }

        synchronized (room) {
            if (!room.getHostUsername().equals(username)) {
                send(session, "ERROR::Only the host can change room settings.");
                return;
            }

            if (!"lobby".equals(room.getStatus()) && !"finished".equals(room.getStatus())) {
                send(session, "ERROR::Settings can be changed before a game starts or after it finishes.");
                return;
            }

            room.setTotalRounds(parseTotalRounds(totalRounds));
            room.setRoundSeconds(parseRoundSeconds(roundSeconds));
            addStatus(room, username + " updated the room settings to " + room.getTotalRounds() + " rounds and " + room.getRoundSeconds() + " seconds per round.");
            broadcastRoom(room);
            broadcastPublicRoomList();
        }
    }

    public static void pickWord(Session session, String word) {
        RoomState room = getRoomFor(session);
        String username = USERNAMES.get(session);

        if (room == null || username == null) {
            return;
        }

        synchronized (room) {
            if (!"picking".equals(room.getStatus()) || !username.equals(room.getDrawerUsername())) {
                return;
            }

            String cleanWord = sanitize(word).toLowerCase();
            if (!room.getWordChoices().contains(cleanWord)) {
                send(session, "ERROR::Choose one of the offered words.");
                return;
            }

            beginDrawingRound(room, cleanWord);
        }
    }

    public static void handleChat(Session session, String text) {
        RoomState room = getRoomFor(session);
        String username = USERNAMES.get(session);

        if (room == null || username == null) {
            return;
        }

        String cleanText = sanitize(text);
        if (cleanText.isEmpty()) {
            return;
        }

        synchronized (room) {
            PlayerState player = room.getPlayers().get(username);
            if ("playing".equals(room.getStatus())
                && !username.equals(room.getDrawerUsername())
                && room.getActiveRoundPlayers().contains(username)
                && !player.hasGuessedCorrectly()
                && cleanText.equalsIgnoreCase(room.getWord())) {

                int guessScore = calculateGuessScore(room);
                player.addScore(guessScore);
                PlayerState drawer = room.getPlayers().get(room.getDrawerUsername());
                if (drawer != null) {
                    drawer.addScore(MAX_GUESS_POINTS);
                }

                player.setGuessedCorrectly(true);
                addStatus(room, username + " guessed the word for " + guessScore + " points.");
                broadcastRoom(room);

                if (allGuessersDone(room)) {
                    endRound(room, "Everyone guessed the word.");
                }
                return;
            }

            room.getChatLog().add("CHAT::" + username + "::" + now() + "::" + cleanText);
            broadcastRoom(room);
            if ("playing".equals(room.getStatus())
                && !username.equals(room.getDrawerUsername())
                && room.getActiveRoundPlayers().contains(username)
                && !player.hasGuessedCorrectly()
                && isCloseGuess(cleanText, room.getWord())) {
                send(session, "PRIVATE_HINT::You are close!");
            }
        }
    }

    public static void kickPlayer(Session session, String targetUsername) {
        RoomState room = getRoomFor(session);
        String username = USERNAMES.get(session);
        String target = sanitize(targetUsername);

        if (room == null || username == null || target.isEmpty()) {
            return;
        }

        synchronized (room) {
            if (!room.getHostUsername().equals(username)) {
                send(session, "ERROR::Only the host can kick players.");
                return;
            }

            if (room.getHostUsername().equals(target)) {
                send(session, "ERROR::Host cannot kick themselves.");
                return;
            }

            removePlayerFromRoom(room, target, "Kicked by host.");
        }
    }

    public static void handleDraw(Session session, String payload) {
        RoomState room = getRoomFor(session);
        String username = USERNAMES.get(session);

        if (room == null || username == null) {
            return;
        }

        synchronized (room) {
            if (!"playing".equals(room.getStatus()) || !username.equals(room.getDrawerUsername())) {
                return;
            }

            room.getStrokes().add(payload);
            room.getRedoStrokes().clear();
            broadcastToRoom(room, "DRAW::" + payload);
        }
    }

    public static void clearCanvas(Session session) {
        RoomState room = getRoomFor(session);
        String username = USERNAMES.get(session);

        if (room == null || username == null) {
            return;
        }

        synchronized (room) {
            if (!username.equals(room.getDrawerUsername())) {
                return;
            }

            room.getStrokes().clear();
            room.getRedoStrokes().clear();
            broadcastToRoom(room, "CANVAS_CLEAR");
        }
    }

    public static void undoDraw(Session session) {
        RoomState room = getRoomFor(session);
        String username = USERNAMES.get(session);

        if (room == null || username == null) {
            return;
        }

        synchronized (room) {
            if (!"playing".equals(room.getStatus()) || !username.equals(room.getDrawerUsername()) || room.getStrokes().isEmpty()) {
                return;
            }

            String groupId = drawingGroupId(room.getStrokes().get(room.getStrokes().size() - 1));
            List<String> undone = new ArrayList<>();
            while (!room.getStrokes().isEmpty()) {
                String stroke = room.getStrokes().get(room.getStrokes().size() - 1);
                if (!drawingGroupId(stroke).equals(groupId)) {
                    break;
                }
                undone.add(0, room.getStrokes().remove(room.getStrokes().size() - 1));
            }
            room.getRedoStrokes().addAll(undone);
            broadcastRoom(room);
        }
    }

    public static void redoDraw(Session session) {
        RoomState room = getRoomFor(session);
        String username = USERNAMES.get(session);

        if (room == null || username == null) {
            return;
        }

        synchronized (room) {
            if (!"playing".equals(room.getStatus()) || !username.equals(room.getDrawerUsername()) || room.getRedoStrokes().isEmpty()) {
                return;
            }

            String groupId = drawingGroupId(room.getRedoStrokes().get(room.getRedoStrokes().size() - 1));
            List<String> redone = new ArrayList<>();
            while (!room.getRedoStrokes().isEmpty()) {
                String stroke = room.getRedoStrokes().get(room.getRedoStrokes().size() - 1);
                if (!drawingGroupId(stroke).equals(groupId)) {
                    break;
                }
                redone.add(0, room.getRedoStrokes().remove(room.getRedoStrokes().size() - 1));
            }
            room.getStrokes().addAll(redone);
            broadcastRoom(room);
        }
    }

    private static void prepareNextRound(RoomState room) {
        List<String> usernames = new ArrayList<>(room.getPlayers().keySet());
        if (usernames.size() < 2) {
            finishGame(room, "Game stopped because fewer than 2 players remain.");
            return;
        }

        int nextDrawerIndex = (room.getDrawerIndex() + 1) % usernames.size();
        boolean startsNewCycle = nextDrawerIndex == 0;
        if (startsNewCycle && room.getRoundNumber() >= room.getTotalRounds()) {
            finishGame(room, "All rounds are complete.");
            return;
        }

        room.bumpRoundVersion();
        room.setStatus("picking");
        if (startsNewCycle) {
            room.setRoundNumber(room.getRoundNumber() + 1);
        }
        room.setTurnNumber(room.getTurnNumber() + 1);
        room.setDrawerIndex(nextDrawerIndex);
        room.setDrawerUsername(usernames.get(room.getDrawerIndex()));
        room.setWord("");
        room.setRoundEndsAt(0L);
        room.setPickEndsAt(now() + (PICK_SECONDS * 1000L));
        room.getStrokes().clear();
        room.getRedoStrokes().clear();
        room.getWordChoices().clear();
        room.getRevealedLetterIndexes().clear();
        room.getWordChoices().addAll(randomWords(3));
        room.getActiveRoundPlayers().clear();
        room.getActiveRoundPlayers().addAll(usernames);
        addStatus(room, "Round " + room.getRoundNumber() + " of " + room.getTotalRounds() + ", turn " + (room.getDrawerIndex() + 1) + " of " + usernames.size() + ": " + room.getDrawerUsername() + " is choosing a word.");

        for (PlayerState player : room.getPlayers().values()) {
            player.setGuessedCorrectly(false);
        }

        long version = room.getRoundVersion();
        broadcastRoom(room);
        broadcastToRoom(room, "CANVAS_CLEAR");

        SCHEDULER.schedule(() -> {
            synchronized (room) {
                if (room.getRoundVersion() != version || !"picking".equals(room.getStatus())) {
                    return;
                }
                beginDrawingRound(room, room.getWordChoices().isEmpty() ? WORDS.get(RANDOM.nextInt(WORDS.size())) : room.getWordChoices().get(0));
            }
        }, PICK_SECONDS, TimeUnit.SECONDS);
    }

    private static void beginDrawingRound(RoomState room, String word) {
        room.bumpRoundVersion();
        room.setStatus("playing");
        room.setWord(word);
        room.setPickEndsAt(0L);
        room.setRoundEndsAt(now() + (room.getRoundSeconds() * 1000L));
        room.getWordChoices().clear();
        room.getStrokes().clear();
        room.getRedoStrokes().clear();
        room.getRevealedLetterIndexes().clear();
        addStatus(room, "Round " + room.getRoundNumber() + " started. " + room.getDrawerUsername() + " is drawing.");

        long version = room.getRoundVersion();
        broadcastRoom(room);
        broadcastToRoom(room, "CANVAS_CLEAR");
        scheduleLetterReveals(room, version);

        SCHEDULER.schedule(() -> {
            synchronized (room) {
                if (room.getRoundVersion() != version || !"playing".equals(room.getStatus())) {
                    return;
                }
                endRound(room, "Time is up.");
            }
        }, room.getRoundSeconds(), TimeUnit.SECONDS);
    }

    private static void endRound(RoomState room, String reason) {
        room.bumpRoundVersion();
        room.setStatus("round_end");
        addStatus(room, reason + " Word was " + room.getWord() + ".");
        broadcastRoom(room);

        long version = room.getRoundVersion();
        SCHEDULER.schedule(() -> {
            synchronized (room) {
                if (room.getRoundVersion() != version || !"round_end".equals(room.getStatus())) {
                    return;
                }
                prepareNextRound(room);
            }
        }, 4, TimeUnit.SECONDS);
    }

    private static boolean allGuessersDone(RoomState room) {
        for (PlayerState player : room.getPlayers().values()) {
            if (!room.getActiveRoundPlayers().contains(player.getUsername())) {
                continue;
            }
            if (player.getUsername().equals(room.getDrawerUsername())) {
                continue;
            }
            if (!player.hasGuessedCorrectly()) {
                return false;
            }
        }
        return true;
    }

    private static void broadcastRoom(RoomState room) {
        for (PlayerState player : room.getPlayers().values()) {
            Session session = player.getSession();
            if (session != null && session.isOpen()) {
                send(session, buildRoomState(room, player.getUsername()));
            }
        }
    }

    private static void broadcastPublicRoomList() {
        String payload = "ROOM_LIST::" + buildRoomList();
        for (Session session : USERNAMES.keySet()) {
            send(session, payload);
        }
    }

    private static void broadcastToRoom(RoomState room, String payload) {
        for (PlayerState player : room.getPlayers().values()) {
            send(player.getSession(), payload);
        }
    }

    private static String buildRoomList() {
        List<String> items = new ArrayList<>();

        for (RoomState room : ROOMS.values()) {
            if (!room.isPublic()) {
                continue;
            }
            items.add(escape(room.getCode()) + "|" + escape(room.getName()) + "|" + room.getPlayers().size() + "|" + escape(room.getStatus()));
        }

        return String.join(",", items);
    }

    private static String buildRoomState(RoomState room, String viewerUsername) {
        StringBuilder players = new StringBuilder();
        for (PlayerState player : room.getPlayers().values()) {
            if (players.length() > 0) {
                players.append(",");
            }
            players.append(escape(player.getUsername()))
                .append("|")
                .append(player.getScore())
                .append("|")
                .append(player.getUsername().equals(room.getDrawerUsername()) ? "drawer" : "player")
                .append("|")
                .append(getPlayerRoundState(room, player));
        }

        StringBuilder chat = new StringBuilder();
        for (String item : room.getChatLog()) {
            if (chat.length() > 0) {
                chat.append(",");
            }
            chat.append(Base64.getEncoder().encodeToString(item.getBytes(StandardCharsets.UTF_8)));
        }

        StringBuilder strokes = new StringBuilder();
        for (String item : room.getStrokes()) {
            if (strokes.length() > 0) {
                strokes.append(",");
            }
            strokes.append(item);
        }

        StringBuilder choices = new StringBuilder();
        if ("picking".equals(room.getStatus()) && viewerUsername.equals(room.getDrawerUsername())) {
            for (String item : room.getWordChoices()) {
                if (choices.length() > 0) {
                    choices.append(",");
                }
                choices.append(escape(item));
            }
        }

        String visibleWord = viewerUsername.equals(room.getDrawerUsername()) ? room.getWord() : mask(room);
        StringBuilder podium = new StringBuilder();
        for (PlayerState player : getScoreboard(room)) {
            if (podium.length() > 0) {
                podium.append(",");
            }
            podium.append(escape(player.getUsername())).append("|").append(player.getScore());
        }

        return "ROOM_STATE::"
            + encodeField(room.getCode()) + "::"
            + encodeField(room.getName()) + "::"
            + encodeField(room.getHostUsername()) + "::"
            + encodeField(room.getStatus()) + "::"
            + encodeField(room.getDrawerUsername()) + "::"
            + encodeField(visibleWord) + "::"
            + room.getRoundNumber() + "::"
            + room.getRoundEndsAt() + "::"
            + room.getMaxPlayers() + "::"
            + encodeField(room.isPublic() ? "PUBLIC" : "PRIVATE") + "::"
            + encodeField(players.toString()) + "::"
            + encodeField(chat.toString()) + "::"
            + encodeField(strokes.toString()) + "::"
            + room.getTotalRounds() + "::"
            + room.getRoundSeconds() + "::"
            + room.getPickEndsAt() + "::"
            + encodeField(choices.toString()) + "::"
            + encodeField(podium.toString());
    }

    public static String getAdminRooms(String password) {
        if (!ADMIN_PASSWORD.equals(password)) {
            return "ERROR::Invalid admin password.";
        }

        StringBuilder builder = new StringBuilder();
        for (RoomState room : ROOMS.values()) {
            if (builder.length() > 0) {
                builder.append(",");
            }
            synchronized (room) {
                builder.append(escape(room.getCode())).append("|")
                    .append(escape(room.getName())).append("|")
                    .append(room.isPublic() ? "PUBLIC" : "PRIVATE").append("|")
                    .append(escape(room.getPassword())).append("|")
                    .append(room.getPlayers().size()).append("|")
                    .append(room.getMaxPlayers()).append("|")
                    .append(room.getTotalRounds()).append("|")
                    .append(room.getRoundSeconds()).append("|")
                    .append(escape(room.getStatus())).append("|")
                    .append(escape(room.getHostUsername())).append("|")
                    .append(escape(room.getWord()));
            }
        }
        return "ADMIN_ROOMS::" + builder;
    }

    public static String closeRoomAsAdmin(String password, String roomCode) {
        if (!ADMIN_PASSWORD.equals(password)) {
            return "ERROR::Invalid admin password.";
        }

        RoomState room = ROOMS.remove(sanitize(roomCode).toUpperCase());
        if (room == null) {
            return "ERROR::Room not found.";
        }

        synchronized (room) {
            for (PlayerState player : room.getPlayers().values()) {
                Session playerSession = player.getSession();
                if (playerSession != null && playerSession.isOpen()) {
                    USER_ROOMS.remove(playerSession);
                    send(playerSession, "ERROR::Room closed by admin.");
                    send(playerSession, "LEFT_ROOM");
                    sendRoomList(playerSession);
                }
            }
            room.getPlayers().clear();
        }

        broadcastPublicRoomList();
        return "ADMIN_OK::Room closed.";
    }

    private static RoomState getRoomFor(Session session) {
        String roomCode = USER_ROOMS.get(session);
        return roomCode == null ? null : ROOMS.get(roomCode);
    }

    private static void removePlayerFromRoom(RoomState room, String targetUsername, String reason) {
        PlayerState removed = room.getPlayers().remove(targetUsername);
        if (removed == null) {
            return;
        }

        Session removedSession = removed.getSession();
        if (removedSession != null) {
            USER_ROOMS.remove(removedSession);
            send(removedSession, "ERROR::" + reason);
            send(removedSession, "LEFT_ROOM");
            sendRoomList(removedSession);
        }

        addStatus(room, targetUsername + " left the room. " + reason);
        reassignHostIfNeeded(room, targetUsername);
        if (targetUsername.equals(room.getDrawerUsername())) {
            endRound(room, "Drawer left. Round ended.");
        } else {
            broadcastRoom(room);
        }
        broadcastPublicRoomList();
    }

    private static void resetScores(RoomState room) {
        for (PlayerState player : room.getPlayers().values()) {
            player.resetScore();
            player.setGuessedCorrectly(false);
        }
        room.getActiveRoundPlayers().clear();
        room.getWordChoices().clear();
        room.getStrokes().clear();
        room.getRedoStrokes().clear();
        room.getRevealedLetterIndexes().clear();
    }

    private static void finishGame(RoomState room, String reason) {
        room.bumpRoundVersion();
        room.setStatus("finished");
        room.setWord("");
        room.setDrawerUsername("");
        room.setRoundEndsAt(0L);
        room.setPickEndsAt(0L);
        room.getWordChoices().clear();
        room.getActiveRoundPlayers().clear();
        room.getRevealedLetterIndexes().clear();
        addStatus(room, reason);
        addStatus(room, "Game finished. Winner: " + winnerSummary(room) + ".");
        broadcastRoom(room);
        broadcastPublicRoomList();
    }

    private static String winnerSummary(RoomState room) {
        List<PlayerState> scoreboard = getScoreboard(room);
        if (scoreboard.isEmpty()) {
            return "No winner";
        }
        PlayerState winner = scoreboard.get(0);
        return winner.getUsername() + " with " + winner.getScore() + " points";
    }

    private static List<PlayerState> getScoreboard(RoomState room) {
        List<PlayerState> scoreboard = new ArrayList<>(room.getPlayers().values());
        scoreboard.sort((left, right) -> {
            int scoreCompare = Integer.compare(right.getScore(), left.getScore());
            if (scoreCompare != 0) {
                return scoreCompare;
            }
            return left.getUsername().compareToIgnoreCase(right.getUsername());
        });
        return scoreboard;
    }

    private static String getPlayerRoundState(RoomState room, PlayerState player) {
        if ("lobby".equals(room.getStatus()) || "finished".equals(room.getStatus())) {
            return "ready";
        }
        if (!room.getActiveRoundPlayers().contains(player.getUsername())) {
            return "next";
        }
        if (player.getUsername().equals(room.getDrawerUsername())) {
            return "drawing";
        }
        return player.hasGuessedCorrectly() ? "guessed" : "guessing";
    }

    private static int calculateGuessScore(RoomState room) {
        int alreadyGuessed = 0;
        int eligibleGuessers = 0;
        for (PlayerState player : room.getPlayers().values()) {
            if (!room.getActiveRoundPlayers().contains(player.getUsername()) || player.getUsername().equals(room.getDrawerUsername())) {
                continue;
            }
            eligibleGuessers += 1;
            if (player.hasGuessedCorrectly()) {
                alreadyGuessed += 1;
            }
        }

        if (alreadyGuessed == 0 || eligibleGuessers <= 1) {
            return MAX_GUESS_POINTS;
        }

        int drop = Math.max(5, (MAX_GUESS_POINTS - MIN_GUESS_POINTS) / Math.max(1, eligibleGuessers - 1));
        return Math.max(MIN_GUESS_POINTS, MAX_GUESS_POINTS - (alreadyGuessed * drop));
    }

    private static void reassignHostIfNeeded(RoomState room, String departedUsername) {
        if (!departedUsername.equals(room.getHostUsername()) || room.getPlayers().isEmpty()) {
            return;
        }

        String nextHost = room.getPlayers().keySet().iterator().next();
        room.setHostUsername(nextHost);
        addStatus(room, nextHost + " is now the host.");
    }

    private static boolean isCloseGuess(String guess, String word) {
        String normalizedGuess = normalizeGuess(guess);
        String normalizedWord = normalizeGuess(word);
        if (normalizedGuess.isEmpty() || normalizedWord.isEmpty() || normalizedGuess.equals(normalizedWord)) {
            return false;
        }
        return levenshteinDistance(normalizedGuess, normalizedWord) <= 2;
    }

    private static String normalizeGuess(String value) {
        return value == null ? "" : value.toLowerCase().replaceAll("[^a-z0-9]", "");
    }

    private static int levenshteinDistance(String left, String right) {
        int[] previous = new int[right.length() + 1];
        int[] current = new int[right.length() + 1];
        for (int j = 0; j <= right.length(); j += 1) {
            previous[j] = j;
        }

        for (int i = 1; i <= left.length(); i += 1) {
            current[0] = i;
            for (int j = 1; j <= right.length(); j += 1) {
                int cost = left.charAt(i - 1) == right.charAt(j - 1) ? 0 : 1;
                current[j] = Math.min(Math.min(current[j - 1] + 1, previous[j] + 1), previous[j - 1] + cost);
            }
            int[] swap = previous;
            previous = current;
            current = swap;
        }

        return previous[right.length()];
    }

    private static void scheduleLetterReveals(RoomState room, long version) {
        int revealCount = Math.min(4, Math.max(1, letterIndexes(room.getWord()).size() / 3));
        for (int step = 1; step <= revealCount; step += 1) {
            long delay = (room.getRoundSeconds() * step) / (revealCount + 1);
            SCHEDULER.schedule(() -> {
                synchronized (room) {
                    if (room.getRoundVersion() != version || !"playing".equals(room.getStatus())) {
                        return;
                    }
                    if (revealRandomLetter(room)) {
                        broadcastRoom(room);
                    }
                }
            }, delay, TimeUnit.SECONDS);
        }
    }

    private static boolean revealRandomLetter(RoomState room) {
        List<Integer> candidates = letterIndexes(room.getWord());
        if (candidates.size() <= 1 || room.getRevealedLetterIndexes().size() >= candidates.size() - 1) {
            return false;
        }

        candidates.removeAll(room.getRevealedLetterIndexes());
        if (candidates.isEmpty()) {
            return false;
        }
        room.getRevealedLetterIndexes().add(candidates.get(RANDOM.nextInt(candidates.size())));
        return true;
    }

    private static List<Integer> letterIndexes(String word) {
        List<Integer> indexes = new ArrayList<>();
        if (word == null) {
            return indexes;
        }
        for (int i = 0; i < word.length(); i += 1) {
            if (Character.isLetterOrDigit(word.charAt(i))) {
                indexes.add(i);
            }
        }
        return indexes;
    }

    private static String mask(RoomState room) {
        String word = room.getWord();
        if (word == null || word.isEmpty()) {
            return "";
        }

        StringBuilder masked = new StringBuilder();
        for (int i = 0; i < word.length(); i += 1) {
            char letter = word.charAt(i);
            if (Character.isWhitespace(letter)) {
                masked.append(" ");
            } else if (room.getRevealedLetterIndexes().contains(i)) {
                masked.append(letter);
            } else if (Character.isLetterOrDigit(letter)) {
                masked.append("_");
            } else {
                masked.append(letter);
            }
        }
        return masked.toString();
    }

    private static String drawingGroupId(String payload) {
        try {
            String decoded = new String(Base64.getDecoder().decode(payload), StandardCharsets.UTF_8);
            String[] parts = decoded.split("\\|", -1);
            if ("bucket".equals(parts[0]) && parts.length > 4) {
                return parts[4];
            }
            if (parts.length > 8) {
                return parts[8];
            }
            return payload;
        } catch (IllegalArgumentException error) {
            return payload;
        }
    }

    private static List<String> randomWords(int count) {
        List<String> pool = new ArrayList<>(WORDS);
        List<String> choices = new ArrayList<>();
        while (!pool.isEmpty() && choices.size() < count) {
            choices.add(pool.remove(RANDOM.nextInt(pool.size())));
        }
        return choices;
    }

    private static void addStatus(RoomState room, String message) {
        room.getChatLog().add("SYSTEM::" + now() + "::" + message);
    }

    private static int parseMaxPlayers(String value) {
        try {
            int parsed = Integer.parseInt(value);
            return Math.max(2, Math.min(parsed, 12));
        } catch (NumberFormatException error) {
            return 8;
        }
    }

    private static int parseTotalRounds(String value) {
        try {
            int parsed = Integer.parseInt(value);
            return Math.max(1, Math.min(parsed, 20));
        } catch (NumberFormatException error) {
            return 5;
        }
    }

    private static int parseRoundSeconds(String value) {
        try {
            int parsed = Integer.parseInt(value);
            return Math.max(30, Math.min(parsed, 180));
        } catch (NumberFormatException error) {
            return 60;
        }
    }

    private static String generateCode() {
        String code;
        do {
            code = Integer.toHexString(RANDOM.nextInt(0xFFFF)).toUpperCase();
            while (code.length() < 4) {
                code = "0" + code;
            }
        } while (ROOMS.containsKey(code));
        return code;
    }

    private static long now() {
        return System.currentTimeMillis();
    }

    private static String mask(String word) {
        if (word == null || word.isEmpty()) {
            return "";
        }
        return word.replaceAll("[A-Za-z0-9]", "_");
    }

    private static String sanitize(String value) {
        return value == null ? "" : value.trim().replaceAll("\\s+", " ");
    }

    private static String encodeField(String value) {
        return Base64.getEncoder().encodeToString((value == null ? "" : value).getBytes(StandardCharsets.UTF_8));
    }

    private static String escape(String value) {
        return value == null ? "" : value.replace("|", "/").replace(",", " ");
    }

    private static void send(Session session, String payload) {
        if (session == null || !session.isOpen()) {
            return;
        }

        try {
            session.getBasicRemote().sendText(payload);
        } catch (IOException ignored) {
        }
    }
}
