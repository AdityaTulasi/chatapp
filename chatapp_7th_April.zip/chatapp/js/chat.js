let ws;
let username = "";
let joined = false;
let manualLogout = false;
let currentRoom = "General";
let privateRooms = [];
let roomUsers = [];
let generalCount = 0;
let unreadCount = 0;
let typingTimer = null;
let sentTypingRecently = false;
let reconnectToken = "";
let activeReply = "";
let selectedReplyPreview = "";

const websocketProtocol = location.protocol === "https:" ? "wss:" : "ws:";
const baseTitle = "Intranet Chatroom";
const reconnectGraceMs = 30000;
const storageKey = "chatapp-user-session";
const emojiCatalog = [
    "😀", "😁", "😂", "🤣", "😃", "😄", "😅", "😆", "😉", "😊", "🙂", "🙃", "😉", "😍", "🥰", "😘",
    "😗", "😙", "😚", "😋", "😛", "😜", "🤪", "🤨", "🧐", "🤓", "😎", "🥳", "🤩", "😏", "😒", "😞",
    "😔", "😟", "😕", "🙁", "☹️", "😣", "😖", "😫", "😩", "🥺", "😢", "😭", "😤", "😠", "😡", "🤬",
    "🤯", "😳", "🥵", "🥶", "😱", "😨", "😰", "😥", "😓", "🤗", "🤔", "🫣", "🤭", "🫢", "🤫", "🤥",
    "😶", "🫠", "😐", "🫤", "😑", "😬", "🙄", "😯", "😦", "😧", "😮", "😲", "🥱", "😴", "🤤", "😪",
    "😮‍💨", "😵", "😵‍💫", "🤐", "🥴", "🤢", "🤮", "🤧", "😷", "🤒", "🤕", "🤑", "🤠", "😈", "👿", "👹",
    "👺", "💀", "☠️", "👻", "👽", "🤖", "🎃", "😺", "😸", "😹", "😻", "😼", "😽", "🙀", "😿", "😾",
    "👋", "🤚", "🖐️", "✋", "🖖", "👌", "🤌", "🤏", "✌️", "🤞", "🫰", "🤟", "🤘", "🤙", "👈", "👉",
    "👆", "🖕", "👇", "☝️", "👍", "👎", "👊", "✊", "🤛", "🤜", "👏", "🙌", "🫶", "👐", "🤲", "🙏",
    "✍️", "💪", "🦾", "🫱", "🫲", "💅", "👂", "🦻", "👃", "🧠", "🫀", "🫁", "🦷", "🦴", "👀", "👁️",
    "❤️", "🧡", "💛", "💚", "💙", "🩵", "💜", "🩷", "🖤", "🩶", "🤍", "🤎", "💔", "❣️", "💕", "💞",
    "💓", "💗", "💖", "💘", "💝", "💯", "💢", "💥", "💫", "💦", "💨", "🕳️", "💬", "🗨️", "🗯️", "💭",
    "🔥", "✨", "⭐", "🌟", "⚡", "💡", "🎉", "🎊", "🎈", "🎁", "🏆", "🏅", "🥇", "🥈", "🥉", "⚽",
    "🏏", "🏀", "🏐", "🎮", "🎧", "🎵", "🎶", "📢", "📣", "📌", "📎", "✅", "❌", "✔️", "➕", "➖",
    "🚀", "🛠️", "💻", "⌨️", "🖥️", "📱", "☎️", "📞", "📷", "📸", "☕", "🍕", "🍔", "🍟", "🍿", "🍫",
    "🍩", "🍪", "🍰", "🧁", "🍎", "🍉", "🍇", "🥭", "🍌", "🥥", "🌈", "☀️", "🌤️", "⛅", "🌧️", "⛈️"
];

const usernameInput = document.getElementById("username");
const messageInput = document.getElementById("msg");
const messages = document.getElementById("messages");
const loginError = document.getElementById("login-error");
const statusText = document.getElementById("status-text");
const activeCount = document.getElementById("active-count");
const typingIndicator = document.getElementById("typing-indicator");
const mentionList = document.getElementById("mention-list");
const emojiPicker = document.getElementById("emoji-picker");
const messageMenu = document.getElementById("message-menu");
const replyBox = document.getElementById("reply-box");
const replyPreview = document.getElementById("reply-preview");
const usernamePill = document.getElementById("username-pill");
const joinButton = document.getElementById("join-btn");
const sendButton = document.getElementById("send-btn");
const roomTitle = document.getElementById("room-title");
const roomSummary = document.getElementById("room-summary");
const generalRoomButton = document.getElementById("general-room-btn");
const leaveRoomButton = document.getElementById("leave-room-btn");
const privateRoomList = document.getElementById("private-room-list");
const privateRoomEmpty = document.getElementById("private-room-empty");
const privateRoomCount = document.getElementById("private-room-count");

document.addEventListener("visibilitychange", resetUnreadIfVisible);
window.addEventListener("focus", resetUnreadIfVisible);
window.addEventListener("beforeunload", persistReconnectWindow);
document.addEventListener("click", handleGlobalClick);
document.addEventListener("keydown", handleGlobalEscape);

usernameInput.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
        join();
    }
});

messageInput.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
        sendMsg();
        return;
    }

    sendTypingSignal();
});

messageInput.addEventListener("input", () => {
    renderMentionSuggestions();
    hideMessageMenu();
});

bootstrapSession();
renderEmojiPicker();

function bootstrapSession() {
    const stored = readStoredSession();
    if (!stored) {
        return;
    }

    usernameInput.value = stored.username;
    reconnectToken = stored.token;
    connect(stored.username);
}

function join() {
    const proposedName = usernameInput.value.trim().replace(/\s+/g, " ");

    if (!proposedName) {
        showLoginError("Enter a username to join.");
        return;
    }

    if (joined) {
        return;
    }

    reconnectToken = reconnectToken || createReconnectToken();
    connect(proposedName);
}

function connect(proposedName) {
    loginError.textContent = "";
    joinButton.disabled = true;
    statusText.textContent = "Connecting...";
    manualLogout = false;

    ws = new WebSocket(`${websocketProtocol}//${location.host}/chatapp/chat`);

    ws.onopen = () => {
        ws.send(`JOIN::${proposedName}::${reconnectToken}`);
        ws.send("LIST_ROOMS");
    };

    ws.onmessage = (event) => {
        const parts = event.data.split("::");
        const type = parts[0];

        if (type === "ERROR") {
            handleJoinFailure(parts.slice(1).join("::"));
            return;
        }

        if (type === "JOINED") {
            username = parts[1];
            joined = true;
            currentRoom = parts[2] || "General";
            showChat();
            usernamePill.textContent = username;
            statusText.textContent = "Connected";
            persistSession();
            updateRoomState(currentRoom);
            return;
        }

        if (type === "ROOMS") {
            generalCount = Number(parts[1] || 0);
            privateRooms = parseRooms(parts.slice(2).join("::"));
            renderRoomList();
            updateRoomState(currentRoom);
            return;
        }

        if (type === "ONLINE_USERS") {
            if ((parts[1] || "") === currentRoom) {
                roomUsers = parseOnlineUsers(parts[2] || "");
                renderMentionSuggestions();
            }
            return;
        }

        if (type === "ROOM_JOINED") {
            updateRoomState(parts[1] || "General");
            roomUsers = [];
            clearMessages();
            clearReply();
            hideTypingIndicator();
            hideMentionSuggestions();
            hideEmojiPicker();
            hideMessageMenu();
            return;
        }

        if (type === "HISTORY") {
            renderHistory(parts[1], parts[2] || "");
            return;
        }

        if (type === "SYSTEM") {
            appendSystemMessage(parts.slice(1).join("::"), true);
            return;
        }

        if (type === "CHAT") {
            appendChatMessage(parts[2], parts[3], parts.slice(4).join("::"), true);
            hideTypingIndicator();
            return;
        }

        if (type === "PRIVATE_CHAT") {
            appendPrivateChatMessage(parts[2], parts[3], parts[4], parts.slice(5).join("::"), true);
            hideTypingIndicator();
            return;
        }

        if (type === "TYPING") {
            if ((parts[1] || "") === currentRoom && (parts[2] || "") !== username) {
                showTypingIndicator(parts[2]);
            }
        }
    };

    ws.onclose = () => {
        sendButton.disabled = true;
        joinButton.disabled = false;

        if (manualLogout) {
            resetToLoggedOutState();
            return;
        }

        if (joined) {
            statusText.textContent = "Disconnected. Waiting for reconnect window.";
            appendSystemMessage("Connection closed. Reopen within 30 seconds to resume.", false);
        }

        joined = false;
    };
}

function sendMsg() {
    const message = messageInput.value.trim();

    if (!joined || !ws || ws.readyState !== WebSocket.OPEN || !message) {
        return;
    }

    const payload = activeReply ? `[reply:${activeReply}] ${message}` : message;
    ws.send(payload);
    messageInput.value = "";
    clearReply();
    hideMentionSuggestions();
    hideEmojiPicker();
    messageInput.focus();
}

function logout() {
    manualLogout = true;
    clearStoredSession();

    if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send("LOGOUT");
        return;
    }

    resetToLoggedOutState();
}

function sendTypingSignal() {
    if (!joined || !ws || ws.readyState !== WebSocket.OPEN || !messageInput.value.trim()) {
        return;
    }

    if (sentTypingRecently) {
        return;
    }

    ws.send(`TYPING::${currentRoom}`);
    sentTypingRecently = true;

    window.setTimeout(() => {
        sentTypingRecently = false;
    }, 1200);
}

function requestRooms() {
    if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send("LIST_ROOMS");
    }
}

function joinPrivateRoom(roomName) {
    if (!joined || !ws || ws.readyState !== WebSocket.OPEN) {
        return;
    }

    const password = prompt(`Enter password for ${roomName}`);
    if (password === null) {
        return;
    }

    ws.send(`JOIN_ROOM::${roomName}::${password}`);
}

function leavePrivateRoom() {
    if (!joined || !ws || ws.readyState !== WebSocket.OPEN || currentRoom === "General") {
        return;
    }

    ws.send("LEAVE_ROOM");
}

function showChat() {
    document.getElementById("login").classList.add("hidden");
    document.getElementById("chat-container").classList.remove("hidden");
    sendButton.disabled = false;
}

function resetToLoggedOutState() {
    username = "";
    joined = false;
    reconnectToken = "";
    activeReply = "";
    selectedReplyPreview = "";
    roomUsers = [];
    hideTypingIndicator();
    hideMentionSuggestions();
    hideEmojiPicker();
    hideMessageMenu();
    clearMessages();
    clearReply();
    document.getElementById("chat-container").classList.add("hidden");
    document.getElementById("login").classList.remove("hidden");
    usernamePill.textContent = "";
    statusText.textContent = "Logged out";
    loginError.textContent = "";
    messageInput.value = "";
    document.title = baseTitle;
}

function showLoginError(message) {
    loginError.textContent = message;
    joinButton.disabled = false;
}

function handleJoinFailure(message) {
    if (!joined) {
        clearStoredSession();
        reconnectToken = "";
        showLoginError(message);
    } else {
        appendSystemMessage(message, false);
    }

    statusText.textContent = joined ? statusText.textContent : "Not connected";

    if (!joined && ws && ws.readyState === WebSocket.OPEN) {
        ws.close();
    }
}

function updateRoomState(roomName) {
    currentRoom = roomName;
    const isGeneral = roomName === "General";
    const currentRoomEntry = privateRooms.find((room) => room.name === roomName);
    const currentCount = isGeneral
        ? generalCount
        : (currentRoomEntry ? currentRoomEntry.count : 0);

    roomTitle.textContent = isGeneral ? "General Chat" : roomName;
    roomSummary.textContent = isGeneral
        ? "General room is open to everyone."
        : `Private room ${roomName} is active.`;
    activeCount.textContent = `${currentCount} active user${currentCount === 1 ? "" : "s"}`;
    generalRoomButton.classList.toggle("active", isGeneral);
    generalRoomButton.textContent = `General Chat (${generalCount})`;
    leaveRoomButton.classList.toggle("hidden", isGeneral);
    renderRoomList();
}

function renderRoomList() {
    privateRoomList.innerHTML = "";
    privateRoomCount.textContent = `${privateRooms.length}/10`;
    privateRoomEmpty.classList.toggle("hidden", privateRooms.length > 0);

    privateRooms.forEach((room) => {
        const button = document.createElement("button");
        button.type = "button";
        button.className = `room-link ${room.name === currentRoom ? "active" : ""}`;
        button.textContent = `${room.name} (${room.count})`;
        button.onclick = () => joinPrivateRoom(room.name);
        privateRoomList.appendChild(button);
    });
}

function parseRooms(rawRooms) {
    if (!rawRooms) {
        return [];
    }

    return rawRooms.split(",")
        .filter(Boolean)
        .map((entry) => {
            const [name, count] = entry.split("|");
            return { name, count: Number(count || 0) };
        });
}

function parseOnlineUsers(rawUsers) {
    if (!rawUsers) {
        return [];
    }

    return rawUsers.split(",").filter(Boolean);
}

function renderHistory(roomName, encodedEntries) {
    if (roomName !== currentRoom) {
        return;
    }

    clearMessages();
    hideTypingIndicator();
    hideMessageMenu();

    if (!encodedEntries) {
        appendSystemMessage(`No previous messages in ${roomName}.`, false);
        return;
    }

    encodedEntries.split(",").filter(Boolean).forEach((encoded) => {
        const decoded = decodeBase64(encoded);
        const parts = decoded.split("::");
        const type = parts[0];

        if (type === "SYSTEM") {
            appendSystemMessage(parts.slice(1).join("::"), false);
            return;
        }

        if (type === "CHAT") {
            appendChatMessage(parts[2], parts[3], parts.slice(4).join("::"), false);
            return;
        }

        if (type === "PRIVATE_CHAT") {
            appendPrivateChatMessage(parts[2], parts[3], parts[4], parts.slice(5).join("::"), false);
        }
    });
}

function clearMessages() {
    messages.innerHTML = "";
}

function appendSystemMessage(message, countUnread) {
    const div = document.createElement("div");
    div.className = "system-message";
    div.textContent = message;
    messages.appendChild(div);
    scrollToLatest();
    maybeIncreaseUnread(countUnread);
}

function appendChatMessage(user, replyTo, text, countUnread) {
    const div = createMessageBubble(user, replyTo, text, false);
    messages.appendChild(div);
    scrollToLatest();
    if (user !== username) {
        maybeIncreaseUnread(countUnread);
    }
}

function appendPrivateChatMessage(sender, recipients, replyTo, text, countUnread) {
    const div = createMessageBubble(sender, replyTo, text, true);
    const tag = document.createElement("div");
    tag.className = "private-tag";
    tag.textContent = `Private to ${recipients}`;
    div.insertBefore(tag, div.firstChild);
    messages.appendChild(div);
    scrollToLatest();
    if (sender !== username) {
        maybeIncreaseUnread(countUnread);
    }
}

function createMessageBubble(user, replyTo, text, isPrivate) {
    const wrapper = document.createElement("div");
    wrapper.className = `message ${user === username ? "right" : "left"}${isPrivate ? " private-message" : ""}`;
    wrapper.dataset.replyPreview = `${user}: ${text}`.slice(0, 120);

    if (replyTo) {
        const reply = document.createElement("div");
        reply.className = "reply-quote";
        reply.textContent = replyTo;
        wrapper.appendChild(reply);
    }

    const body = document.createElement("div");
    body.className = "message-body";
    body.textContent = `${user}: ${text}`;
    wrapper.appendChild(body);

    wrapper.addEventListener("contextmenu", (event) => openMessageMenu(event, wrapper.dataset.replyPreview));

    return wrapper;
}

function openMessageMenu(event, preview) {
    event.preventDefault();
    selectedReplyPreview = preview;
    const bubbleRect = event.currentTarget.getBoundingClientRect();
    const menuWidth = 160;
    const menuHeight = 58;
    const bubbleOnRight = event.currentTarget.classList.contains("right");
    const preferredLeft = bubbleOnRight ? bubbleRect.right - menuWidth : bubbleRect.left;
    const spaceBelow = window.innerHeight - bubbleRect.bottom;
    const placeBelow = spaceBelow >= menuHeight + 16;
    const preferredTop = placeBelow ? bubbleRect.bottom + 8 : bubbleRect.top - menuHeight - 8;
    const left = Math.max(12, Math.min(preferredLeft, window.innerWidth - menuWidth - 12));
    const top = Math.max(12, Math.min(preferredTop, window.innerHeight - menuHeight - 12));

    messageMenu.style.left = `${left}px`;
    messageMenu.style.top = `${top}px`;
    messageMenu.dataset.caret = bubbleOnRight ? "right" : "left";
    messageMenu.dataset.vertical = placeBelow ? "top" : "bottom";
    messageMenu.classList.remove("hidden");
}

function replyFromMenu() {
    if (!selectedReplyPreview) {
        return;
    }

    startReply(selectedReplyPreview);
    hideMessageMenu();
}

function hideMessageMenu() {
    messageMenu.classList.add("hidden");
    messageMenu.dataset.caret = "";
    messageMenu.dataset.vertical = "";
    selectedReplyPreview = "";
}

function startReply(preview) {
    activeReply = preview.slice(0, 120);
    replyPreview.textContent = activeReply;
    replyBox.classList.remove("hidden");
    messageInput.focus();
}

function clearReply() {
    activeReply = "";
    replyPreview.textContent = "";
    replyBox.classList.add("hidden");
}

function renderEmojiPicker() {
    emojiPicker.innerHTML = "";

    emojiCatalog.forEach((emoji) => {
        const button = document.createElement("button");
        button.type = "button";
        button.className = "emoji-item";
        button.textContent = emoji;
        button.onclick = () => insertEmoji(emoji);
        emojiPicker.appendChild(button);
    });
}

function toggleEmojiPicker() {
    emojiPicker.classList.toggle("hidden");
    hideMessageMenu();
    if (!emojiPicker.classList.contains("hidden")) {
        hideMentionSuggestions();
    }
}

function hideEmojiPicker() {
    emojiPicker.classList.add("hidden");
}

function insertEmoji(emoji) {
    messageInput.value += emoji;
    messageInput.focus();
}

function showTypingIndicator(name) {
    typingIndicator.textContent = `${name} is typing...`;
    typingIndicator.classList.remove("hidden");

    if (typingTimer) {
        window.clearTimeout(typingTimer);
    }

    typingTimer = window.setTimeout(() => {
        hideTypingIndicator();
    }, 1600);
}

function hideTypingIndicator() {
    typingIndicator.classList.add("hidden");
    typingIndicator.textContent = "";
    if (typingTimer) {
        window.clearTimeout(typingTimer);
        typingTimer = null;
    }
}

function renderMentionSuggestions() {
    const value = messageInput.value;
    const state = getMentionState(value);

    if (!state) {
        hideMentionSuggestions();
        return;
    }

    const matchingUsers = roomUsers
        .filter((name) => name !== username)
        .filter((name) => !state.selected.includes(name))
        .filter((name) => name.toLowerCase().startsWith(state.partial.toLowerCase()));

    if (matchingUsers.length === 0) {
        hideMentionSuggestions();
        return;
    }

    mentionList.innerHTML = "";
    mentionList.classList.remove("hidden");

    matchingUsers.forEach((name) => {
        const button = document.createElement("button");
        button.type = "button";
        button.className = "mention-item";
        button.textContent = name;
        button.onclick = () => applyMention(name, state.prefix);
        mentionList.appendChild(button);
    });
}

function getMentionState(value) {
    if (!value.startsWith("@")) {
        return null;
    }

    const tokens = value.split(" ");
    const selected = [];

    for (let i = 0; i < tokens.length; i += 1) {
        const token = tokens[i];
        if (token.startsWith("@")) {
            const clean = token.slice(1).trim();
            if (i < tokens.length - 1 && clean) {
                selected.push(clean);
                continue;
            }

            return {
                prefix: tokens.slice(0, i).filter(Boolean).join(" "),
                partial: clean,
                selected
            };
        }

        return null;
    }

    return null;
}

function applyMention(name, prefix) {
    const nextValue = prefix ? `${prefix} @${name} ` : `@${name} `;
    messageInput.value = nextValue;
    messageInput.focus();
    hideMentionSuggestions();
}

function hideMentionSuggestions() {
    mentionList.classList.add("hidden");
    mentionList.innerHTML = "";
}

function handleGlobalClick(event) {
    if (!event.target.closest("#emoji-picker") && !event.target.closest("#emoji-btn")) {
        hideEmojiPicker();
    }

    if (!event.target.closest("#message-menu")) {
        hideMessageMenu();
    }
}

function handleGlobalEscape(event) {
    if (event.key !== "Escape") {
        return;
    }

    hideEmojiPicker();
    hideMentionSuggestions();
    hideMessageMenu();
}

function maybeIncreaseUnread(shouldCount) {
    if (!shouldCount || !document.hidden) {
        return;
    }

    unreadCount += 1;
    document.title = `(${unreadCount}) ${baseTitle}`;
}

function resetUnreadIfVisible() {
    if (document.hidden) {
        return;
    }

    unreadCount = 0;
    document.title = baseTitle;
}

function persistSession() {
    localStorage.setItem(storageKey, JSON.stringify({
        username,
        token: reconnectToken,
        expiresAt: Date.now() + reconnectGraceMs
    }));
}

function persistReconnectWindow() {
    if (!username || manualLogout) {
        clearStoredSession();
        return;
    }

    persistSession();
}

function readStoredSession() {
    try {
        const raw = localStorage.getItem(storageKey);
        if (!raw) {
            return null;
        }

        const parsed = JSON.parse(raw);
        if (!parsed.username || !parsed.token || !parsed.expiresAt) {
            clearStoredSession();
            return null;
        }

        if (Date.now() > Number(parsed.expiresAt)) {
            clearStoredSession();
            return null;
        }

        return parsed;
    } catch (error) {
        clearStoredSession();
        return null;
    }
}

function clearStoredSession() {
    localStorage.removeItem(storageKey);
}

function createReconnectToken() {
    if (window.crypto && window.crypto.randomUUID) {
        return window.crypto.randomUUID();
    }

    return `token-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function decodeBase64(value) {
    const binary = window.atob(value);
    let encoded = "";

    for (let i = 0; i < binary.length; i += 1) {
        encoded += `%${(`00${binary.charCodeAt(i).toString(16)}`).slice(-2)}`;
    }

    try {
        return decodeURIComponent(encoded);
    } catch (error) {
        return binary;
    }
}

function scrollToLatest() {
    messages.scrollTop = messages.scrollHeight;
}
