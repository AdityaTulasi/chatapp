package com.chat;

import javax.websocket.Session;

public class UserSession {

    private Session session;
    private String username;
    private final String ip;
    private String currentRoom;
    private final String reconnectToken;
    private boolean connected;
    private long disconnectDeadline;

    public UserSession(Session session, String username, String ip, String currentRoom, String reconnectToken) {
        this.session = session;
        this.username = username;
        this.ip = ip;
        this.currentRoom = currentRoom;
        this.reconnectToken = reconnectToken;
        this.connected = true;
        this.disconnectDeadline = 0L;
    }

    public Session getSession() {
        return session;
    }

    public void setSession(Session session) {
        this.session = session;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getIp() {
        return ip;
    }

    public String getCurrentRoom() {
        return currentRoom;
    }

    public void setCurrentRoom(String currentRoom) {
        this.currentRoom = currentRoom;
    }

    public String getReconnectToken() {
        return reconnectToken;
    }

    public boolean isConnected() {
        return connected;
    }

    public void setConnected(boolean connected) {
        this.connected = connected;
    }

    public long getDisconnectDeadline() {
        return disconnectDeadline;
    }

    public void setDisconnectDeadline(long disconnectDeadline) {
        this.disconnectDeadline = disconnectDeadline;
    }

    public boolean hasUsername() {
        return username != null && !username.trim().isEmpty();
    }
}
