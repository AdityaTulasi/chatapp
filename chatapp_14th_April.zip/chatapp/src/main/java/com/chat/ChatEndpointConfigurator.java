package com.chat;

import javax.websocket.HandshakeResponse;
import javax.websocket.server.HandshakeRequest;
import javax.websocket.server.ServerEndpointConfig;
import java.util.List;
import java.util.Map;

public class ChatEndpointConfigurator extends ServerEndpointConfig.Configurator {

    @Override
    public void modifyHandshake(ServerEndpointConfig config, HandshakeRequest request, HandshakeResponse response) {
        String clientIp = extractClientIp(request.getHeaders());
        if (!clientIp.isEmpty()) {
            config.getUserProperties().put("clientIp", clientIp);
        }
    }

    private String extractClientIp(Map<String, List<String>> headers) {
        String forwarded = firstHeader(headers, "X-Forwarded-For");
        if (!forwarded.isEmpty()) {
            return forwarded.split(",")[0].trim();
        }

        forwarded = firstHeader(headers, "Forwarded");
        if (!forwarded.isEmpty()) {
            return forwarded;
        }

        String proxyClientIp = firstHeader(headers, "Proxy-Client-IP");
        if (!proxyClientIp.isEmpty()) {
            return proxyClientIp;
        }

        String wlProxyClientIp = firstHeader(headers, "WL-Proxy-Client-IP");
        if (!wlProxyClientIp.isEmpty()) {
            return wlProxyClientIp;
        }

        return "";
    }

    private String firstHeader(Map<String, List<String>> headers, String name) {
        for (Map.Entry<String, List<String>> entry : headers.entrySet()) {
            if (entry.getKey() != null && entry.getKey().equalsIgnoreCase(name) && !entry.getValue().isEmpty()) {
                return entry.getValue().get(0);
            }
        }
        return "";
    }
}
