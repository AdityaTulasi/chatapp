package com.chat;

public class ChatRoom {

    private final String name;
    private final String password;

    public ChatRoom(String name, String password) {
        this.name = name;
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public boolean matchesPassword(String value) {
        return password.equals(value == null ? "" : value.trim());
    }
}
