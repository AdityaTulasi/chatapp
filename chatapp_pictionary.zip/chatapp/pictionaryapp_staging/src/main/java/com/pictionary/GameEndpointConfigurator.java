package com.pictionary;

import javax.servlet.http.HttpSession;
import javax.websocket.HandshakeResponse;
import javax.websocket.server.HandshakeRequest;
import javax.websocket.server.ServerEndpointConfig;

public class GameEndpointConfigurator extends ServerEndpointConfig.Configurator {

    @Override
    public void modifyHandshake(ServerEndpointConfig config, HandshakeRequest request, HandshakeResponse response) {
        Object rawSession = request.getHttpSession();
        if (rawSession instanceof HttpSession) {
            HttpSession httpSession = (HttpSession) rawSession;
            Object username = httpSession.getAttribute("pictionaryUsername");
            if (username instanceof String) {
                config.getUserProperties().put("pictionaryUsername", username);
            }
        }
    }
}
