package com.pictionary;

import javax.websocket.Session;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class GameManager {

    private static final Map<String, RoomState> ROOMS = new ConcurrentHashMap<>();
    private static final Map<Session, String> USERNAMES = new ConcurrentHashMap<>();
    private static final Map<Session, String> USER_ROOMS = new ConcurrentHashMap<>();
    private static final ScheduledExecutorService SCHEDULER = Executors.newSingleThreadScheduledExecutor();
    private static final List<String> WORDS = Arrays.asList(
        "rocket", "apple", "bridge", "planet", "guitar", "camera", "satellite", "cricket",
        "pencil", "sunflower", "rainbow", "elephant", "mountain", "notebook", "spaceship",
        "bicycle", "umbrella", "volcano", "telescope", "library", "train", "waterfall",
        "butterfly", "castle", "keyboard", "helicopter", "compass", "pizza", "snowman"
    );
    private static final Random RANDOM = new Random();

    private GameManager() {
    }

    public static void connect(String username, Session session) {
        USERNAMES.put(session, username);
        send(session, "WELCOME::" + username);
        sendRoomList(session);
    }

    public static void disconnect(Session session) {
        String roomCode = USER_ROOMS.remove(session);
        String username = USERNAMES.remove(session);

        if (roomCode == null || username == null) {
            return;
        }

        RoomState room = ROOMS.get(roomCode);
        if (room == null) {
            return;
        }

        synchronized (room) {
            room.getPlayers().remove(username);
            addStatus(room, username + " left the room.");
            if (room.getPlayers().isEmpty()) {
                ROOMS.remove(roomCode);
            } else {
                if (username.equals(room.getDrawerUsername())) {
                    endRound(room, "Drawer left. Round ended.");
                }
                broadcastRoom(room);
            }
        }

        broadcastPublicRoomList();
    }

    public static void sendRoomList(Session session) {
        send(session, "ROOM_LIST::" + buildRoomList());
    }

    public static void createRoom(Session session, String name, String visibility, String password, String maxPlayers, String totalRounds, String roundSeconds) {
        String username = USERNAMES.get(session);
        if (username == null) {
            return;
        }

        String cleanName = sanitize(name);
        boolean isPublic = "PUBLIC".equalsIgnoreCase(visibility);
        String cleanPassword = sanitize(password);
        int limit = parseMaxPlayers(maxPlayers);
        int rounds = parseTotalRounds(totalRounds);
        int seconds = parseRoundSeconds(roundSeconds);

        if (cleanName.isEmpty()) {
            send(session, "ERROR::Room name is required.");
            return;
        }

        String roomCode = generateCode();
        RoomState room = new RoomState(roomCode, cleanName, isPublic, cleanPassword, limit, rounds, seconds, username);
        room.getPlayers().put(username, new PlayerState(username, session));
        addStatus(room, "Room created by " + username + ". " + rounds + " rounds, " + seconds + " seconds per round.");
        ROOMS.put(roomCode, room);
        USER_ROOMS.put(session, roomCode);

        send(session, "ROOM_JOINED::" + roomCode);
        broadcastRoom(room);
        broadcastPublicRoomList();
    }

    public static void joinRoom(Session session, String roomCode, String password) {
        String username = USERNAMES.get(session);
        if (username == null) {
            return;
        }

        RoomState room = ROOMS.get(sanitize(roomCode).toUpperCase());
        if (room == null) {
            send(session, "ERROR::Room not found.");
            return;
        }

        synchronized (room) {
            if (!room.getPassword().isEmpty() && !room.getPassword().equals(sanitize(password))) {
                send(session, "ERROR::Wrong room password.");
                return;
            }

            if (room.getPlayers().containsKey(username)) {
                room.getPlayers().get(username).setSession(session);
            } else {
                if (room.getPlayers().size() >= room.getMaxPlayers()) {
                    send(session, "ERROR::Room is full.");
                    return;
                }
                room.getPlayers().put(username, new PlayerState(username, session));
                addStatus(room, username + " joined the room.");
                if (!"lobby".equals(room.getStatus()) && !"finished".equals(room.getStatus())) {
                    addStatus(room, username + " will join the active draw order from the next round.");
                }
            }
        }

        USER_ROOMS.put(session, room.getCode());
        send(session, "ROOM_JOINED::" + room.getCode());
        broadcastRoom(room);
        broadcastPublicRoomList();
    }

    public static void leaveRoom(Session session) {
        String roomCode = USER_ROOMS.remove(session);
        String username = USERNAMES.get(session);

        if (roomCode == null || username == null) {
            return;
        }

        RoomState room = ROOMS.get(roomCode);
        if (room == null) {
            return;
        }

        synchronized (room) {
            room.getPlayers().remove(username);
            addStatus(room, username + " left the room.");
            if (room.getPlayers().isEmpty()) {
                ROOMS.remove(roomCode);
            } else {
                if (username.equals(room.getDrawerUsername())) {
                    endRound(room, "Drawer left. Round ended.");
                }
                broadcastRoom(room);
            }
        }

        send(session, "LEFT_ROOM");
        sendRoomList(session);
        broadcastPublicRoomList();
    }

    public static void startGame(Session session) {
        RoomState room = getRoomFor(session);
        String username = USERNAMES.get(session);

        if (room == null || username == null) {
            return;
        }

        synchronized (room) {
            if (!room.getHostUsername().equals(username)) {
                send(session, "ERROR::Only the host can start the game.");
                return;
            }

            if (!"lobby".equals(room.getStatus()) && !"finished".equals(room.getStatus())) {
                send(session, "ERROR::A game is already running.");
                return;
            }

            if (room.getPlayers().size() < 2) {
                send(session, "ERROR::Need at least 2 players to start.");
                return;
            }

            resetScores(room);
            room.setRoundNumber(0);
            room.setDrawerIndex(-1);
            addStatus(room, username + " started the game.");
            prepareNextRound(room);
        }
    }

    public static void updateRoomSettings(Session session, String totalRounds, String roundSeconds) {
        RoomState room = getRoomFor(session);
        String username = USERNAMES.get(session);

        if (room == null || username == null) {
            return;
        }

        synchronized (room) {
            if (!room.getHostUsername().equals(username)) {
                send(session, "ERROR::Only the host can change room settings.");
                return;
            }

            if (!"lobby".equals(room.getStatus()) && !"finished".equals(room.getStatus())) {
                send(session, "ERROR::Settings can be changed before a game starts or after it finishes.");
                return;
            }

            room.setTotalRounds(parseTotalRounds(totalRounds));
            room.setRoundSeconds(parseRoundSeconds(roundSeconds));
            addStatus(room, username + " updated the room settings to " + room.getTotalRounds() + " rounds and " + room.getRoundSeconds() + " seconds per round.");
            broadcastRoom(room);
            broadcastPublicRoomList();
        }
    }

    public static void pickWord(Session session, String word) {
        RoomState room = getRoomFor(session);
        String username = USERNAMES.get(session);

        if (room == null || username == null) {
            return;
        }

        synchronized (room) {
            if (!"picking".equals(room.getStatus()) || !username.equals(room.getDrawerUsername())) {
                return;
            }

            String cleanWord = sanitize(word).toLowerCase();
            if (!room.getWordChoices().contains(cleanWord)) {
                send(session, "ERROR::Choose one of the offered words.");
                return;
            }

            beginDrawingRound(room, cleanWord);
        }
    }

    public static void handleChat(Session session, String text) {
        RoomState room = getRoomFor(session);
        String username = USERNAMES.get(session);

        if (room == null || username == null) {
            return;
        }

        String cleanText = sanitize(text);
        if (cleanText.isEmpty()) {
            return;
        }

        synchronized (room) {
            PlayerState player = room.getPlayers().get(username);
            if ("playing".equals(room.getStatus())
                && !username.equals(room.getDrawerUsername())
                && room.getActiveRoundPlayers().contains(username)
                && !player.hasGuessedCorrectly()
                && cleanText.equalsIgnoreCase(room.getWord())) {

                player.addScore(10);
                PlayerState drawer = room.getPlayers().get(room.getDrawerUsername());
                if (drawer != null) {
                    drawer.addScore(5);
                }

                player.setGuessedCorrectly(true);
                addStatus(room, username + " guessed the word.");
                broadcastRoom(room);

                if (allGuessersDone(room)) {
                    endRound(room, "Everyone guessed the word.");
                }
                return;
            }

            room.getChatLog().add("CHAT::" + username + "::" + now() + "::" + cleanText);
            broadcastRoom(room);
        }
    }

    public static void handleDraw(Session session, String payload) {
        RoomState room = getRoomFor(session);
        String username = USERNAMES.get(session);

        if (room == null || username == null) {
            return;
        }

        synchronized (room) {
            if (!"playing".equals(room.getStatus()) || !username.equals(room.getDrawerUsername())) {
                return;
            }

            room.getStrokes().add(payload);
            broadcastToRoom(room, "DRAW::" + payload);
        }
    }

    public static void clearCanvas(Session session) {
        RoomState room = getRoomFor(session);
        String username = USERNAMES.get(session);

        if (room == null || username == null) {
            return;
        }

        synchronized (room) {
            if (!username.equals(room.getDrawerUsername())) {
                return;
            }

            room.getStrokes().clear();
            broadcastToRoom(room, "CANVAS_CLEAR");
        }
    }

    private static void prepareNextRound(RoomState room) {
        List<String> usernames = new ArrayList<>(room.getPlayers().keySet());
        if (usernames.size() < 2) {
            finishGame(room, "Game stopped because fewer than 2 players remain.");
            return;
        }

        room.bumpRoundVersion();
        if (room.getRoundNumber() >= room.getTotalRounds()) {
            finishGame(room, "All rounds are complete.");
            return;
        }

        room.setStatus("picking");
        room.setRoundNumber(room.getRoundNumber() + 1);
        room.setDrawerIndex((room.getDrawerIndex() + 1) % usernames.size());
        room.setDrawerUsername(usernames.get(room.getDrawerIndex()));
        room.setWord("");
        room.setRoundEndsAt(0L);
        room.setPickEndsAt(now() + 15000L);
        room.getStrokes().clear();
        room.getWordChoices().clear();
        room.getWordChoices().addAll(randomWords(3));
        room.getActiveRoundPlayers().clear();
        room.getActiveRoundPlayers().addAll(usernames);
        addStatus(room, "Round " + room.getRoundNumber() + " of " + room.getTotalRounds() + ": " + room.getDrawerUsername() + " is choosing a word.");

        for (PlayerState player : room.getPlayers().values()) {
            player.setGuessedCorrectly(false);
        }

        long version = room.getRoundVersion();
        broadcastRoom(room);
        broadcastToRoom(room, "CANVAS_CLEAR");

        SCHEDULER.schedule(() -> {
            synchronized (room) {
                if (room.getRoundVersion() != version || !"picking".equals(room.getStatus())) {
                    return;
                }
                beginDrawingRound(room, room.getWordChoices().isEmpty() ? WORDS.get(RANDOM.nextInt(WORDS.size())) : room.getWordChoices().get(0));
            }
        }, 15, TimeUnit.SECONDS);
    }

    private static void beginDrawingRound(RoomState room, String word) {
        room.bumpRoundVersion();
        room.setStatus("playing");
        room.setWord(word);
        room.setPickEndsAt(0L);
        room.setRoundEndsAt(now() + (room.getRoundSeconds() * 1000L));
        room.getWordChoices().clear();
        room.getStrokes().clear();
        addStatus(room, "Round " + room.getRoundNumber() + " started. " + room.getDrawerUsername() + " is drawing.");

        long version = room.getRoundVersion();
        broadcastRoom(room);
        broadcastToRoom(room, "CANVAS_CLEAR");

        SCHEDULER.schedule(() -> {
            synchronized (room) {
                if (room.getRoundVersion() != version || !"playing".equals(room.getStatus())) {
                    return;
                }
                endRound(room, "Time is up.");
            }
        }, room.getRoundSeconds(), TimeUnit.SECONDS);
    }

    private static void endRound(RoomState room, String reason) {
        room.bumpRoundVersion();
        room.setStatus("round_end");
        addStatus(room, reason + " Word was " + room.getWord() + ".");
        broadcastRoom(room);

        long version = room.getRoundVersion();
        SCHEDULER.schedule(() -> {
            synchronized (room) {
                if (room.getRoundVersion() != version || !"round_end".equals(room.getStatus())) {
                    return;
                }
                prepareNextRound(room);
            }
        }, 4, TimeUnit.SECONDS);
    }

    private static boolean allGuessersDone(RoomState room) {
        for (PlayerState player : room.getPlayers().values()) {
            if (!room.getActiveRoundPlayers().contains(player.getUsername())) {
                continue;
            }
            if (player.getUsername().equals(room.getDrawerUsername())) {
                continue;
            }
            if (!player.hasGuessedCorrectly()) {
                return false;
            }
        }
        return true;
    }

    private static void broadcastRoom(RoomState room) {
        for (PlayerState player : room.getPlayers().values()) {
            Session session = player.getSession();
            if (session != null && session.isOpen()) {
                send(session, buildRoomState(room, player.getUsername()));
            }
        }
    }

    private static void broadcastPublicRoomList() {
        String payload = "ROOM_LIST::" + buildRoomList();
        for (Session session : USERNAMES.keySet()) {
            send(session, payload);
        }
    }

    private static void broadcastToRoom(RoomState room, String payload) {
        for (PlayerState player : room.getPlayers().values()) {
            send(player.getSession(), payload);
        }
    }

    private static String buildRoomList() {
        List<String> items = new ArrayList<>();

        for (RoomState room : ROOMS.values()) {
            if (!room.isPublic()) {
                continue;
            }
            items.add(escape(room.getCode()) + "|" + escape(room.getName()) + "|" + room.getPlayers().size() + "|" + escape(room.getStatus()));
        }

        return String.join(",", items);
    }

    private static String buildRoomState(RoomState room, String viewerUsername) {
        StringBuilder players = new StringBuilder();
        for (PlayerState player : room.getPlayers().values()) {
            if (players.length() > 0) {
                players.append(",");
            }
            players.append(escape(player.getUsername()))
                .append("|")
                .append(player.getScore())
                .append("|")
                .append(player.getUsername().equals(room.getDrawerUsername()) ? "drawer" : "player")
                .append("|")
                .append(getPlayerRoundState(room, player));
        }

        StringBuilder chat = new StringBuilder();
        for (String item : room.getChatLog()) {
            if (chat.length() > 0) {
                chat.append(",");
            }
            chat.append(Base64.getEncoder().encodeToString(item.getBytes(StandardCharsets.UTF_8)));
        }

        StringBuilder strokes = new StringBuilder();
        for (String item : room.getStrokes()) {
            if (strokes.length() > 0) {
                strokes.append(",");
            }
            strokes.append(item);
        }

        StringBuilder choices = new StringBuilder();
        if ("picking".equals(room.getStatus()) && viewerUsername.equals(room.getDrawerUsername())) {
            for (String item : room.getWordChoices()) {
                if (choices.length() > 0) {
                    choices.append(",");
                }
                choices.append(escape(item));
            }
        }

        String visibleWord = viewerUsername.equals(room.getDrawerUsername()) ? room.getWord() : mask(room.getWord());
        StringBuilder podium = new StringBuilder();
        for (PlayerState player : getScoreboard(room)) {
            if (podium.length() > 0) {
                podium.append(",");
            }
            podium.append(escape(player.getUsername())).append("|").append(player.getScore());
        }

        return "ROOM_STATE::"
            + encodeField(room.getCode()) + "::"
            + encodeField(room.getName()) + "::"
            + encodeField(room.getHostUsername()) + "::"
            + encodeField(room.getStatus()) + "::"
            + encodeField(room.getDrawerUsername()) + "::"
            + encodeField(visibleWord) + "::"
            + room.getRoundNumber() + "::"
            + room.getRoundEndsAt() + "::"
            + room.getMaxPlayers() + "::"
            + encodeField(room.isPublic() ? "PUBLIC" : "PRIVATE") + "::"
            + encodeField(players.toString()) + "::"
            + encodeField(chat.toString()) + "::"
            + encodeField(strokes.toString()) + "::"
            + room.getTotalRounds() + "::"
            + room.getRoundSeconds() + "::"
            + room.getPickEndsAt() + "::"
            + encodeField(choices.toString()) + "::"
            + encodeField(podium.toString());
    }

    private static RoomState getRoomFor(Session session) {
        String roomCode = USER_ROOMS.get(session);
        return roomCode == null ? null : ROOMS.get(roomCode);
    }

    private static void resetScores(RoomState room) {
        for (PlayerState player : room.getPlayers().values()) {
            player.resetScore();
            player.setGuessedCorrectly(false);
        }
        room.getActiveRoundPlayers().clear();
        room.getWordChoices().clear();
        room.getStrokes().clear();
    }

    private static void finishGame(RoomState room, String reason) {
        room.bumpRoundVersion();
        room.setStatus("finished");
        room.setWord("");
        room.setDrawerUsername("");
        room.setRoundEndsAt(0L);
        room.setPickEndsAt(0L);
        room.getWordChoices().clear();
        room.getActiveRoundPlayers().clear();
        addStatus(room, reason);
        addStatus(room, "Game finished. Winner: " + winnerSummary(room) + ".");
        broadcastRoom(room);
        broadcastPublicRoomList();
    }

    private static String winnerSummary(RoomState room) {
        List<PlayerState> scoreboard = getScoreboard(room);
        if (scoreboard.isEmpty()) {
            return "No winner";
        }
        PlayerState winner = scoreboard.get(0);
        return winner.getUsername() + " with " + winner.getScore() + " points";
    }

    private static List<PlayerState> getScoreboard(RoomState room) {
        List<PlayerState> scoreboard = new ArrayList<>(room.getPlayers().values());
        scoreboard.sort((left, right) -> {
            int scoreCompare = Integer.compare(right.getScore(), left.getScore());
            if (scoreCompare != 0) {
                return scoreCompare;
            }
            return left.getUsername().compareToIgnoreCase(right.getUsername());
        });
        return scoreboard;
    }

    private static String getPlayerRoundState(RoomState room, PlayerState player) {
        if ("lobby".equals(room.getStatus()) || "finished".equals(room.getStatus())) {
            return "ready";
        }
        if (!room.getActiveRoundPlayers().contains(player.getUsername())) {
            return "next";
        }
        if (player.getUsername().equals(room.getDrawerUsername())) {
            return "drawing";
        }
        return player.hasGuessedCorrectly() ? "guessed" : "guessing";
    }

    private static List<String> randomWords(int count) {
        List<String> pool = new ArrayList<>(WORDS);
        List<String> choices = new ArrayList<>();
        while (!pool.isEmpty() && choices.size() < count) {
            choices.add(pool.remove(RANDOM.nextInt(pool.size())));
        }
        return choices;
    }

    private static void addStatus(RoomState room, String message) {
        room.getChatLog().add("SYSTEM::" + now() + "::" + message);
    }

    private static int parseMaxPlayers(String value) {
        try {
            int parsed = Integer.parseInt(value);
            return Math.max(2, Math.min(parsed, 12));
        } catch (NumberFormatException error) {
            return 8;
        }
    }

    private static int parseTotalRounds(String value) {
        try {
            int parsed = Integer.parseInt(value);
            return Math.max(1, Math.min(parsed, 20));
        } catch (NumberFormatException error) {
            return 5;
        }
    }

    private static int parseRoundSeconds(String value) {
        try {
            int parsed = Integer.parseInt(value);
            return Math.max(30, Math.min(parsed, 180));
        } catch (NumberFormatException error) {
            return 60;
        }
    }

    private static String generateCode() {
        String code;
        do {
            code = Integer.toHexString(RANDOM.nextInt(0xFFFF)).toUpperCase();
            while (code.length() < 4) {
                code = "0" + code;
            }
        } while (ROOMS.containsKey(code));
        return code;
    }

    private static long now() {
        return System.currentTimeMillis();
    }

    private static String mask(String word) {
        if (word == null || word.isEmpty()) {
            return "";
        }
        return word.replaceAll("[A-Za-z0-9]", "_");
    }

    private static String sanitize(String value) {
        return value == null ? "" : value.trim().replaceAll("\\s+", " ");
    }

    private static String encodeField(String value) {
        return Base64.getEncoder().encodeToString((value == null ? "" : value).getBytes(StandardCharsets.UTF_8));
    }

    private static String escape(String value) {
        return value == null ? "" : value.replace("|", "/").replace(",", " ");
    }

    private static void send(Session session, String payload) {
        if (session == null || !session.isOpen()) {
            return;
        }

        try {
            session.getBasicRemote().sendText(payload);
        } catch (IOException ignored) {
        }
    }
}
