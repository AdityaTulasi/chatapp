package com.pictionary;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/enter")
public class EnterServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        LaunchTokenUtil.LaunchIdentity identity = LaunchTokenUtil.validate(request.getParameter("token"));

        if (identity == null) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN, "Valid launch token required.");
            return;
        }

        HttpSession session = request.getSession(true);
        session.setAttribute("pictionaryUsername", identity.getUsername());
        response.sendRedirect(request.getContextPath() + "/");
    }
}
