package com.chat;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

@WebServlet("/pictionary-launch")
public class PictionaryLaunchServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String reconnectToken = request.getParameter("token");

        if (!ChatManager.canLaunchGame(username, reconnectToken)) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN, "Join chatapp first before launching pictionary.");
            return;
        }

        String launchToken = LaunchTokenUtil.createToken(username);
        String encodedToken = URLEncoder.encode(launchToken, StandardCharsets.UTF_8.name());
        response.sendRedirect(request.getContextPath().replace("/chatapp", "") + "/pictionaryapp/enter?token=" + encodedToken);
    }
}
