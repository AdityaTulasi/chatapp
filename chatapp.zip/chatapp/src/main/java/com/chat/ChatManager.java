package com.chat;

import javax.websocket.Session;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Comparator;
import java.util.Deque;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class ChatManager {

    public static final String GENERAL_ROOM = "General";
    private static final String ADMIN_PASSWORD = "admin123";
    private static final String SUPERUSER_PASSWORD = "super123";
    private static final int MAX_PRIVATE_ROOMS = 10;
    private static final int HISTORY_LIMIT = 100;

    private static final Map<Session, UserSession> USERS = new ConcurrentHashMap<>();
    private static final Map<String, ChatRoom> PRIVATE_ROOMS = new ConcurrentHashMap<>();
    private static final Map<String, Deque<String>> ROOM_HISTORY = new ConcurrentHashMap<>();

    static {
        ROOM_HISTORY.put(GENERAL_ROOM, new ArrayDeque<>());
    }

    private ChatManager() {
    }

    public static void addSession(Session session) {
        USERS.put(session, new UserSession(session, null, resolveClientIp(session), GENERAL_ROOM));
        sendRoomsTo(session);
    }

    public static void removeSession(Session session) {
        UserSession removed = USERS.remove(session);

        if (removed != null && removed.hasUsername()) {
            broadcastSystemToRoom(removed.getCurrentRoom(), removed.getUsername() + " left " + removed.getCurrentRoom() + ".", true);
            broadcastRooms();
        }
    }

    public static void join(Session session, String username) {
        UserSession current = USERS.get(session);

        if (current == null) {
            addSession(session);
            current = USERS.get(session);
        }

        String cleanUsername = normalize(username);

        if (cleanUsername.isEmpty()) {
            send(session, "ERROR::Username is required.");
            return;
        }

        if (cleanUsername.length() > 24) {
            send(session, "ERROR::Username must be 24 characters or fewer.");
            return;
        }

        if (!cleanUsername.matches("[A-Za-z0-9_\\- ]+")) {
            send(session, "ERROR::Use letters, numbers, spaces, hyphens, or underscores.");
            return;
        }

        if (isUsernameTaken(cleanUsername, session)) {
            send(session, "ERROR::That username is already in use.");
            return;
        }

        current.setUsername(cleanUsername);
        current.setCurrentRoom(GENERAL_ROOM);

        send(session, "JOINED::" + cleanUsername + "::" + GENERAL_ROOM);
        sendRoomsTo(session);
        sendHistory(session, GENERAL_ROOM);
        broadcastSystemToRoom(GENERAL_ROOM, cleanUsername + " joined the general chat.", true);
        broadcastRooms();
    }

    public static void handleChat(Session session, String message) {
        UserSession user = USERS.get(session);

        if (user == null || !user.hasUsername()) {
            send(session, "ERROR::Join with a username before chatting.");
            return;
        }

        String cleanMessage = normalize(message);

        if (cleanMessage.isEmpty()) {
            return;
        }

        String payload = "CHAT::" + user.getCurrentRoom() + "::" + user.getUsername() + "::" + cleanMessage;
        addToHistory(user.getCurrentRoom(), payload);
        broadcastToRoom(user.getCurrentRoom(), payload);
    }

    public static void handleTyping(Session session) {
        UserSession user = USERS.get(session);

        if (user == null || !user.hasUsername()) {
            return;
        }

        String payload = "TYPING::" + user.getCurrentRoom() + "::" + user.getUsername();
        for (UserSession target : USERS.values()) {
            if (target.getSession().equals(session)) {
                continue;
            }

            if (user.getCurrentRoom().equals(target.getCurrentRoom())) {
                send(target.getSession(), payload);
            }
        }
    }

    public static void joinPrivateRoom(Session session, String roomName, String password) {
        UserSession user = USERS.get(session);

        if (user == null || !user.hasUsername()) {
            send(session, "ERROR::Join the app first before switching rooms.");
            return;
        }

        ChatRoom room = findRoom(roomName);

        if (room == null) {
            send(session, "ERROR::That private room does not exist.");
            return;
        }

        if (!room.matchesPassword(password)) {
            send(session, "ERROR::Wrong password for that private room.");
            return;
        }

        switchRoom(user, room.getName(), true);
    }

    public static void leavePrivateRoom(Session session) {
        UserSession user = USERS.get(session);

        if (user == null || !user.hasUsername()) {
            send(session, "ERROR::Join the app first before switching rooms.");
            return;
        }

        if (GENERAL_ROOM.equals(user.getCurrentRoom())) {
            send(session, "SYSTEM::You are already in the general chat.");
            return;
        }

        switchRoom(user, GENERAL_ROOM, false);
    }

    public static void sendRoomsTo(Session session) {
        send(session, "ROOMS::" + getGeneralUserCount() + "::" + getRoomsAsString());
    }

    public static void createPrivateRoom(Session session, String adminPassword, String roomName, String roomPassword) {
        if (!ADMIN_PASSWORD.equals(adminPassword)) {
            send(session, "ERROR::Invalid admin password.");
            return;
        }

        String cleanRoomName = normalize(roomName);
        String cleanRoomPassword = normalize(roomPassword);

        if (cleanRoomName.isEmpty() || cleanRoomPassword.isEmpty()) {
            send(session, "ERROR::Room name and room password are required.");
            return;
        }

        if (GENERAL_ROOM.equalsIgnoreCase(cleanRoomName)) {
            send(session, "ERROR::That room name is reserved.");
            return;
        }

        if (cleanRoomName.length() > 30) {
            send(session, "ERROR::Room name must be 30 characters or fewer.");
            return;
        }

        if (!cleanRoomName.matches("[A-Za-z0-9_\\- ]+")) {
            send(session, "ERROR::Room name can use letters, numbers, spaces, hyphens, or underscores.");
            return;
        }

        if (cleanRoomPassword.length() > 30) {
            send(session, "ERROR::Room password must be 30 characters or fewer.");
            return;
        }

        synchronized (PRIVATE_ROOMS) {
            if (PRIVATE_ROOMS.size() >= MAX_PRIVATE_ROOMS) {
                send(session, "ERROR::Only 10 private chatrooms can exist at a time.");
                return;
            }

            if (findRoom(cleanRoomName) != null) {
                send(session, "ERROR::That private room already exists.");
                return;
            }

            PRIVATE_ROOMS.put(cleanRoomName, new ChatRoom(cleanRoomName, cleanRoomPassword));
            ROOM_HISTORY.put(cleanRoomName, new ArrayDeque<>());
        }

        send(session, "ADMIN_OK::Private room created.");
        broadcastRooms();
    }

    public static void deletePrivateRoom(Session session, String superuserPassword, String roomName) {
        if (!SUPERUSER_PASSWORD.equals(superuserPassword)) {
            send(session, "ERROR::Invalid superuser password.");
            return;
        }

        ChatRoom room;
        synchronized (PRIVATE_ROOMS) {
            room = findRoom(roomName);
            if (room == null) {
                send(session, "ERROR::That private room does not exist.");
                return;
            }

            PRIVATE_ROOMS.remove(room.getName());
            ROOM_HISTORY.remove(room.getName());
        }

        for (UserSession user : USERS.values()) {
            if (room.getName().equals(user.getCurrentRoom())) {
                user.setCurrentRoom(GENERAL_ROOM);
                send(user.getSession(), "ROOM_JOINED::" + GENERAL_ROOM + "::GENERAL");
                sendHistory(user.getSession(), GENERAL_ROOM);
                send(user.getSession(), "SYSTEM::Private room " + room.getName() + " was deleted. You are back in General.");
            }
        }

        send(session, "ADMIN_OK::Private room deleted.");
        broadcastSystemToRoom(GENERAL_ROOM, "Private room " + room.getName() + " was deleted.", true);
        broadcastRooms();
    }

    public static void sendUsersTo(Session session, String adminPassword) {
        if (!ADMIN_PASSWORD.equals(adminPassword)) {
            send(session, "ERROR::Invalid admin password.");
            return;
        }

        send(session, "ADMIN_USERS::" + getUsersAsString());
    }

    public static void sendRoomsToAdmin(Session session, String adminPassword) {
        if (!ADMIN_PASSWORD.equals(adminPassword)) {
            send(session, "ERROR::Invalid admin password.");
            return;
        }

        send(session, "ADMIN_ROOMS::" + getGeneralUserCount() + "::" + getRoomsAsString());
    }

    public static void kickUser(Session session, String adminPassword, String username) {
        if (!ADMIN_PASSWORD.equals(adminPassword)) {
            send(session, "ERROR::Invalid admin password.");
            return;
        }

        String target = normalize(username);

        for (Map.Entry<Session, UserSession> entry : USERS.entrySet()) {
            UserSession user = entry.getValue();

            if (user.hasUsername() && user.getUsername().equalsIgnoreCase(target)) {
                send(entry.getKey(), "SYSTEM::You were removed by the admin.");
                try {
                    entry.getKey().close();
                } catch (IOException ignored) {
                }
                send(session, "ADMIN_OK::User removed.");
                return;
            }
        }

        send(session, "ERROR::User not found.");
    }

    private static void switchRoom(UserSession user, String nextRoom, boolean privateRoom) {
        String previousRoom = user.getCurrentRoom();

        if (previousRoom.equals(nextRoom)) {
            send(user.getSession(), "SYSTEM::You are already in " + nextRoom + ".");
            return;
        }

        user.setCurrentRoom(nextRoom);
        send(user.getSession(), "ROOM_JOINED::" + nextRoom + "::" + (privateRoom ? "PRIVATE" : "GENERAL"));
        sendHistory(user.getSession(), nextRoom);
        send(user.getSession(), "SYSTEM::You entered " + nextRoom + ".");

        if (user.hasUsername()) {
            broadcastSystemToRoom(previousRoom, user.getUsername() + " left " + previousRoom + ".", true);
            broadcastSystemToRoom(nextRoom, user.getUsername() + " joined " + nextRoom + ".", true);
        }

        broadcastRooms();
    }

    private static void sendHistory(Session session, String roomName) {
        Deque<String> history = ROOM_HISTORY.computeIfAbsent(roomName, key -> new ArrayDeque<>());
        StringBuilder builder = new StringBuilder();

        synchronized (history) {
            for (String entry : history) {
                if (builder.length() > 0) {
                    builder.append(",");
                }
                builder.append(encode(entry));
            }
        }

        send(session, "HISTORY::" + roomName + "::" + builder);
    }

    private static void addToHistory(String roomName, String payload) {
        Deque<String> history = ROOM_HISTORY.computeIfAbsent(roomName, key -> new ArrayDeque<>());

        synchronized (history) {
            history.addLast(payload);
            while (history.size() > HISTORY_LIMIT) {
                history.removeFirst();
            }
        }
    }

    private static void broadcastRooms() {
        String payload = "ROOMS::" + getGeneralUserCount() + "::" + getRoomsAsString();

        for (Session session : USERS.keySet()) {
            send(session, payload);
        }
    }

    private static void broadcastToRoom(String roomName, String message) {
        for (UserSession user : USERS.values()) {
            if (roomName.equals(user.getCurrentRoom())) {
                send(user.getSession(), message);
            }
        }
    }

    private static void broadcastSystemToRoom(String roomName, String message, boolean persist) {
        String payload = "SYSTEM::" + message;

        if (persist) {
            addToHistory(roomName, payload);
        }

        broadcastToRoom(roomName, payload);
    }

    private static String getUsersAsString() {
        List<UserSession> sessions = new ArrayList<>(USERS.values());
        sessions.sort(Comparator.comparing(
            user -> user.hasUsername() ? user.getUsername().toLowerCase() : "~pending"
        ));

        StringBuilder builder = new StringBuilder();

        for (UserSession user : sessions) {
            if (!user.hasUsername()) {
                continue;
            }

            if (builder.length() > 0) {
                builder.append(",");
            }

            builder.append(user.getUsername())
                .append("|")
                .append(user.getCurrentRoom())
                .append("|")
                .append(user.getIp());
        }

        return builder.toString();
    }

    private static String getRoomsAsString() {
        List<ChatRoom> rooms = new ArrayList<>(PRIVATE_ROOMS.values());
        rooms.sort(Comparator.comparing(room -> room.getName().toLowerCase()));

        StringBuilder builder = new StringBuilder();
        for (ChatRoom room : rooms) {
            if (builder.length() > 0) {
                builder.append(",");
            }

            builder.append(room.getName())
                .append("|")
                .append(countUsersInRoom(room.getName()));
        }

        return builder.toString();
    }

    private static int getGeneralUserCount() {
        return countUsersInRoom(GENERAL_ROOM);
    }

    private static int countUsersInRoom(String roomName) {
        int count = 0;
        for (UserSession user : USERS.values()) {
            if (roomName.equals(user.getCurrentRoom())) {
                count++;
            }
        }
        return count;
    }

    private static boolean isUsernameTaken(String username, Session currentSession) {
        for (Map.Entry<Session, UserSession> entry : USERS.entrySet()) {
            if (entry.getKey().equals(currentSession)) {
                continue;
            }

            UserSession user = entry.getValue();
            if (user.hasUsername() && user.getUsername().equalsIgnoreCase(username)) {
                return true;
            }
        }

        return false;
    }

    private static ChatRoom findRoom(String roomName) {
        String target = normalize(roomName);

        for (ChatRoom room : PRIVATE_ROOMS.values()) {
            if (room.getName().equalsIgnoreCase(target)) {
                return room;
            }
        }

        return null;
    }

    private static String resolveClientIp(Session session) {
        Object clientIp = session.getUserProperties().get("clientIp");
        if (clientIp instanceof String && !((String) clientIp).trim().isEmpty()) {
            return ((String) clientIp).trim();
        }
        return "Unavailable (" + session.getId() + ")";
    }

    private static String encode(String value) {
        return Base64.getEncoder().encodeToString(value.getBytes(StandardCharsets.UTF_8));
    }

    private static void send(Session session, String message) {
        if (session == null || !session.isOpen()) {
            return;
        }

        try {
            session.getBasicRemote().sendText(message);
        } catch (IOException ignored) {
        }
    }

    private static String normalize(String value) {
        return value == null ? "" : value.trim().replaceAll("\\s+", " ");
    }
}
