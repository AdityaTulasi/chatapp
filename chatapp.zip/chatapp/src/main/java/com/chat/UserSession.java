package com.chat;

import javax.websocket.Session;

public class UserSession {

    private final Session session;
    private String username;
    private final String ip;
    private String currentRoom;

    public UserSession(Session session, String username, String ip, String currentRoom) {
        this.session = session;
        this.username = username;
        this.ip = ip;
        this.currentRoom = currentRoom;
    }

    public Session getSession() {
        return session;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getIp() {
        return ip;
    }

    public String getCurrentRoom() {
        return currentRoom;
    }

    public void setCurrentRoom(String currentRoom) {
        this.currentRoom = currentRoom;
    }

    public boolean hasUsername() {
        return username != null && !username.trim().isEmpty();
    }
}
