const adminPassword = prompt("Enter admin password:");
const websocketProtocol = location.protocol === "https:" ? "wss:" : "ws:";
const accessAllowed = Boolean(adminPassword);

if (!accessAllowed) {
    alert("Access denied");
    document.body.innerHTML = "";
}

let ws;

function connect() {
    ws = new WebSocket(`${websocketProtocol}//${location.host}/chatapp/chat`);

    ws.onopen = () => {
        loadUsers();
        loadRooms();
    };

    ws.onmessage = (event) => {
        const parts = event.data.split("::");
        const type = parts[0];

        if (type === "ADMIN_USERS") {
            renderUsers(parts.slice(1).join("::"));
            return;
        }

        if (type === "ADMIN_ROOMS" || type === "ROOMS") {
            renderRooms(parts[1] || "0", parts.slice(2).join("::"));
            return;
        }

        if (type === "ADMIN_OK") {
            setAdminMessage(parts.slice(1).join("::"));
            loadRooms();
            loadUsers();
            return;
        }

        if (type === "ERROR") {
            setAdminMessage(parts.slice(1).join("::"));
        }
    };
}

function loadUsers() {
    if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send(`/admin users::${adminPassword}`);
    }
}

function loadRooms() {
    if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send(`/admin rooms::${adminPassword}`);
    }
}

function createRoom() {
    const roomName = document.getElementById("room-name").value.trim().replace(/\s+/g, " ");
    const roomPassword = document.getElementById("room-password").value.trim();

    if (!roomName || !roomPassword) {
        setAdminMessage("Enter both room name and room password.");
        return;
    }

    ws.send(`/admin create room::${adminPassword}::${roomName}::${roomPassword}`);
    document.getElementById("room-name").value = "";
    document.getElementById("room-password").value = "";
}

function renderUsers(data) {
    const list = document.getElementById("users");
    list.innerHTML = "";

    data.split(",").forEach((entry) => {
        if (!entry) {
            return;
        }

        const [name, room, ip] = entry.split("|");
        const item = document.createElement("li");
        item.className = "admin-item";

        const label = document.createElement("span");
        label.textContent = `${name} in ${room} (${ip})`;

        const button = document.createElement("button");
        button.type = "button";
        button.textContent = "Kick";
        button.onclick = () => kick(name);

        item.appendChild(label);
        item.appendChild(button);
        list.appendChild(item);
    });
}

function renderRooms(generalUsers, data) {
    const roomList = document.getElementById("admin-room-list");
    const empty = document.getElementById("admin-room-empty");
    const roomCount = document.getElementById("admin-room-count");
    const generalCount = document.getElementById("general-room-admin-count");

    roomList.innerHTML = "";
    generalCount.textContent = `General Chat (${generalUsers} users)`;

    const rooms = data
        .split(",")
        .filter(Boolean)
        .map((entry) => {
            const [name, count] = entry.split("|");
            return { name, count: Number(count || 0) };
        });

    roomCount.textContent = `${rooms.length}/10`;
    empty.classList.toggle("hidden", rooms.length > 0);

    rooms.forEach((room) => {
        const row = document.createElement("div");
        row.className = "admin-room-row";

        const label = document.createElement("span");
        label.textContent = `${room.name} (${room.count} users)`;

        const button = document.createElement("button");
        button.type = "button";
        button.textContent = "Delete";
        button.onclick = () => deleteRoom(room.name);

        row.appendChild(label);
        row.appendChild(button);
        roomList.appendChild(row);
    });
}

function kick(username) {
    ws.send(`/admin kick::${adminPassword}::${username}`);
}

function deleteRoom(roomName) {
    const superPassword = prompt(`Enter superuser password to delete ${roomName}`);
    if (superPassword === null || !superPassword.trim()) {
        return;
    }

    ws.send(`/super delete room::${superPassword.trim()}::${roomName}`);
}

function setAdminMessage(message) {
    document.getElementById("admin-message").textContent = message;
}

if (accessAllowed) {
    connect();
}
