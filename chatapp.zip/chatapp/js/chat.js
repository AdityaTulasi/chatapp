let ws;
let username = "";
let joined = false;
let currentRoom = "General";
let privateRooms = [];
let generalCount = 0;
let unreadCount = 0;
let typingTimer = null;
let sentTypingRecently = false;

const websocketProtocol = location.protocol === "https:" ? "wss:" : "ws:";
const baseTitle = "Intranet Chatroom";

const usernameInput = document.getElementById("username");
const messageInput = document.getElementById("msg");
const messages = document.getElementById("messages");
const loginError = document.getElementById("login-error");
const statusText = document.getElementById("status-text");
const activeCount = document.getElementById("active-count");
const typingIndicator = document.getElementById("typing-indicator");
const usernamePill = document.getElementById("username-pill");
const joinButton = document.getElementById("join-btn");
const sendButton = document.getElementById("send-btn");
const roomTitle = document.getElementById("room-title");
const roomSummary = document.getElementById("room-summary");
const generalRoomButton = document.getElementById("general-room-btn");
const leaveRoomButton = document.getElementById("leave-room-btn");
const privateRoomList = document.getElementById("private-room-list");
const privateRoomEmpty = document.getElementById("private-room-empty");
const privateRoomCount = document.getElementById("private-room-count");

document.addEventListener("visibilitychange", resetUnreadIfVisible);
window.addEventListener("focus", resetUnreadIfVisible);

usernameInput.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
        join();
    }
});

messageInput.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
        sendMsg();
        return;
    }

    sendTypingSignal();
});

function join() {
    const proposedName = usernameInput.value.trim().replace(/\s+/g, " ");

    if (!proposedName) {
        showLoginError("Enter a username to join.");
        return;
    }

    if (joined) {
        return;
    }

    loginError.textContent = "";
    joinButton.disabled = true;
    statusText.textContent = "Connecting...";

    ws = new WebSocket(`${websocketProtocol}//${location.host}/chatapp/chat`);

    ws.onopen = () => {
        ws.send(`JOIN::${proposedName}`);
        ws.send("LIST_ROOMS");
    };

    ws.onmessage = (event) => {
        const parts = event.data.split("::");
        const type = parts[0];

        if (type === "ERROR") {
            handleJoinFailure(parts.slice(1).join("::"));
            return;
        }

        if (type === "JOINED") {
            username = parts[1];
            joined = true;
            currentRoom = parts[2] || "General";
            showChat();
            usernamePill.textContent = username;
            statusText.textContent = "Connected";
            updateRoomState(currentRoom);
            return;
        }

        if (type === "ROOMS") {
            generalCount = Number(parts[1] || 0);
            privateRooms = parseRooms(parts.slice(2).join("::"));
            renderRoomList();
            updateRoomState(currentRoom);
            return;
        }

        if (type === "ROOM_JOINED") {
            updateRoomState(parts[1] || "General");
            clearMessages();
            hideTypingIndicator();
            return;
        }

        if (type === "HISTORY") {
            renderHistory(parts[1], parts[2] || "");
            return;
        }

        if (type === "SYSTEM") {
            appendSystemMessage(parts.slice(1).join("::"), true);
            return;
        }

        if (type === "CHAT") {
            appendChatMessage(parts[2], parts.slice(3).join("::"), true);
            hideTypingIndicator();
            return;
        }

        if (type === "TYPING") {
            if ((parts[1] || "") === currentRoom && (parts[2] || "") !== username) {
                showTypingIndicator(parts[2]);
            }
        }
    };

    ws.onclose = () => {
        if (joined) {
            statusText.textContent = "Disconnected";
            appendSystemMessage("Connection closed.", false);
        }

        joinButton.disabled = false;
        sendButton.disabled = true;
        joined = false;
    };
}

function sendMsg() {
    const message = messageInput.value.trim();

    if (!joined || !ws || ws.readyState !== WebSocket.OPEN || !message) {
        return;
    }

    ws.send(message);
    messageInput.value = "";
    messageInput.focus();
}

function sendTypingSignal() {
    if (!joined || !ws || ws.readyState !== WebSocket.OPEN || !messageInput.value.trim()) {
        return;
    }

    if (sentTypingRecently) {
        return;
    }

    ws.send(`TYPING::${currentRoom}`);
    sentTypingRecently = true;

    window.setTimeout(() => {
        sentTypingRecently = false;
    }, 1200);
}

function requestRooms() {
    if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send("LIST_ROOMS");
    }
}

function joinPrivateRoom(roomName) {
    if (!joined || !ws || ws.readyState !== WebSocket.OPEN) {
        return;
    }

    const password = prompt(`Enter password for ${roomName}`);
    if (password === null) {
        return;
    }

    ws.send(`JOIN_ROOM::${roomName}::${password}`);
}

function leavePrivateRoom() {
    if (!joined || !ws || ws.readyState !== WebSocket.OPEN || currentRoom === "General") {
        return;
    }

    ws.send("LEAVE_ROOM");
}

function showChat() {
    document.getElementById("login").classList.add("hidden");
    document.getElementById("chat-container").classList.remove("hidden");
    sendButton.disabled = false;
}

function showLoginError(message) {
    loginError.textContent = message;
    joinButton.disabled = false;
}

function handleJoinFailure(message) {
    if (!joined) {
        showLoginError(message);
    } else {
        appendSystemMessage(message, false);
    }

    statusText.textContent = joined ? statusText.textContent : "Not connected";

    if (!joined && ws && ws.readyState === WebSocket.OPEN) {
        ws.close();
    }
}

function updateRoomState(roomName) {
    currentRoom = roomName;
    const isGeneral = roomName === "General";
    const currentCount = isGeneral
        ? generalCount
        : (privateRooms.find((room) => room.name === roomName)?.count || 0);

    roomTitle.textContent = isGeneral ? "General Chat" : roomName;
    roomSummary.textContent = isGeneral
        ? "General room is open to everyone."
        : `Private room ${roomName} is active.`;
    activeCount.textContent = `${currentCount} active user${currentCount === 1 ? "" : "s"}`;
    generalRoomButton.classList.toggle("active", isGeneral);
    generalRoomButton.textContent = `General Chat (${generalCount})`;
    leaveRoomButton.classList.toggle("hidden", isGeneral);
    renderRoomList();
}

function renderRoomList() {
    privateRoomList.innerHTML = "";
    privateRoomCount.textContent = `${privateRooms.length}/10`;
    privateRoomEmpty.classList.toggle("hidden", privateRooms.length > 0);

    privateRooms.forEach((room) => {
        const button = document.createElement("button");
        button.type = "button";
        button.className = `room-link ${room.name === currentRoom ? "active" : ""}`;
        button.textContent = `${room.name} (${room.count})`;
        button.onclick = () => joinPrivateRoom(room.name);
        privateRoomList.appendChild(button);
    });
}

function parseRooms(rawRooms) {
    if (!rawRooms) {
        return [];
    }

    return rawRooms.split(",")
        .filter(Boolean)
        .map((entry) => {
            const [name, count] = entry.split("|");
            return { name, count: Number(count || 0) };
        });
}

function renderHistory(roomName, encodedEntries) {
    if (roomName !== currentRoom) {
        return;
    }

    clearMessages();
    hideTypingIndicator();

    if (!encodedEntries) {
        appendSystemMessage(`No previous messages in ${roomName}.`, false);
        return;
    }

    encodedEntries.split(",").filter(Boolean).forEach((encoded) => {
        const decoded = decodeURIComponent(escape(window.atob(encoded)));
        const parts = decoded.split("::");
        const type = parts[0];

        if (type === "SYSTEM") {
            appendSystemMessage(parts.slice(1).join("::"), false);
            return;
        }

        if (type === "CHAT") {
            appendChatMessage(parts[2], parts.slice(3).join("::"), false);
        }
    });
}

function clearMessages() {
    messages.innerHTML = "";
}

function appendSystemMessage(message, countUnread) {
    const div = document.createElement("div");
    div.className = "system-message";
    div.textContent = message;
    messages.appendChild(div);
    scrollToLatest();
    maybeIncreaseUnread(countUnread);
}

function appendChatMessage(user, text, countUnread) {
    const div = document.createElement("div");
    div.className = `message ${user === username ? "right" : "left"}`;
    div.textContent = `${user}: ${text}`;
    messages.appendChild(div);
    scrollToLatest();
    if (user !== username) {
        maybeIncreaseUnread(countUnread);
    }
}

function showTypingIndicator(name) {
    typingIndicator.textContent = `${name} is typing...`;
    typingIndicator.classList.remove("hidden");

    if (typingTimer) {
        window.clearTimeout(typingTimer);
    }

    typingTimer = window.setTimeout(() => {
        hideTypingIndicator();
    }, 1600);
}

function hideTypingIndicator() {
    typingIndicator.classList.add("hidden");
    typingIndicator.textContent = "";
    if (typingTimer) {
        window.clearTimeout(typingTimer);
        typingTimer = null;
    }
}

function maybeIncreaseUnread(shouldCount) {
    if (!shouldCount) {
        return;
    }

    if (!document.hidden) {
        return;
    }

    unreadCount += 1;
    document.title = `(${unreadCount}) ${baseTitle}`;
}

function resetUnreadIfVisible() {
    if (document.hidden) {
        return;
    }

    unreadCount = 0;
    document.title = baseTitle;
}

function scrollToLatest() {
    messages.scrollTop = messages.scrollHeight;
}
