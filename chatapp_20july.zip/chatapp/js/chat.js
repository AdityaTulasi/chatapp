let ws;
let username = "";
let joined = false;
let manualLogout = false;
let currentRoom = "General";
let privateRooms = [];
let roomUsers = [];
let generalCount = 0;
let unreadCount = 0;
let typingTimer = null;
let sentTypingRecently = false;
let reconnectToken = "";
let activeReply = "";
let selectedReplyPreview = "";
let serverTimeOffset = 0;
let unreadDivider = null;

const websocketProtocol = location.protocol === "https:" ? "wss:" : "ws:";
const baseTitle = "Intranet Chatroom";
const reconnectGraceMs = 30000;
const storageKey = "chatapp-user-session";
const emojiCatalog = [
    "😀", "😁", "😂", "🤣", "😃", "😄", "😅", "😆", "😉", "😊", "🙂", "🙃", "😉", "😍", "🥰", "😘",
    "😗", "😙", "😚", "😋", "😛", "😜", "🤪", "🤨", "🧐", "🤓", "😎", "🥳", "🤩", "😏", "😒", "😞",
    "😔", "😟", "😕", "🙁", "☹️", "😣", "😖", "😫", "😩", "🥺", "😢", "😭", "😤", "😠", "😡", "🤬",
    "🤯", "😳", "🥵", "🥶", "😱", "😨", "😰", "😥", "😓", "🤗", "🤔", "🫣", "🤭", "🫢", "🤫", "🤥",
    "😶", "🫠", "😐", "🫤", "😑", "😬", "🙄", "😯", "😦", "😧", "😮", "😲", "🥱", "😴", "🤤", "😪",
    "😮‍💨", "😵", "😵‍💫", "🤐", "🥴", "🤢", "🤮", "🤧", "😷", "🤒", "🤕", "🤑", "🤠", "😈", "👿", "👹",
    "👺", "💀", "☠️", "👻", "👽", "🤖", "🎃", "😺", "😸", "😹", "😻", "😼", "😽", "🙀", "😿", "😾",
    "👋", "🤚", "🖐️", "✋", "🖖", "👌", "🤌", "🤏", "✌️", "🤞", "🫰", "🤟", "🤘", "🤙", "👈", "👉",
    "👆", "🖕", "👇", "☝️", "👍", "👎", "👊", "✊", "🤛", "🤜", "👏", "🙌", "🫶", "👐", "🤲", "🙏",
    "✍️", "💪", "🦾", "🫱", "🫲", "💅", "👂", "🦻", "👃", "🧠", "🫀", "🫁", "🦷", "🦴", "👀", "👁️",
    "❤️", "🧡", "💛", "💚", "💙", "🩵", "💜", "🩷", "🖤", "🩶", "🤍", "🤎", "💔", "❣️", "💕", "💞",
    "💓", "💗", "💖", "💘", "💝", "💯", "💢", "💥", "💫", "💦", "💨", "🕳️", "💬", "🗨️", "🗯️", "💭",
    "🔥", "✨", "⭐", "🌟", "⚡", "💡", "🎉", "🎊", "🎈", "🎁", "🏆", "🏅", "🥇", "🥈", "🥉", "⚽",
    "🏏", "🏀", "🏐", "🎮", "🎧", "🎵", "🎶", "📢", "📣", "📌", "📎", "✅", "❌", "✔️", "➕", "➖",
    "🚀", "🛠️", "💻", "⌨️", "🖥️", "📱", "☎️", "📞", "📷", "📸", "☕", "🍕", "🍔", "🍟", "🍿", "🍫",
    "🍩", "🍪", "🍰", "🧁", "🍎", "🍉", "🍇", "🥭", "🍌", "🥥", "🌈", "☀️", "🌤️", "⛅", "🌧️", "⛈️"
];

const usernameInput = document.getElementById("username");
const messageInput = document.getElementById("msg");
const mediaInput = document.getElementById("media-input");
const maxMediaFileSizeBytes = 50 * 1024 * 1024;
const messages = document.getElementById("messages");
const chatDatePill = document.getElementById("chat-date-pill");
const loginError = document.getElementById("login-error");
const statusText = document.getElementById("status-text");
const activeCount = document.getElementById("active-count");
const typingIndicator = document.getElementById("typing-indicator");
const mentionList = document.getElementById("mention-list");
const emojiPicker = document.getElementById("emoji-picker");
const messageMenu = document.getElementById("message-menu");
const replyBox = document.getElementById("reply-box");
const replyPreview = document.getElementById("reply-preview");
const usernamePill = document.getElementById("username-pill");
const joinButton = document.getElementById("join-btn");
const sendButton = document.getElementById("send-btn");
const roomTitle = document.getElementById("room-title");
const roomSummary = document.getElementById("room-summary");
const generalRoomButton = document.getElementById("general-room-btn");
const leaveRoomButton = document.getElementById("leave-room-btn");
const privateRoomList = document.getElementById("private-room-list");
const privateRoomEmpty = document.getElementById("private-room-empty");
const privateRoomCount = document.getElementById("private-room-count");

document.addEventListener("visibilitychange", resetUnreadIfVisible);
window.addEventListener("focus", resetUnreadIfVisible);
window.addEventListener("beforeunload", persistReconnectWindow);
document.addEventListener("click", handleGlobalClick);
document.addEventListener("keydown", handleGlobalEscape);
messages.addEventListener("scroll", updateDatePill);
messages.addEventListener("scroll", clearUnreadDividerIfAtBottom);

usernameInput.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
        join();
    }
});

messageInput.addEventListener("keydown", (event) => {
    if (event.key === "Enter" && !event.shiftKey) {
        event.preventDefault();
        sendMsg();
        return;
    }

    sendTypingSignal();
});

messageInput.addEventListener("input", () => {
    resizeMessageInput();
    renderMentionSuggestions();
    hideMessageMenu();
});

mediaInput.addEventListener("change", sendSelectedMedia);

bootstrapSession();
renderEmojiPicker();

function bootstrapSession() {
    const stored = readStoredSession();
    if (!stored) {
        return;
    }

    usernameInput.value = stored.username;
    reconnectToken = stored.token;
    connect(stored.username);
}

function join() {
    const proposedName = usernameInput.value.trim().replace(/\s+/g, " ");

    if (!proposedName) {
        showLoginError("Enter a username to join.");
        return;
    }

    if (joined) {
        return;
    }

    reconnectToken = reconnectToken || createReconnectToken();
    connect(proposedName);
}

function connect(proposedName) {
    loginError.textContent = "";
    joinButton.disabled = true;
    statusText.textContent = "Connecting...";
    manualLogout = false;

    ws = new WebSocket(`${websocketProtocol}//${location.host}/chatapp/chat`);

    ws.onopen = () => {
        ws.send(`JOIN::${proposedName}::${reconnectToken}`);
        ws.send("LIST_ROOMS");
    };

    ws.onmessage = (event) => {
        const parts = event.data.split("::");
        const type = parts[0];

        if (type === "ERROR") {
            handleJoinFailure(parts.slice(1).join("::"));
            return;
        }

        if (type === "JOINED") {
            username = parts[1];
            joined = true;
            currentRoom = parts[2] || "General";
            showChat();
            usernamePill.textContent = username;
            statusText.textContent = "Connected";
            persistSession();
            updateRoomState(currentRoom);
            return;
        }

        if (type === "SERVER_TIME") {
            serverTimeOffset = Date.now() - Number(parts[1] || Date.now());
            return;
        }

        if (type === "ROOMS") {
            generalCount = Number(parts[1] || 0);
            privateRooms = parseRooms(parts.slice(2).join("::"));
            renderRoomList();
            updateRoomState(currentRoom);
            return;
        }

        if (type === "ONLINE_USERS") {
            if ((parts[1] || "") === currentRoom) {
                roomUsers = parseOnlineUsers(parts[2] || "");
                renderMentionSuggestions();
            }
            return;
        }

        if (type === "ROOM_JOINED") {
            updateRoomState(parts[1] || "General");
            roomUsers = [];
            clearMessages();
            clearReply();
            hideTypingIndicator();
            hideMentionSuggestions();
            hideEmojiPicker();
            hideMessageMenu();
            return;
        }

        if (type === "HISTORY") {
            renderHistory(parts[1], parts[2] || "");
            return;
        }

        if (type === "SYSTEM") {
            appendSystemMessage(parts.slice(2).join("::"), Number(parts[1] || Date.now()), true);
            return;
        }

        if (type === "CHAT") {
            appendChatMessage(parts[2], parts[3], Number(parts[4] || Date.now()), parts.slice(5).join("::"), true);
            hideTypingIndicator();
            return;
        }

        if (type === "PRIVATE_CHAT") {
            appendPrivateChatMessage(parts[2], parts[3], parts[4], Number(parts[5] || Date.now()), parts.slice(6).join("::"), true);
            hideTypingIndicator();
            return;
        }

        if (type === "TYPING") {
            if ((parts[1] || "") === currentRoom && (parts[2] || "") !== username) {
                showTypingIndicator(parts[2]);
            }
        }
    };

    ws.onclose = () => {
        sendButton.disabled = true;
        joinButton.disabled = false;

        if (manualLogout) {
            resetToLoggedOutState();
            return;
        }

        if (joined) {
            statusText.textContent = "Disconnected. Waiting for reconnect window.";
            appendSystemMessage("Connection closed. Reopen within 30 seconds to resume.", Date.now(), false);
        }

        joined = false;
    };
}

function sendMsg() {
    const message = messageInput.value.trim();

    if (!joined || !ws || ws.readyState !== WebSocket.OPEN || !message) {
        return;
    }

    const payload = activeReply ? `[reply:${activeReply}] ${message}` : message;
    ws.send(payload);
    messageInput.value = "";
    resizeMessageInput();
    clearReply();
    hideMentionSuggestions();
    hideEmojiPicker();
    messageInput.focus();
}

function openMediaPicker() {
    if (!joined || !ws || ws.readyState !== WebSocket.OPEN) {
        return;
    }

    mediaInput.click();
}

function sendSelectedMedia() {
    const file = mediaInput.files && mediaInput.files[0];
    mediaInput.value = "";

    if (!file) {
        return;
    }

    if (file.size > maxMediaFileSizeBytes) {
        appendSystemMessage("File is too large. Choose one below 50 MB.", Date.now(), false);
        return;
    }

    const reader = new FileReader();
    reader.onload = () => {
        const dataUrl = String(reader.result || "");
        if (!dataUrl.startsWith("data:")) {
            appendSystemMessage("That file could not be read.", Date.now(), false);
            return;
        }

        const attachment = encodeAttachment({
            name: file.name || "attachment",
            type: file.type || "application/octet-stream",
            size: file.size,
            dataUrl
        });
        const payload = activeReply ? `[reply:${activeReply}] ${attachment}` : attachment;
        ws.send(payload);
        clearReply();
        hideMentionSuggestions();
        hideEmojiPicker();
        messageInput.focus();
    };
    reader.onerror = () => appendSystemMessage("That file could not be read.", Date.now(), false);
    reader.readAsDataURL(file);
}

function logout() {
    manualLogout = true;
    clearStoredSession();

    if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send("LOGOUT");
        return;
    }

    resetToLoggedOutState();
}

function openPictionary() {
    if (!joined || !username || !reconnectToken) {
        appendSystemMessage("Join chat before launching Pictionary.", Date.now(), false);
        return;
    }

    const launchUrl = `${location.origin}/chatapp/pictionary-launch?username=${encodeURIComponent(username)}&token=${encodeURIComponent(reconnectToken)}`;
    window.open(launchUrl, "_blank");
}

function sendTypingSignal() {
    if (!joined || !ws || ws.readyState !== WebSocket.OPEN || !messageInput.value.trim()) {
        return;
    }

    if (sentTypingRecently) {
        return;
    }

    ws.send(`TYPING::${currentRoom}`);
    sentTypingRecently = true;

    window.setTimeout(() => {
        sentTypingRecently = false;
    }, 1200);
}

function requestRooms() {
    if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send("LIST_ROOMS");
    }
}

function joinPrivateRoom(roomName) {
    if (!joined || !ws || ws.readyState !== WebSocket.OPEN) {
        return;
    }

    const password = prompt(`Enter password for ${roomName}`);
    if (password === null) {
        return;
    }

    ws.send(`JOIN_ROOM::${roomName}::${password}`);
}

function leavePrivateRoom() {
    if (!joined || !ws || ws.readyState !== WebSocket.OPEN || currentRoom === "General") {
        return;
    }

    ws.send("LEAVE_ROOM");
}

function showChat() {
    document.getElementById("login").classList.add("hidden");
    document.getElementById("chat-container").classList.remove("hidden");
    sendButton.disabled = false;
}

function resetToLoggedOutState() {
    username = "";
    joined = false;
    reconnectToken = "";
    activeReply = "";
    selectedReplyPreview = "";
    roomUsers = [];
    hideTypingIndicator();
    hideMentionSuggestions();
    hideEmojiPicker();
    hideMessageMenu();
    clearMessages();
    clearReply();
    document.getElementById("chat-container").classList.add("hidden");
    document.getElementById("login").classList.remove("hidden");
    usernamePill.textContent = "";
    statusText.textContent = "Logged out";
    loginError.textContent = "";
    messageInput.value = "";
    resizeMessageInput();
    document.title = baseTitle;
}

function showLoginError(message) {
    loginError.textContent = message;
    joinButton.disabled = false;
}

function handleJoinFailure(message) {
    if (!joined) {
        clearStoredSession();
        reconnectToken = "";
        showLoginError(message);
    } else {
        appendSystemMessage(message, Date.now(), false);
    }

    statusText.textContent = joined ? statusText.textContent : "Not connected";

    if (!joined && ws && ws.readyState === WebSocket.OPEN) {
        ws.close();
    }
}

function updateRoomState(roomName) {
    currentRoom = roomName;
    const isGeneral = roomName === "General";
    const currentRoomEntry = privateRooms.find((room) => room.name === roomName);
    const currentCount = isGeneral
        ? generalCount
        : (currentRoomEntry ? currentRoomEntry.count : 0);

    roomTitle.textContent = isGeneral ? "General Chat" : roomName;
    roomSummary.textContent = isGeneral
        ? "General room is open to everyone."
        : `Private room ${roomName} is active.`;
    activeCount.textContent = `${currentCount} active user${currentCount === 1 ? "" : "s"}`;
    generalRoomButton.classList.toggle("active", isGeneral);
    generalRoomButton.textContent = `General Chat (${generalCount})`;
    leaveRoomButton.classList.toggle("hidden", isGeneral);
    renderRoomList();
}

function renderRoomList() {
    privateRoomList.innerHTML = "";
    privateRoomCount.textContent = `${privateRooms.length}/10`;
    privateRoomEmpty.classList.toggle("hidden", privateRooms.length > 0);

    privateRooms.forEach((room) => {
        const button = document.createElement("button");
        button.type = "button";
        button.className = `room-link ${room.name === currentRoom ? "active" : ""}`;
        button.textContent = `${room.name} (${room.count})`;
        button.onclick = () => joinPrivateRoom(room.name);
        privateRoomList.appendChild(button);
    });
}

function parseRooms(rawRooms) {
    if (!rawRooms) {
        return [];
    }

    return rawRooms.split(",")
        .filter(Boolean)
        .map((entry) => {
            const [name, count] = entry.split("|");
            return { name, count: Number(count || 0) };
        });
}

function parseOnlineUsers(rawUsers) {
    if (!rawUsers) {
        return [];
    }

    return rawUsers.split(",").filter(Boolean);
}

function renderHistory(roomName, encodedEntries) {
    if (roomName !== currentRoom) {
        return;
    }

    clearMessages();
    hideTypingIndicator();
    hideMessageMenu();

    if (!encodedEntries) {
            appendSystemMessage(`No previous messages in ${roomName}.`, Date.now(), false);
            return;
        }

    encodedEntries.split(",").filter(Boolean).forEach((encoded) => {
        const decoded = decodeBase64(encoded);
        const parts = decoded.split("::");
        const type = parts[0];

        if (type === "SYSTEM") {
            appendSystemMessage(parts.slice(2).join("::"), Number(parts[1] || Date.now()), false);
            return;
        }

        if (type === "CHAT") {
            appendChatMessage(parts[2], parts[3], Number(parts[4] || Date.now()), parts.slice(5).join("::"), false);
            return;
        }

        if (type === "PRIVATE_CHAT") {
            appendPrivateChatMessage(parts[2], parts[3], parts[4], Number(parts[5] || Date.now()), parts.slice(6).join("::"), false);
        }
    });
}

function clearMessages() {
    messages.innerHTML = "";
    chatDatePill.classList.add("hidden");
    chatDatePill.textContent = "";
    unreadDivider = null;
}

function appendSystemMessage(message, timestamp, countUnread) {
    const shouldScroll = isNearLatest();
    const shouldMarkUnread = countUnread && (document.hidden || !shouldScroll);
    insertDateSeparatorIfNeeded(timestamp);
    if (shouldMarkUnread) {
        insertUnreadDivider(timestamp);
    }
    const div = document.createElement("div");
    div.className = "system-message";
    div.textContent = message;
    div.dataset.timestamp = String(timestamp);
    div.dataset.dateKey = getDateKey(timestamp);
    messages.appendChild(div);
    finishMessageAppend(shouldScroll && !document.hidden);
    maybeIncreaseUnread(countUnread);
}

function appendChatMessage(user, replyTo, timestamp, text, countUnread) {
    const fromSelf = user === username;
    const shouldScroll = fromSelf || isNearLatest();
    const shouldMarkUnread = countUnread && !fromSelf && (document.hidden || !shouldScroll);
    if (shouldMarkUnread) {
        insertDateSeparatorIfNeeded(timestamp);
        insertUnreadDivider(timestamp);
    }
    const div = createMessageBubble(user, replyTo, timestamp, text, false);
    messages.appendChild(div);
    finishMessageAppend(shouldScroll && (!document.hidden || fromSelf));
    if (!fromSelf) {
        maybeIncreaseUnread(countUnread);
    }
}

function appendPrivateChatMessage(sender, recipients, replyTo, timestamp, text, countUnread) {
    const fromSelf = sender === username;
    const shouldScroll = fromSelf || isNearLatest();
    const shouldMarkUnread = countUnread && !fromSelf && (document.hidden || !shouldScroll);
    if (shouldMarkUnread) {
        insertDateSeparatorIfNeeded(timestamp);
        insertUnreadDivider(timestamp);
    }
    const div = createMessageBubble(sender, replyTo, timestamp, text, true);
    const tag = document.createElement("div");
    tag.className = "private-tag";
    tag.textContent = `Private to ${recipients}`;
    div.insertBefore(tag, div.firstChild);
    messages.appendChild(div);
    finishMessageAppend(shouldScroll && (!document.hidden || fromSelf));
    if (!fromSelf) {
        maybeIncreaseUnread(countUnread);
    }
}

function createMessageBubble(user, replyTo, timestamp, text, isPrivate) {
    insertDateSeparatorIfNeeded(timestamp);
    const wrapper = document.createElement("div");
    wrapper.className = `message ${user === username ? "right" : "left"}${isPrivate ? " private-message" : ""}`;
    wrapper.dataset.replyPreview = `${user}: ${isAttachmentMessage(text) ? "Attachment" : text}`.slice(0, 120);
    wrapper.dataset.timestamp = String(timestamp);
    wrapper.dataset.dateKey = getDateKey(timestamp);

    if (replyTo) {
        const reply = document.createElement("div");
        reply.className = "reply-quote";
        reply.textContent = replyTo;
        wrapper.appendChild(reply);
    }

    const body = document.createElement("div");
    body.className = "message-body";
    renderMessageBody(body, user, text);
    wrapper.appendChild(body);

    const timeTag = document.createElement("div");
    timeTag.className = "message-time";
    timeTag.textContent = formatTime(timestamp);
    wrapper.appendChild(timeTag);

    wrapper.addEventListener("contextmenu", (event) => openMessageMenu(event, wrapper.dataset.replyPreview));

    return wrapper;
}

function renderMessageBody(body, user, text) {
    const author = document.createElement("strong");
    author.className = "message-author";
    author.textContent = `${user}:`;
    body.appendChild(author);

    if (isAttachmentMessage(text)) {
        const attachment = parseAttachment(text);
        if (!attachment) {
            body.appendChild(document.createTextNode(" Attachment could not be displayed."));
            return;
        }

        const dataUrl = attachment.dataUrl;
        const mediaType = attachment.type || getMediaType(dataUrl);
        const fileName = attachment.name || "attachment";
        if (mediaType.startsWith("image/")) {
            const image = document.createElement("img");
            image.className = "chat-image";
            image.src = dataUrl;
            image.alt = fileName;
            image.loading = "lazy";
            image.onclick = () => openMediaViewer(attachment);
            image.tabIndex = 0;
            body.appendChild(image);
            body.appendChild(createAttachmentActions(attachment, "Open image"));
            return;
        }

        if (mediaType.startsWith("video/")) {
            const video = document.createElement("video");
            video.className = "chat-media";
            video.src = dataUrl;
            video.controls = true;
            body.appendChild(video);
            body.appendChild(createAttachmentActions(attachment, "Open media"));
            return;
        }

        if (mediaType.startsWith("audio/")) {
            const audio = document.createElement("audio");
            audio.className = "chat-audio";
            audio.src = dataUrl;
            audio.controls = true;
            body.appendChild(audio);
            body.appendChild(createAttachmentActions(attachment, "Open media"));
            return;
        }

        body.appendChild(createFileCard(attachment));
        return;
    }

    body.appendChild(document.createTextNode(` ${text}`));
}

function isAttachmentMessage(text) {
    return typeof text === "string"
        && ((text.startsWith("[file:") && text.endsWith("]"))
            || ((text.startsWith("[media:data:") || text.startsWith("[image:data:image/")) && text.includes(";base64,")));
}

function encodeAttachment(attachment) {
    return `[file:${window.btoa(unescape(encodeURIComponent(JSON.stringify(attachment))))}]`;
}

function parseAttachment(text) {
    if (text.startsWith("[file:") && text.endsWith("]")) {
        try {
            const json = decodeURIComponent(escape(window.atob(text.slice(6, -1))));
            const parsed = JSON.parse(json);
            if (!parsed.dataUrl || !parsed.dataUrl.startsWith("data:")) {
                return null;
            }
            return {
                name: parsed.name || "attachment",
                type: parsed.type || getMediaType(parsed.dataUrl) || "application/octet-stream",
                size: Number(parsed.size || 0),
                dataUrl: parsed.dataUrl
            };
        } catch (error) {
            return null;
        }
    }

    const raw = text.slice(7);
    const dataUrl = raw.endsWith("]") ? raw.slice(0, -1) : raw;
    return {
        name: getDefaultAttachmentName(getMediaType(dataUrl)),
        type: getMediaType(dataUrl),
        size: 0,
        dataUrl
    };
}

function createAttachmentActions(attachment, openLabel) {
    const actions = document.createElement("div");
    actions.className = "attachment-actions";
    actions.appendChild(createOpenAttachmentButton(attachment, openLabel));
    actions.appendChild(createDownloadButton(attachment));
    return actions;
}

function createOpenAttachmentButton(attachment, label) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "attachment-btn";
    button.textContent = label;
    button.onclick = () => openMediaViewer(attachment);
    return button;
}

function createDownloadButton(attachment) {
    const link = document.createElement("a");
    link.className = "attachment-btn attachment-download";
    link.href = createAttachmentObjectUrl(attachment);
    link.download = attachment.name || "attachment";
    link.textContent = "Download";
    return link;
}

function createFileCard(attachment) {
    const card = document.createElement("div");
    card.className = "file-card";

    const icon = document.createElement("div");
    icon.className = "file-icon";
    icon.textContent = getFileBadge(attachment);

    const details = document.createElement("div");
    details.className = "file-details";

    const name = document.createElement("strong");
    name.textContent = attachment.name || "attachment";

    const meta = document.createElement("span");
    meta.textContent = `${attachment.type || "file"}${attachment.size ? ` - ${formatFileSize(attachment.size)}` : ""}`;

    details.appendChild(name);
    details.appendChild(meta);
    card.appendChild(icon);
    card.appendChild(details);
    card.appendChild(createAttachmentActions(attachment, "Open"));
    return card;
}

function openMediaViewer(attachment) {
    const objectUrl = createAttachmentObjectUrl(attachment);
    const opened = window.open(objectUrl, "_blank");
    if (opened) {
        return;
    }

    openFallbackViewer(attachment);
}

function openFallbackViewer(attachment) {
    const win = window.open("", "_blank");
    if (!win) {
        return;
    }

    const dataUrl = attachment.dataUrl;
    const mediaType = attachment.type || getMediaType(dataUrl);
    const fileName = escapeHtml(attachment.name || "attachment");
    const safeTitle = mediaType.startsWith("image/") ? "Image" : "Attachment";
    const download = `<a class="download" href="${dataUrl}" download="${fileName}">Download</a>`;
    let content = `<div class="file-open">${download}<p>${fileName}</p></div>`;
    if (mediaType.startsWith("image/")) {
        content = `<img src="${dataUrl}" alt="${fileName}">${download}`;
    } else if (mediaType.startsWith("video/")) {
        content = `<video src="${dataUrl}" controls autoplay></video>${download}`;
    } else if (mediaType.startsWith("audio/")) {
        content = `<audio src="${dataUrl}" controls autoplay></audio>${download}`;
    } else if (mediaType === "application/pdf") {
        content = `<iframe src="${dataUrl}" title="${fileName}"></iframe>${download}`;
    }

    win.document.write(`<!DOCTYPE html><html><head><title>${safeTitle}</title><style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#111;color:#fff;font-family:sans-serif;padding:18px}img,video{max-width:96vw;max-height:90vh}audio{width:min(720px,92vw)}iframe{width:96vw;height:88vh;border:0;background:#fff}.download{position:fixed;right:18px;bottom:18px;color:#111;background:#fff;padding:10px 14px;border-radius:10px;text-decoration:none;font-weight:700}.file-open{text-align:center}</style></head><body>${content}</body></html>`);
    win.document.close();
}

function createAttachmentObjectUrl(attachment) {
    try {
        const blob = dataUrlToBlob(attachment.dataUrl, attachment.type);
        return URL.createObjectURL(blob);
    } catch (error) {
        return attachment.dataUrl;
    }
}

function dataUrlToBlob(dataUrl, fallbackType) {
    const [header, encoded] = dataUrl.split(",");
    const typeMatch = /^data:([^;]+)/.exec(header || "");
    const mimeType = fallbackType || (typeMatch ? typeMatch[1] : "application/octet-stream");
    const binary = window.atob(encoded || "");
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i += 1) {
        bytes[i] = binary.charCodeAt(i);
    }
    return new Blob([bytes], { type: mimeType });
}

function getMediaType(dataUrl) {
    const match = /^data:([^;,]+)/.exec(dataUrl);
    return match ? match[1] : "";
}

function getDefaultAttachmentName(mediaType) {
    if (mediaType.startsWith("image/")) {
        return "image";
    }
    if (mediaType.startsWith("video/")) {
        return "video";
    }
    if (mediaType.startsWith("audio/")) {
        return "audio";
    }
    return "attachment";
}

function getFileBadge(attachment) {
    const type = attachment.type || "";
    const name = attachment.name || "";
    if (type === "application/pdf" || name.toLowerCase().endsWith(".pdf")) {
        return "PDF";
    }
    if (name.toLowerCase().endsWith(".doc") || name.toLowerCase().endsWith(".docx")) {
        return "DOC";
    }
    if (name.toLowerCase().endsWith(".xls") || name.toLowerCase().endsWith(".xlsx")) {
        return "XLS";
    }
    if (name.toLowerCase().endsWith(".ppt") || name.toLowerCase().endsWith(".pptx")) {
        return "PPT";
    }
    return "FILE";
}

function formatFileSize(size) {
    if (size < 1024) {
        return `${size} B`;
    }
    if (size < 1024 * 1024) {
        return `${Math.round(size / 1024)} KB`;
    }
    return `${(size / (1024 * 1024)).toFixed(1)} MB`;
}

function openMessageMenu(event, preview) {
    event.preventDefault();
    selectedReplyPreview = preview;
    const bubbleRect = event.currentTarget.getBoundingClientRect();
    const menuWidth = 160;
    const menuHeight = 58;
    const bubbleOnRight = event.currentTarget.classList.contains("right");
    const preferredLeft = bubbleOnRight ? bubbleRect.right - menuWidth : bubbleRect.left;
    const spaceBelow = window.innerHeight - bubbleRect.bottom;
    const placeBelow = spaceBelow >= menuHeight + 16;
    const preferredTop = placeBelow ? bubbleRect.bottom + 8 : bubbleRect.top - menuHeight - 8;
    const left = Math.max(12, Math.min(preferredLeft, window.innerWidth - menuWidth - 12));
    const top = Math.max(12, Math.min(preferredTop, window.innerHeight - menuHeight - 12));

    messageMenu.style.left = `${left}px`;
    messageMenu.style.top = `${top}px`;
    messageMenu.dataset.caret = bubbleOnRight ? "right" : "left";
    messageMenu.dataset.vertical = placeBelow ? "top" : "bottom";
    messageMenu.classList.remove("hidden");
}

function replyFromMenu() {
    if (!selectedReplyPreview) {
        return;
    }

    startReply(selectedReplyPreview);
    hideMessageMenu();
}

function hideMessageMenu() {
    messageMenu.classList.add("hidden");
    messageMenu.dataset.caret = "";
    messageMenu.dataset.vertical = "";
    selectedReplyPreview = "";
}

function startReply(preview) {
    activeReply = preview.slice(0, 120);
    replyPreview.textContent = activeReply;
    replyBox.classList.remove("hidden");
    messageInput.focus();
}

function clearReply() {
    activeReply = "";
    replyPreview.textContent = "";
    replyBox.classList.add("hidden");
}

function renderEmojiPicker() {
    emojiPicker.innerHTML = "";

    emojiCatalog.forEach((emoji) => {
        const button = document.createElement("button");
        button.type = "button";
        button.className = "emoji-item";
        button.textContent = emoji;
        button.onclick = () => insertEmoji(emoji);
        emojiPicker.appendChild(button);
    });
}

function toggleEmojiPicker() {
    emojiPicker.classList.toggle("hidden");
    hideMessageMenu();
    if (!emojiPicker.classList.contains("hidden")) {
        hideMentionSuggestions();
    }
}

function hideEmojiPicker() {
    emojiPicker.classList.add("hidden");
}

function insertEmoji(emoji) {
    messageInput.value += emoji;
    resizeMessageInput();
    messageInput.focus();
}

function showTypingIndicator(name) {
    typingIndicator.textContent = `${name} is typing...`;
    typingIndicator.classList.remove("hidden");

    if (typingTimer) {
        window.clearTimeout(typingTimer);
    }

    typingTimer = window.setTimeout(() => {
        hideTypingIndicator();
    }, 1600);
}

function hideTypingIndicator() {
    typingIndicator.classList.add("hidden");
    typingIndicator.textContent = "";
    if (typingTimer) {
        window.clearTimeout(typingTimer);
        typingTimer = null;
    }
}

function renderMentionSuggestions() {
    const value = messageInput.value;
    const state = getMentionState(value);

    if (!state) {
        hideMentionSuggestions();
        return;
    }

    const matchingUsers = roomUsers
        .filter((name) => name !== username)
        .filter((name) => !state.selected.includes(name))
        .filter((name) => name.toLowerCase().startsWith(state.partial.toLowerCase()));

    if (matchingUsers.length === 0) {
        hideMentionSuggestions();
        return;
    }

    mentionList.innerHTML = "";
    mentionList.classList.remove("hidden");

    matchingUsers.forEach((name) => {
        const button = document.createElement("button");
        button.type = "button";
        button.className = "mention-item";
        button.textContent = name;
        button.onclick = () => applyMention(name, state.prefix);
        mentionList.appendChild(button);
    });
}

function getMentionState(value) {
    if (!value.startsWith("@")) {
        return null;
    }

    const tokens = value.split(" ");
    const selected = [];

    for (let i = 0; i < tokens.length; i += 1) {
        const token = tokens[i];
        if (token.startsWith("@")) {
            const clean = token.slice(1).trim();
            if (i < tokens.length - 1 && clean) {
                selected.push(clean);
                continue;
            }

            return {
                prefix: tokens.slice(0, i).filter(Boolean).join(" "),
                partial: clean,
                selected
            };
        }

        return null;
    }

    return null;
}

function applyMention(name, prefix) {
    const nextValue = prefix ? `${prefix} @${name} ` : `@${name} `;
    messageInput.value = nextValue;
    resizeMessageInput();
    messageInput.focus();
    hideMentionSuggestions();
}

function hideMentionSuggestions() {
    mentionList.classList.add("hidden");
    mentionList.innerHTML = "";
}

function handleGlobalClick(event) {
    if (!event.target.closest("#emoji-picker") && !event.target.closest("#emoji-btn")) {
        hideEmojiPicker();
    }

    if (!event.target.closest("#message-menu")) {
        hideMessageMenu();
    }
}

function handleGlobalEscape(event) {
    if (event.key !== "Escape") {
        return;
    }

    hideEmojiPicker();
    hideMentionSuggestions();
    hideMessageMenu();
}

function maybeIncreaseUnread(shouldCount) {
    if (!shouldCount || !document.hidden) {
        return;
    }

    unreadCount += 1;
    document.title = `(${unreadCount}) ${baseTitle}`;
}

function resetUnreadIfVisible() {
    if (document.hidden) {
        return;
    }

    unreadCount = 0;
    document.title = baseTitle;
}

function resizeMessageInput() {
    messageInput.style.height = "auto";
    messageInput.style.height = `${Math.min(messageInput.scrollHeight, 140)}px`;
}

function persistSession() {
    localStorage.setItem(storageKey, JSON.stringify({
        username,
        token: reconnectToken,
        expiresAt: Date.now() + reconnectGraceMs
    }));
}

function persistReconnectWindow() {
    if (!username || manualLogout) {
        clearStoredSession();
        return;
    }

    persistSession();
}

function readStoredSession() {
    try {
        const raw = localStorage.getItem(storageKey);
        if (!raw) {
            return null;
        }

        const parsed = JSON.parse(raw);
        if (!parsed.username || !parsed.token || !parsed.expiresAt) {
            clearStoredSession();
            return null;
        }

        if (Date.now() > Number(parsed.expiresAt)) {
            clearStoredSession();
            return null;
        }

        return parsed;
    } catch (error) {
        clearStoredSession();
        return null;
    }
}

function clearStoredSession() {
    localStorage.removeItem(storageKey);
}

function createReconnectToken() {
    if (window.crypto && window.crypto.randomUUID) {
        return window.crypto.randomUUID();
    }

    return `token-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function decodeBase64(value) {
    const binary = window.atob(value);
    let encoded = "";

    for (let i = 0; i < binary.length; i += 1) {
        encoded += `%${(`00${binary.charCodeAt(i).toString(16)}`).slice(-2)}`;
    }

    try {
        return decodeURIComponent(encoded);
    } catch (error) {
        return binary;
    }
}

function scrollToLatest() {
    messages.scrollTop = messages.scrollHeight;
    updateDatePill();
}

function finishMessageAppend(shouldScroll) {
    if (shouldScroll) {
        scrollToLatest();
        return;
    }

    updateDatePill();
}

function isNearLatest() {
    return messages.scrollHeight - messages.scrollTop - messages.clientHeight < 90;
}

function insertUnreadDivider(timestamp) {
    if (unreadDivider) {
        return;
    }

    unreadDivider = document.createElement("div");
    unreadDivider.className = "unread-divider";
    unreadDivider.textContent = "New messages";
    unreadDivider.dataset.timestamp = String(timestamp);
    unreadDivider.dataset.dateKey = getDateKey(timestamp);
    messages.appendChild(unreadDivider);
}

function clearUnreadDividerIfAtBottom() {
    if (!unreadDivider || !isNearLatest()) {
        return;
    }

    unreadDivider.remove();
    unreadDivider = null;
}

function insertDateSeparatorIfNeeded(timestamp) {
    const dateKey = getDateKey(timestamp);
    const lastDatedNode = Array.from(messages.children).reverse().find((node) => node.dataset && node.dataset.dateKey);

    if (lastDatedNode && lastDatedNode.dataset.dateKey === dateKey) {
        return;
    }

    const separator = document.createElement("div");
    separator.className = "date-separator";
    separator.textContent = formatDateLabel(timestamp);
    separator.dataset.timestamp = String(timestamp);
    separator.dataset.dateKey = dateKey;
    messages.appendChild(separator);
}

function updateDatePill() {
    const datedNodes = Array.from(messages.children).filter((node) => node.dataset && node.dataset.dateKey);
    if (datedNodes.length === 0) {
        chatDatePill.classList.add("hidden");
        return;
    }

    const scrollTop = messages.scrollTop;
    let current = datedNodes[0];

    for (let i = 0; i < datedNodes.length; i += 1) {
        if (datedNodes[i].offsetTop - 12 <= scrollTop) {
            current = datedNodes[i];
        } else {
            break;
        }
    }

    chatDatePill.textContent = formatDateLabel(Number(current.dataset.timestamp || Date.now()));
    chatDatePill.classList.remove("hidden");
}

function getDateKey(timestamp) {
    const date = new Date(timestamp);
    return `${date.getFullYear()}-${date.getMonth()}-${date.getDate()}`;
}

function formatTime(timestamp) {
    return new Date(applyClientClock(timestamp)).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

function formatDateLabel(timestamp) {
    return new Date(applyClientClock(timestamp)).toLocaleDateString([], {
        day: "numeric",
        month: "long",
        year: "numeric"
    });
}

function applyClientClock(timestamp) {
    return Number(timestamp) + serverTimeOffset;
}
