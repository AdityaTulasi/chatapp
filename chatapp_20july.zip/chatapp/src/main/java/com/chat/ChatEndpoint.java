package com.chat;

import javax.websocket.OnClose;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;

@ServerEndpoint(value = "/chat", configurator = ChatEndpointConfigurator.class)
public class ChatEndpoint {

    private static final int MAX_TEXT_MESSAGE_BYTES = 100 * 1024 * 1024;

    @OnOpen
    public void onOpen(Session session) {
        session.setMaxTextMessageBufferSize(MAX_TEXT_MESSAGE_BYTES);
        ChatManager.addSession(session);
    }

    @OnMessage
    public void onMessage(String message, Session session) {
        if (message == null) {
            return;
        }

        if (message.startsWith("JOIN::")) {
            String[] parts = message.split("::", 3);
            if (parts.length == 3) {
                ChatManager.join(session, parts[1], parts[2]);
            } else {
                session.getAsyncRemote().sendText("ERROR::Join request is incomplete.");
            }
            return;
        }

        if (message.startsWith("JOIN_ROOM::")) {
            String[] parts = message.split("::", 3);
            if (parts.length == 3) {
                ChatManager.joinPrivateRoom(session, parts[1], parts[2]);
            } else {
                session.getAsyncRemote().sendText("ERROR::Private room join request is incomplete.");
            }
            return;
        }

        if (message.startsWith("TYPING::")) {
            ChatManager.handleTyping(session);
            return;
        }

        if ("LEAVE_ROOM".equals(message)) {
            ChatManager.leavePrivateRoom(session);
            return;
        }

        if ("LOGOUT".equals(message)) {
            ChatManager.logout(session);
            return;
        }

        if ("LIST_ROOMS".equals(message)) {
            ChatManager.sendRoomsTo(session);
            return;
        }

        if (message.startsWith("/admin")) {
            handleAdminCommand(message, session);
            return;
        }

        if (message.startsWith("/super")) {
            handleSuperuserCommand(message, session);
            return;
        }

        ChatManager.handleChat(session, message);
    }

    @OnClose
    public void onClose(Session session) {
        ChatManager.removeSession(session);
    }

    private void handleAdminCommand(String message, Session session) {
        String[] parts = message.split("::", 4);

        if ("/admin users".equals(parts[0]) && parts.length >= 2) {
            ChatManager.sendUsersTo(session, parts[1]);
            return;
        }

        if ("/admin rooms".equals(parts[0]) && parts.length >= 2) {
            ChatManager.sendRoomsToAdmin(session, parts[1]);
            return;
        }

        if ("/admin kick".equals(parts[0]) && parts.length >= 3) {
            ChatManager.kickUser(session, parts[1], parts[2]);
            return;
        }

        if ("/admin create room".equals(parts[0]) && parts.length >= 4) {
            ChatManager.createPrivateRoom(session, parts[1], parts[2], parts[3]);
            return;
        }

        session.getAsyncRemote().sendText("ERROR::Unknown admin command.");
    }

    private void handleSuperuserCommand(String message, Session session) {
        String[] parts = message.split("::", 3);

        if ("/super delete room".equals(parts[0]) && parts.length >= 3) {
            ChatManager.deletePrivateRoom(session, parts[1], parts[2]);
            return;
        }

        session.getAsyncRemote().sendText("ERROR::Unknown superuser command.");
    }
}
