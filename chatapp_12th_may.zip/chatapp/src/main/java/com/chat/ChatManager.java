package com.chat;

import javax.websocket.Session;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Comparator;
import java.util.Deque;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ChatManager {

    public static final String GENERAL_ROOM = "General";
    private static final String ADMIN_PASSWORD = "admin123";
    private static final String SUPERUSER_PASSWORD = "super123";
    private static final int MAX_PRIVATE_ROOMS = 10;
    private static final int HISTORY_LIMIT = 100;
    private static final long RECONNECT_GRACE_MS = 30000L;
    private static final Pattern REPLY_PATTERN = Pattern.compile("^\\[reply:([^\\]]*)\\]\\s*(.*)$", Pattern.DOTALL);

    private static final Map<String, UserSession> USERS_BY_TOKEN = new ConcurrentHashMap<>();
    private static final Map<Session, String> SESSION_TOKENS = new ConcurrentHashMap<>();
    private static final Map<String, ChatRoom> PRIVATE_ROOMS = new ConcurrentHashMap<>();
    private static final Map<String, Deque<String>> ROOM_HISTORY = new ConcurrentHashMap<>();
    private static final ScheduledExecutorService SCHEDULER = Executors.newSingleThreadScheduledExecutor();

    static {
        ROOM_HISTORY.put(GENERAL_ROOM, new ArrayDeque<>());
    }

    private ChatManager() {
    }

    public static void addSession(Session session) {
        send(session, "SERVER_TIME::" + System.currentTimeMillis());
        sendRoomsTo(session);
    }

    public static void removeSession(Session session) {
        String token = SESSION_TOKENS.remove(session);
        if (token == null) {
            return;
        }

        UserSession user = USERS_BY_TOKEN.get(token);
        if (user == null || !session.equals(user.getSession())) {
            return;
        }

        if (Boolean.TRUE.equals(session.getUserProperties().get("logout"))) {
            removeUserCompletely(user);
            return;
        }

        user.setConnected(false);
        user.setSession(null);
        user.setDisconnectDeadline(System.currentTimeMillis() + RECONNECT_GRACE_MS);
        broadcastRooms();
        broadcastOnlineUsersForRoom(user.getCurrentRoom());
        scheduleRemovalIfExpired(token);
    }

    public static void join(Session session, String username, String reconnectToken) {
        cleanupExpiredUsers();

        String cleanUsername = normalize(username);
        String cleanToken = normalize(reconnectToken);

        if (cleanUsername.isEmpty()) {
            send(session, "ERROR::Username is required.");
            return;
        }

        if (cleanToken.isEmpty()) {
            send(session, "ERROR::Reconnect token is required.");
            return;
        }

        if (cleanUsername.length() > 24) {
            send(session, "ERROR::Username must be 24 characters or fewer.");
            return;
        }

        if (!cleanUsername.matches("[A-Za-z0-9_\\- ]+")) {
            send(session, "ERROR::Use letters, numbers, spaces, hyphens, or underscores.");
            return;
        }

        UserSession existing = USERS_BY_TOKEN.get(cleanToken);
        if (existing != null && existing.hasUsername() && existing.getUsername().equals(cleanUsername)) {
            if (existing.isConnected()) {
                send(session, "ERROR::That session is already active.");
                return;
            }

            existing.setSession(session);
            existing.setConnected(true);
            existing.setDisconnectDeadline(0L);
            SESSION_TOKENS.put(session, cleanToken);
            send(session, "JOINED::" + cleanUsername + "::" + existing.getCurrentRoom());
            sendRoomsTo(session);
            sendOnlineUsersForRoom(session, existing.getCurrentRoom());
            sendHistory(session, existing.getCurrentRoom(), existing);
            broadcastRooms();
            broadcastOnlineUsersForRoom(existing.getCurrentRoom());
            return;
        }

        if (isUsernameTaken(cleanUsername, cleanToken)) {
            send(session, "ERROR::That username is already in use.");
            return;
        }

        UserSession user = new UserSession(session, cleanUsername, resolveClientIp(session), GENERAL_ROOM, cleanToken);
        USERS_BY_TOKEN.put(cleanToken, user);
        SESSION_TOKENS.put(session, cleanToken);

        send(session, "JOINED::" + cleanUsername + "::" + GENERAL_ROOM);
        sendRoomsTo(session);
        sendOnlineUsersForRoom(session, GENERAL_ROOM);
        sendHistory(session, GENERAL_ROOM, user);
        broadcastSystemToRoom(GENERAL_ROOM, cleanUsername + " joined the general chat.", true);
        broadcastRooms();
        broadcastOnlineUsersForRoom(GENERAL_ROOM);
    }

    public static void logout(Session session) {
        session.getUserProperties().put("logout", true);
        try {
            session.close();
        } catch (IOException ignored) {
        }
    }

    public static void handleChat(Session session, String message) {
        UserSession user = getConnectedUser(session);

        if (user == null) {
            send(session, "ERROR::Join with a username before chatting.");
            return;
        }

        String cleanMessage = normalize(message);

        if (cleanMessage.isEmpty()) {
            return;
        }

        ReplyData replyData = extractReplyData(cleanMessage);

        if (replyData.getMessage().startsWith("@")) {
            handlePrivateMessage(user, replyData);
            return;
        }

        String payload = "CHAT::" + user.getCurrentRoom() + "::" + user.getUsername() + "::" + replyData.getReplyPreview() + "::" + System.currentTimeMillis() + "::" + replyData.getMessage();
        addToHistory(user.getCurrentRoom(), payload);
        broadcastToRoom(user.getCurrentRoom(), payload);
    }

    public static void handleTyping(Session session) {
        UserSession user = getConnectedUser(session);

        if (user == null) {
            return;
        }

        String payload = "TYPING::" + user.getCurrentRoom() + "::" + user.getUsername();
        for (UserSession target : USERS_BY_TOKEN.values()) {
            if (!target.isConnected() || target.getSession() == null) {
                continue;
            }

            if (target.getReconnectToken().equals(user.getReconnectToken())) {
                continue;
            }

            if (user.getCurrentRoom().equals(target.getCurrentRoom())) {
                send(target.getSession(), payload);
            }
        }
    }

    public static void joinPrivateRoom(Session session, String roomName, String password) {
        UserSession user = getConnectedUser(session);

        if (user == null) {
            send(session, "ERROR::Join the app first before switching rooms.");
            return;
        }

        ChatRoom room = findRoom(roomName);

        if (room == null) {
            send(session, "ERROR::That private room does not exist.");
            return;
        }

        if (!room.matchesPassword(password)) {
            send(session, "ERROR::Wrong password for that private room.");
            return;
        }

        switchRoom(user, room.getName(), true);
    }

    public static void leavePrivateRoom(Session session) {
        UserSession user = getConnectedUser(session);

        if (user == null) {
            send(session, "ERROR::Join the app first before switching rooms.");
            return;
        }

        if (GENERAL_ROOM.equals(user.getCurrentRoom())) {
            send(session, "SYSTEM::You are already in the general chat.");
            return;
        }

        switchRoom(user, GENERAL_ROOM, false);
    }

    public static void sendRoomsTo(Session session) {
        send(session, "ROOMS::" + getGeneralUserCount() + "::" + getRoomsAsString());
    }

    public static void sendOnlineUsersForRoom(Session session, String roomName) {
        send(session, "ONLINE_USERS::" + roomName + "::" + getOnlineUsersAsString(roomName));
    }

    public static void createPrivateRoom(Session session, String adminPassword, String roomName, String roomPassword) {
        if (!ADMIN_PASSWORD.equals(adminPassword)) {
            send(session, "ERROR::Invalid admin password.");
            return;
        }

        String cleanRoomName = normalize(roomName);
        String cleanRoomPassword = normalize(roomPassword);

        if (cleanRoomName.isEmpty() || cleanRoomPassword.isEmpty()) {
            send(session, "ERROR::Room name and room password are required.");
            return;
        }

        if (GENERAL_ROOM.equalsIgnoreCase(cleanRoomName)) {
            send(session, "ERROR::That room name is reserved.");
            return;
        }

        if (cleanRoomName.length() > 30) {
            send(session, "ERROR::Room name must be 30 characters or fewer.");
            return;
        }

        if (!cleanRoomName.matches("[A-Za-z0-9_\\- ]+")) {
            send(session, "ERROR::Room name can use letters, numbers, spaces, hyphens, or underscores.");
            return;
        }

        if (cleanRoomPassword.length() > 30) {
            send(session, "ERROR::Room password must be 30 characters or fewer.");
            return;
        }

        synchronized (PRIVATE_ROOMS) {
            if (PRIVATE_ROOMS.size() >= MAX_PRIVATE_ROOMS) {
                send(session, "ERROR::Only 10 private chatrooms can exist at a time.");
                return;
            }

            if (findRoom(cleanRoomName) != null) {
                send(session, "ERROR::That private room already exists.");
                return;
            }

            PRIVATE_ROOMS.put(cleanRoomName, new ChatRoom(cleanRoomName, cleanRoomPassword));
            ROOM_HISTORY.put(cleanRoomName, new ArrayDeque<>());
        }

        send(session, "ADMIN_OK::Private room created.");
        broadcastRooms();
    }

    public static void deletePrivateRoom(Session session, String superuserPassword, String roomName) {
        if (!SUPERUSER_PASSWORD.equals(superuserPassword)) {
            send(session, "ERROR::Invalid superuser password.");
            return;
        }

        ChatRoom room;
        synchronized (PRIVATE_ROOMS) {
            room = findRoom(roomName);
            if (room == null) {
                send(session, "ERROR::That private room does not exist.");
                return;
            }

            PRIVATE_ROOMS.remove(room.getName());
            ROOM_HISTORY.remove(room.getName());
        }

        for (UserSession user : USERS_BY_TOKEN.values()) {
            if (room.getName().equals(user.getCurrentRoom())) {
                user.setCurrentRoom(GENERAL_ROOM);
                if (user.isConnected() && user.getSession() != null) {
                    send(user.getSession(), "ROOM_JOINED::" + GENERAL_ROOM + "::GENERAL");
                    sendHistory(user.getSession(), GENERAL_ROOM, user);
                    send(user.getSession(), "SYSTEM::Private room " + room.getName() + " was deleted. You are back in General.");
                    sendOnlineUsersForRoom(user.getSession(), GENERAL_ROOM);
                }
            }
        }

        send(session, "ADMIN_OK::Private room deleted.");
        broadcastSystemToRoom(GENERAL_ROOM, "Private room " + room.getName() + " was deleted.", true);
        broadcastRooms();
        broadcastOnlineUsersForRoom(GENERAL_ROOM);
    }

    public static void sendUsersTo(Session session, String adminPassword) {
        if (!ADMIN_PASSWORD.equals(adminPassword)) {
            send(session, "ERROR::Invalid admin password.");
            return;
        }

        send(session, "ADMIN_USERS::" + getUsersAsString());
    }

    public static void sendRoomsToAdmin(Session session, String adminPassword) {
        if (!ADMIN_PASSWORD.equals(adminPassword)) {
            send(session, "ERROR::Invalid admin password.");
            return;
        }

        send(session, "ADMIN_ROOMS::" + getGeneralUserCount() + "::" + getRoomsAsString());
    }

    public static boolean canLaunchGame(String username, String reconnectToken) {
        String cleanUsername = normalize(username);
        String cleanToken = normalize(reconnectToken);

        if (cleanUsername.isEmpty() || cleanToken.isEmpty()) {
            return false;
        }

        cleanupExpiredUsers();

        UserSession user = USERS_BY_TOKEN.get(cleanToken);
        return user != null
            && user.hasUsername()
            && user.isConnected()
            && cleanUsername.equals(user.getUsername());
    }

    public static void kickUser(Session session, String adminPassword, String username) {
        if (!ADMIN_PASSWORD.equals(adminPassword)) {
            send(session, "ERROR::Invalid admin password.");
            return;
        }

        String target = normalize(username);

        for (UserSession user : USERS_BY_TOKEN.values()) {
            if (user.hasUsername() && user.getUsername().equalsIgnoreCase(target)) {
                if (user.isConnected() && user.getSession() != null) {
                    send(user.getSession(), "SYSTEM::You were removed by the admin.");
                    user.getSession().getUserProperties().put("logout", true);
                    try {
                        user.getSession().close();
                    } catch (IOException ignored) {
                    }
                } else {
                    removeUserCompletely(user);
                }
                send(session, "ADMIN_OK::User removed.");
                return;
            }
        }

        send(session, "ERROR::User not found.");
    }

    private static void handlePrivateMessage(UserSession sender, ReplyData replyData) {
        String[] parts = replyData.getMessage().split("\\s+");
        Set<String> recipients = new LinkedHashSet<>();
        int index = 0;

        while (index < parts.length && parts[index].startsWith("@")) {
            String username = normalize(parts[index].substring(1));
            if (!username.isEmpty()) {
                recipients.add(username);
            }
            index++;
        }

        if (recipients.isEmpty() || index >= parts.length) {
            String helpText = "Use @name or @name @name followed by a message for private sending.";
            send(sender.getSession(), "ERROR::" + helpText);
            return;
        }

        StringBuilder textBuilder = new StringBuilder();
        for (int i = index; i < parts.length; i++) {
            if (textBuilder.length() > 0) {
                textBuilder.append(" ");
            }
            textBuilder.append(parts[i]);
        }

        String privateText = textBuilder.toString().trim();
        if (privateText.isEmpty()) {
            send(sender.getSession(), "ERROR::Private message text is required.");
            return;
        }

        List<UserSession> targets = new ArrayList<>();
        List<String> deliveredNames = new ArrayList<>();

        for (UserSession user : USERS_BY_TOKEN.values()) {
            if (!user.isConnected() || !user.hasUsername()) {
                continue;
            }

            if (!sender.getCurrentRoom().equals(user.getCurrentRoom())) {
                continue;
            }

            if (recipients.contains(user.getUsername())) {
                targets.add(user);
                deliveredNames.add(user.getUsername());
            }
        }

        if (targets.isEmpty()) {
            send(sender.getSession(), "ERROR::None of those users are currently online in this room.");
            return;
        }

        String recipientsCsv = String.join(",", deliveredNames);
        String payload = "PRIVATE_CHAT::" + sender.getCurrentRoom() + "::" + sender.getUsername() + "::" + recipientsCsv + "::" + replyData.getReplyPreview() + "::" + System.currentTimeMillis() + "::" + privateText;
        addToHistory(sender.getCurrentRoom(), payload);

        send(sender.getSession(), payload);
        for (UserSession target : targets) {
            if (!target.getReconnectToken().equals(sender.getReconnectToken())) {
                send(target.getSession(), payload);
            }
        }
    }

    private static void switchRoom(UserSession user, String nextRoom, boolean privateRoom) {
        String previousRoom = user.getCurrentRoom();

        if (previousRoom.equals(nextRoom)) {
            if (user.isConnected() && user.getSession() != null) {
                send(user.getSession(), "SYSTEM::You are already in " + nextRoom + ".");
            }
            return;
        }

        user.setCurrentRoom(nextRoom);
        if (user.isConnected() && user.getSession() != null) {
            send(user.getSession(), "ROOM_JOINED::" + nextRoom + "::" + (privateRoom ? "PRIVATE" : "GENERAL"));
            sendHistory(user.getSession(), nextRoom, user);
            send(user.getSession(), "SYSTEM::You entered " + nextRoom + ".");
            sendOnlineUsersForRoom(user.getSession(), nextRoom);
        }

        if (user.hasUsername()) {
            broadcastSystemToRoom(previousRoom, user.getUsername() + " left " + previousRoom + ".", true);
            broadcastSystemToRoom(nextRoom, user.getUsername() + " joined " + nextRoom + ".", true);
        }

        broadcastRooms();
        broadcastOnlineUsersForRoom(previousRoom);
        broadcastOnlineUsersForRoom(nextRoom);
    }

    private static void sendHistory(Session session, String roomName, UserSession viewer) {
        Deque<String> history = ROOM_HISTORY.computeIfAbsent(roomName, key -> new ArrayDeque<>());
        StringBuilder builder = new StringBuilder();

        synchronized (history) {
            for (String entry : history) {
                if (!canViewHistoryEntry(entry, viewer)) {
                    continue;
                }

                if (builder.length() > 0) {
                    builder.append(",");
                }
                builder.append(encode(entry));
            }
        }

        send(session, "HISTORY::" + roomName + "::" + builder);
    }

    private static boolean canViewHistoryEntry(String entry, UserSession viewer) {
        if (!entry.startsWith("PRIVATE_CHAT::")) {
            return true;
        }

        String[] parts = entry.split("::", 7);
        if (parts.length < 7) {
            return false;
        }

        if (parts[2].equals(viewer.getUsername())) {
            return true;
        }

        for (String name : parts[3].split(",")) {
            if (name.equals(viewer.getUsername())) {
                return true;
            }
        }

        return false;
    }

    private static void addToHistory(String roomName, String payload) {
        Deque<String> history = ROOM_HISTORY.computeIfAbsent(roomName, key -> new ArrayDeque<>());

        synchronized (history) {
            history.addLast(payload);
            while (history.size() > HISTORY_LIMIT) {
                history.removeFirst();
            }
        }
    }

    private static void broadcastRooms() {
        String payload = "ROOMS::" + getGeneralUserCount() + "::" + getRoomsAsString();

        for (UserSession user : USERS_BY_TOKEN.values()) {
            if (user.isConnected() && user.getSession() != null) {
                send(user.getSession(), payload);
            }
        }
    }

    private static void broadcastToRoom(String roomName, String message) {
        for (UserSession user : USERS_BY_TOKEN.values()) {
            if (!user.isConnected() || user.getSession() == null) {
                continue;
            }

            if (roomName.equals(user.getCurrentRoom())) {
                send(user.getSession(), message);
            }
        }
    }

    private static void broadcastSystemToRoom(String roomName, String message, boolean persist) {
        String payload = "SYSTEM::" + System.currentTimeMillis() + "::" + message;

        if (persist) {
            addToHistory(roomName, payload);
        }

        broadcastToRoom(roomName, payload);
    }

    private static void broadcastOnlineUsersForRoom(String roomName) {
        String payload = "ONLINE_USERS::" + roomName + "::" + getOnlineUsersAsString(roomName);

        for (UserSession user : USERS_BY_TOKEN.values()) {
            if (!user.isConnected() || user.getSession() == null) {
                continue;
            }

            if (roomName.equals(user.getCurrentRoom())) {
                send(user.getSession(), payload);
            }
        }
    }

    private static String getOnlineUsersAsString(String roomName) {
        List<String> names = new ArrayList<>();

        for (UserSession user : USERS_BY_TOKEN.values()) {
            if (user.isConnected() && user.hasUsername() && roomName.equals(user.getCurrentRoom())) {
                names.add(user.getUsername());
            }
        }

        names.sort(String::compareToIgnoreCase);
        return String.join(",", names);
    }

    private static String getUsersAsString() {
        List<UserSession> sessions = new ArrayList<>(USERS_BY_TOKEN.values());
        sessions.sort(Comparator.comparing(
            user -> user.hasUsername() ? user.getUsername().toLowerCase() : "~pending"
        ));

        StringBuilder builder = new StringBuilder();

        for (UserSession user : sessions) {
            if (!user.hasUsername()) {
                continue;
            }

            if (builder.length() > 0) {
                builder.append(",");
            }

            builder.append(user.getUsername())
                .append("|")
                .append(user.getCurrentRoom())
                .append("|")
                .append(user.getIp())
                .append("|")
                .append(user.isConnected() ? "online" : "reconnecting");
        }

        return builder.toString();
    }

    private static String getRoomsAsString() {
        List<ChatRoom> rooms = new ArrayList<>(PRIVATE_ROOMS.values());
        rooms.sort(Comparator.comparing(room -> room.getName().toLowerCase()));

        StringBuilder builder = new StringBuilder();
        for (ChatRoom room : rooms) {
            if (builder.length() > 0) {
                builder.append(",");
            }

            builder.append(room.getName())
                .append("|")
                .append(countUsersInRoom(room.getName()));
        }

        return builder.toString();
    }

    private static int getGeneralUserCount() {
        return countUsersInRoom(GENERAL_ROOM);
    }

    private static int countUsersInRoom(String roomName) {
        int count = 0;
        for (UserSession user : USERS_BY_TOKEN.values()) {
            if (user.isConnected() && roomName.equals(user.getCurrentRoom())) {
                count++;
            }
        }
        return count;
    }

    private static boolean isUsernameTaken(String username, String reconnectToken) {
        for (UserSession user : USERS_BY_TOKEN.values()) {
            if (!user.hasUsername()) {
                continue;
            }

            if (user.getReconnectToken().equals(reconnectToken)) {
                continue;
            }

            if (user.getUsername().equalsIgnoreCase(username)) {
                return true;
            }
        }

        return false;
    }

    private static ChatRoom findRoom(String roomName) {
        String target = normalize(roomName);

        for (ChatRoom room : PRIVATE_ROOMS.values()) {
            if (room.getName().equalsIgnoreCase(target)) {
                return room;
            }
        }

        return null;
    }

    private static UserSession getConnectedUser(Session session) {
        String token = SESSION_TOKENS.get(session);
        if (token == null) {
            return null;
        }

        UserSession user = USERS_BY_TOKEN.get(token);
        if (user == null || !user.isConnected()) {
            return null;
        }

        return user;
    }

    private static void removeUserCompletely(UserSession user) {
        USERS_BY_TOKEN.remove(user.getReconnectToken());
        if (user.getSession() != null) {
            SESSION_TOKENS.remove(user.getSession());
        }

        if (user.hasUsername()) {
            broadcastSystemToRoom(user.getCurrentRoom(), user.getUsername() + " left " + user.getCurrentRoom() + ".", true);
            broadcastRooms();
            broadcastOnlineUsersForRoom(user.getCurrentRoom());
        }
    }

    private static void scheduleRemovalIfExpired(String reconnectToken) {
        SCHEDULER.schedule(() -> {
            UserSession user = USERS_BY_TOKEN.get(reconnectToken);
            if (user == null || user.isConnected()) {
                return;
            }

            if (System.currentTimeMillis() < user.getDisconnectDeadline()) {
                return;
            }

            removeUserCompletely(user);
        }, RECONNECT_GRACE_MS, TimeUnit.MILLISECONDS);
    }

    private static void cleanupExpiredUsers() {
        long now = System.currentTimeMillis();
        for (UserSession user : new ArrayList<>(USERS_BY_TOKEN.values())) {
            if (!user.isConnected() && user.getDisconnectDeadline() > 0 && now >= user.getDisconnectDeadline()) {
                removeUserCompletely(user);
            }
        }
    }

    private static String resolveClientIp(Session session) {
        Object clientIp = session.getUserProperties().get("clientIp");
        if (clientIp instanceof String && !((String) clientIp).trim().isEmpty()) {
            return ((String) clientIp).trim();
        }
        return "Unavailable (" + session.getId() + ")";
    }

    private static String encode(String value) {
        return Base64.getEncoder().encodeToString(value.getBytes(StandardCharsets.UTF_8));
    }

    private static void send(Session session, String message) {
        if (session == null || !session.isOpen()) {
            return;
        }

        try {
            session.getBasicRemote().sendText(message);
        } catch (IOException ignored) {
        }
    }

    private static String normalize(String value) {
        return value == null ? "" : value.trim().replaceAll("\\s+", " ");
    }

    private static ReplyData extractReplyData(String cleanMessage) {
        Matcher matcher = REPLY_PATTERN.matcher(cleanMessage);
        if (!matcher.matches()) {
            return new ReplyData("", cleanMessage);
        }

        String replyPreview = normalize(matcher.group(1));
        String message = normalize(matcher.group(2));
        return new ReplyData(replyPreview, message);
    }

    private static class ReplyData {
        private final String replyPreview;
        private final String message;

        private ReplyData(String replyPreview, String message) {
            this.replyPreview = replyPreview == null ? "" : replyPreview;
            this.message = message == null ? "" : message;
        }

        private String getReplyPreview() {
            return replyPreview;
        }

        private String getMessage() {
            return message;
        }
    }
}
