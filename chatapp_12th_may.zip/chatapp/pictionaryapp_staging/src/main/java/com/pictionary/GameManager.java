package com.pictionary;

import javax.websocket.Session;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class GameManager {

    private static final Map<String, RoomState> ROOMS = new ConcurrentHashMap<>();
    private static final Map<Session, String> USERNAMES = new ConcurrentHashMap<>();
    private static final Map<Session, String> USER_ROOMS = new ConcurrentHashMap<>();
    private static final ScheduledExecutorService SCHEDULER = Executors.newSingleThreadScheduledExecutor();
    private static final List<String> WORDS = Arrays.asList(
        "rocket", "apple", "bridge", "planet", "guitar", "camera", "satellite", "cricket",
        "pencil", "sunflower", "rainbow", "elephant", "mountain", "notebook", "spaceship"
    );
    private static final Random RANDOM = new Random();

    private GameManager() {
    }

    public static void connect(String username, Session session) {
        USERNAMES.put(session, username);
        send(session, "WELCOME::" + username);
        sendRoomList(session);
    }

    public static void disconnect(Session session) {
        String roomCode = USER_ROOMS.remove(session);
        String username = USERNAMES.remove(session);

        if (roomCode == null || username == null) {
            return;
        }

        RoomState room = ROOMS.get(roomCode);
        if (room == null) {
            return;
        }

        synchronized (room) {
            room.getPlayers().remove(username);
            room.getChatLog().add("SYSTEM::" + now() + "::" + username + " left the room.");
            if (room.getPlayers().isEmpty()) {
                ROOMS.remove(roomCode);
            } else {
                if (username.equals(room.getDrawerUsername())) {
                    endRound(room, "Drawer left. Round ended.");
                }
                broadcastRoom(room);
            }
        }

        broadcastPublicRoomList();
    }

    public static void sendRoomList(Session session) {
        send(session, "ROOM_LIST::" + buildRoomList());
    }

    public static void createRoom(Session session, String name, String visibility, String password, String maxPlayers) {
        String username = USERNAMES.get(session);
        if (username == null) {
            return;
        }

        String cleanName = sanitize(name);
        boolean isPublic = "PUBLIC".equalsIgnoreCase(visibility);
        String cleanPassword = sanitize(password);
        int limit = parseMaxPlayers(maxPlayers);

        if (cleanName.isEmpty()) {
            send(session, "ERROR::Room name is required.");
            return;
        }

        String roomCode = generateCode();
        RoomState room = new RoomState(roomCode, cleanName, isPublic, cleanPassword, limit, username);
        room.getPlayers().put(username, new PlayerState(username, session));
        room.getChatLog().add("SYSTEM::" + now() + "::Room created by " + username + ".");
        ROOMS.put(roomCode, room);
        USER_ROOMS.put(session, roomCode);

        send(session, "ROOM_JOINED::" + roomCode);
        broadcastRoom(room);
        broadcastPublicRoomList();
    }

    public static void joinRoom(Session session, String roomCode, String password) {
        String username = USERNAMES.get(session);
        if (username == null) {
            return;
        }

        RoomState room = ROOMS.get(sanitize(roomCode).toUpperCase());
        if (room == null) {
            send(session, "ERROR::Room not found.");
            return;
        }

        synchronized (room) {
            if (!room.getPassword().isEmpty() && !room.getPassword().equals(sanitize(password))) {
                send(session, "ERROR::Wrong room password.");
                return;
            }

            if (room.getPlayers().containsKey(username)) {
                room.getPlayers().get(username).setSession(session);
            } else {
                if (room.getPlayers().size() >= room.getMaxPlayers()) {
                    send(session, "ERROR::Room is full.");
                    return;
                }
                room.getPlayers().put(username, new PlayerState(username, session));
                room.getChatLog().add("SYSTEM::" + now() + "::" + username + " joined the room.");
            }
        }

        USER_ROOMS.put(session, room.getCode());
        send(session, "ROOM_JOINED::" + room.getCode());
        broadcastRoom(room);
        broadcastPublicRoomList();
    }

    public static void leaveRoom(Session session) {
        String roomCode = USER_ROOMS.remove(session);
        String username = USERNAMES.get(session);

        if (roomCode == null || username == null) {
            return;
        }

        RoomState room = ROOMS.get(roomCode);
        if (room == null) {
            return;
        }

        synchronized (room) {
            room.getPlayers().remove(username);
            room.getChatLog().add("SYSTEM::" + now() + "::" + username + " left the room.");
            if (room.getPlayers().isEmpty()) {
                ROOMS.remove(roomCode);
            } else {
                if (username.equals(room.getDrawerUsername())) {
                    endRound(room, "Drawer left. Round ended.");
                }
                broadcastRoom(room);
            }
        }

        send(session, "LEFT_ROOM");
        sendRoomList(session);
        broadcastPublicRoomList();
    }

    public static void startGame(Session session) {
        RoomState room = getRoomFor(session);
        String username = USERNAMES.get(session);

        if (room == null || username == null) {
            return;
        }

        synchronized (room) {
            if (!room.getHostUsername().equals(username)) {
                send(session, "ERROR::Only the host can start the game.");
                return;
            }

            if (room.getPlayers().size() < 2) {
                send(session, "ERROR::Need at least 2 players to start.");
                return;
            }

            startNextRound(room);
        }
    }

    public static void nextRound(Session session) {
        RoomState room = getRoomFor(session);
        String username = USERNAMES.get(session);

        if (room == null || username == null) {
            return;
        }

        synchronized (room) {
            if (!room.getHostUsername().equals(username)) {
                send(session, "ERROR::Only the host can start the next round.");
                return;
            }
            startNextRound(room);
        }
    }

    public static void handleChat(Session session, String text) {
        RoomState room = getRoomFor(session);
        String username = USERNAMES.get(session);

        if (room == null || username == null) {
            return;
        }

        String cleanText = sanitize(text);
        if (cleanText.isEmpty()) {
            return;
        }

        synchronized (room) {
            PlayerState player = room.getPlayers().get(username);
            if ("playing".equals(room.getStatus())
                && !username.equals(room.getDrawerUsername())
                && !player.hasGuessedCorrectly()
                && cleanText.equalsIgnoreCase(room.getWord())) {

                player.addScore(10);
                PlayerState drawer = room.getPlayers().get(room.getDrawerUsername());
                if (drawer != null) {
                    drawer.addScore(5);
                }

                player.setGuessedCorrectly(true);
                room.getChatLog().add("SYSTEM::" + now() + "::" + username + " guessed the word.");
                broadcastRoom(room);

                if (allGuessersDone(room)) {
                    endRound(room, "Everyone guessed the word.");
                }
                return;
            }

            room.getChatLog().add("CHAT::" + username + "::" + now() + "::" + cleanText);
            broadcastRoom(room);
        }
    }

    public static void handleDraw(Session session, String payload) {
        RoomState room = getRoomFor(session);
        String username = USERNAMES.get(session);

        if (room == null || username == null) {
            return;
        }

        synchronized (room) {
            if (!"playing".equals(room.getStatus()) || !username.equals(room.getDrawerUsername())) {
                return;
            }

            room.getStrokes().add(payload);
            broadcastToRoom(room, "DRAW::" + payload);
        }
    }

    public static void clearCanvas(Session session) {
        RoomState room = getRoomFor(session);
        String username = USERNAMES.get(session);

        if (room == null || username == null) {
            return;
        }

        synchronized (room) {
            if (!username.equals(room.getDrawerUsername())) {
                return;
            }

            room.getStrokes().clear();
            broadcastToRoom(room, "CANVAS_CLEAR");
        }
    }

    private static void startNextRound(RoomState room) {
        List<String> usernames = new ArrayList<>(room.getPlayers().keySet());
        if (usernames.isEmpty()) {
            return;
        }

        room.bumpRoundVersion();
        room.setStatus("playing");
        room.setRoundNumber(room.getRoundNumber() + 1);
        room.setDrawerIndex((room.getDrawerIndex() + 1) % usernames.size());
        room.setDrawerUsername(usernames.get(room.getDrawerIndex()));
        room.setWord(WORDS.get(RANDOM.nextInt(WORDS.size())));
        room.setRoundEndsAt(now() + 60000L);
        room.getStrokes().clear();
        room.getChatLog().add("SYSTEM::" + now() + "::Round " + room.getRoundNumber() + " started. " + room.getDrawerUsername() + " is drawing.");

        for (PlayerState player : room.getPlayers().values()) {
            player.setGuessedCorrectly(false);
        }

        long version = room.getRoundVersion();
        broadcastRoom(room);
        broadcastToRoom(room, "CANVAS_CLEAR");

        SCHEDULER.schedule(() -> {
            synchronized (room) {
                if (room.getRoundVersion() != version || !"playing".equals(room.getStatus())) {
                    return;
                }
                endRound(room, "Time is up.");
            }
        }, 60, TimeUnit.SECONDS);
    }

    private static void endRound(RoomState room, String reason) {
        room.bumpRoundVersion();
        room.setStatus("round_end");
        room.getChatLog().add("SYSTEM::" + now() + "::" + reason + " Word was " + room.getWord() + ".");
        broadcastRoom(room);
    }

    private static boolean allGuessersDone(RoomState room) {
        for (PlayerState player : room.getPlayers().values()) {
            if (player.getUsername().equals(room.getDrawerUsername())) {
                continue;
            }
            if (!player.hasGuessedCorrectly()) {
                return false;
            }
        }
        return true;
    }

    private static void broadcastRoom(RoomState room) {
        for (PlayerState player : room.getPlayers().values()) {
            Session session = player.getSession();
            if (session != null && session.isOpen()) {
                send(session, buildRoomState(room, player.getUsername()));
            }
        }
    }

    private static void broadcastPublicRoomList() {
        String payload = "ROOM_LIST::" + buildRoomList();
        for (Session session : USERNAMES.keySet()) {
            send(session, payload);
        }
    }

    private static void broadcastToRoom(RoomState room, String payload) {
        for (PlayerState player : room.getPlayers().values()) {
            send(player.getSession(), payload);
        }
    }

    private static String buildRoomList() {
        List<String> items = new ArrayList<>();

        for (RoomState room : ROOMS.values()) {
            if (!room.isPublic()) {
                continue;
            }
            items.add(escape(room.getCode()) + "|" + escape(room.getName()) + "|" + room.getPlayers().size() + "|" + escape(room.getStatus()));
        }

        return String.join(",", items);
    }

    private static String buildRoomState(RoomState room, String viewerUsername) {
        StringBuilder players = new StringBuilder();
        for (PlayerState player : room.getPlayers().values()) {
            if (players.length() > 0) {
                players.append(",");
            }
            players.append(escape(player.getUsername()))
                .append("|")
                .append(player.getScore())
                .append("|")
                .append(player.getUsername().equals(room.getDrawerUsername()) ? "drawer" : "player")
                .append("|")
                .append(player.hasGuessedCorrectly() ? "guessed" : "waiting");
        }

        StringBuilder chat = new StringBuilder();
        for (String item : room.getChatLog()) {
            if (chat.length() > 0) {
                chat.append(",");
            }
            chat.append(Base64.getEncoder().encodeToString(item.getBytes()));
        }

        StringBuilder strokes = new StringBuilder();
        for (String item : room.getStrokes()) {
            if (strokes.length() > 0) {
                strokes.append(",");
            }
            strokes.append(item);
        }

        String visibleWord = viewerUsername.equals(room.getDrawerUsername()) ? room.getWord() : mask(room.getWord());

        return "ROOM_STATE::"
            + encodeField(room.getCode()) + "::"
            + encodeField(room.getName()) + "::"
            + encodeField(room.getHostUsername()) + "::"
            + encodeField(room.getStatus()) + "::"
            + encodeField(room.getDrawerUsername()) + "::"
            + encodeField(visibleWord) + "::"
            + room.getRoundNumber() + "::"
            + room.getRoundEndsAt() + "::"
            + room.getMaxPlayers() + "::"
            + encodeField(room.isPublic() ? "PUBLIC" : "PRIVATE") + "::"
            + encodeField(players.toString()) + "::"
            + encodeField(chat.toString()) + "::"
            + encodeField(strokes.toString());
    }

    private static RoomState getRoomFor(Session session) {
        String roomCode = USER_ROOMS.get(session);
        return roomCode == null ? null : ROOMS.get(roomCode);
    }

    private static int parseMaxPlayers(String value) {
        try {
            int parsed = Integer.parseInt(value);
            return Math.max(2, Math.min(parsed, 12));
        } catch (NumberFormatException error) {
            return 8;
        }
    }

    private static String generateCode() {
        String code;
        do {
            code = Integer.toHexString(RANDOM.nextInt(0xFFFF)).toUpperCase();
            while (code.length() < 4) {
                code = "0" + code;
            }
        } while (ROOMS.containsKey(code));
        return code;
    }

    private static long now() {
        return System.currentTimeMillis();
    }

    private static String mask(String word) {
        if (word == null || word.isEmpty()) {
            return "";
        }
        return word.replaceAll("[A-Za-z0-9]", "_");
    }

    private static String sanitize(String value) {
        return value == null ? "" : value.trim().replaceAll("\\s+", " ");
    }

    private static String encodeField(String value) {
        return Base64.getEncoder().encodeToString((value == null ? "" : value).getBytes(StandardCharsets.UTF_8));
    }

    private static String escape(String value) {
        return value == null ? "" : value.replace("|", "/").replace(",", " ");
    }

    private static void send(Session session, String payload) {
        if (session == null || !session.isOpen()) {
            return;
        }

        try {
            session.getBasicRemote().sendText(payload);
        } catch (IOException ignored) {
        }
    }
}
