package com.pictionary;

import javax.websocket.Session;

public class PlayerState {

    private final String username;
    private Session session;
    private int score;
    private boolean guessedCorrectly;

    public PlayerState(String username, Session session) {
        this.username = username;
        this.session = session;
    }

    public String getUsername() {
        return username;
    }

    public Session getSession() {
        return session;
    }

    public void setSession(Session session) {
        this.session = session;
    }

    public int getScore() {
        return score;
    }

    public void addScore(int score) {
        this.score += score;
    }

    public boolean hasGuessedCorrectly() {
        return guessedCorrectly;
    }

    public void setGuessedCorrectly(boolean guessedCorrectly) {
        this.guessedCorrectly = guessedCorrectly;
    }
}
