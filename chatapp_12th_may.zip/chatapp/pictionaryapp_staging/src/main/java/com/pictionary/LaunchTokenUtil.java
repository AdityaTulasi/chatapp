package com.pictionary;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

public class LaunchTokenUtil {

    private static final String SECRET = "chatapp-pictionary-secret-2026";

    private LaunchTokenUtil() {
    }

    public static LaunchIdentity validate(String token) {
        if (token == null || token.trim().isEmpty()) {
            return null;
        }

        String[] parts = token.split("\\|", 4);
        if (parts.length != 4) {
            return null;
        }

        String payload = parts[0] + "|" + parts[1] + "|" + parts[2];
        if (!safeEquals(sign(payload), parts[3])) {
            return null;
        }

        long expiresAt;
        try {
            expiresAt = Long.parseLong(parts[2]);
        } catch (NumberFormatException error) {
            return null;
        }

        if (System.currentTimeMillis() > expiresAt) {
            return null;
        }

        return new LaunchIdentity(URLDecoder.decode(parts[0], StandardCharsets.UTF_8));
    }

    private static String sign(String value) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(SECRET.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
            return Base64.getUrlEncoder().withoutPadding().encodeToString(mac.doFinal(value.getBytes(StandardCharsets.UTF_8)));
        } catch (Exception error) {
            throw new IllegalStateException("Unable to sign launch token", error);
        }
    }

    private static boolean safeEquals(String left, String right) {
        if (left == null || right == null || left.length() != right.length()) {
            return false;
        }

        int result = 0;
        for (int i = 0; i < left.length(); i += 1) {
            result |= left.charAt(i) ^ right.charAt(i);
        }
        return result == 0;
    }

    public static class LaunchIdentity {
        private final String username;

        public LaunchIdentity(String username) {
            this.username = username;
        }

        public String getUsername() {
            return username;
        }
    }
}
