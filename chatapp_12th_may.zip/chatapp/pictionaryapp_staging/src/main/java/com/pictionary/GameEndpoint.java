package com.pictionary;

import javax.websocket.OnClose;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;

@ServerEndpoint(value = "/game", configurator = GameEndpointConfigurator.class)
public class GameEndpoint {

    @OnOpen
    public void onOpen(Session session) {
        String username = (String) session.getUserProperties().get("pictionaryUsername");
        if (username == null || username.trim().isEmpty()) {
            try {
                session.close();
            } catch (Exception ignored) {
            }
            return;
        }

        GameManager.connect(username, session);
    }

    @OnMessage
    public void onMessage(String message, Session session) {
        if (message == null) {
            return;
        }

        if ("LIST_ROOMS".equals(message)) {
            GameManager.sendRoomList(session);
            return;
        }

        if (message.startsWith("CREATE_ROOM::")) {
            String[] parts = message.split("::", 5);
            if (parts.length == 5) {
                GameManager.createRoom(session, parts[1], parts[2], parts[3], parts[4]);
            }
            return;
        }

        if (message.startsWith("JOIN_ROOM::")) {
            String[] parts = message.split("::", 3);
            if (parts.length == 3) {
                GameManager.joinRoom(session, parts[1], parts[2]);
            }
            return;
        }

        if ("LEAVE_ROOM".equals(message)) {
            GameManager.leaveRoom(session);
            return;
        }

        if ("START_GAME".equals(message)) {
            GameManager.startGame(session);
            return;
        }

        if ("NEXT_ROUND".equals(message)) {
            GameManager.nextRound(session);
            return;
        }

        if (message.startsWith("CHAT::")) {
            GameManager.handleChat(session, message.substring("CHAT::".length()));
            return;
        }

        if (message.startsWith("DRAW::")) {
            GameManager.handleDraw(session, message.substring("DRAW::".length()));
            return;
        }

        if ("CLEAR_CANVAS".equals(message)) {
            GameManager.clearCanvas(session);
        }
    }

    @OnClose
    public void onClose(Session session) {
        GameManager.disconnect(session);
    }
}
