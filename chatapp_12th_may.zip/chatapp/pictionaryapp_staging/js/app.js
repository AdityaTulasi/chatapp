let ws;
let username = "";
let currentRoom = null;
let currentDrawer = "";
let currentStatus = "lobby";
let roundEndsAt = 0;
let isDrawer = false;
let lastPoint = null;
let timerInterval = null;

const roomList = document.getElementById("room-list");
const roomListEmpty = document.getElementById("room-list-empty");
const publicCount = document.getElementById("public-count");
const identityName = document.getElementById("identity-name");
const authError = document.getElementById("auth-error");
const app = document.getElementById("app");
const lobbyView = document.getElementById("lobby-view");
const roomView = document.getElementById("room-view");
const roomName = document.getElementById("room-name");
const roomMeta = document.getElementById("room-meta");
const roundInfo = document.getElementById("round-info");
const drawerInfo = document.getElementById("drawer-info");
const wordInfo = document.getElementById("word-info");
const timerInfo = document.getElementById("timer-info");
const playerList = document.getElementById("player-list");
const playerCount = document.getElementById("player-count");
const chatLog = document.getElementById("chat-log");
const guessInput = document.getElementById("guess-input");
const statusBadge = document.getElementById("status-badge");
const startBtn = document.getElementById("start-btn");
const nextBtn = document.getElementById("next-btn");
const canvas = document.getElementById("draw-board");
const context = canvas.getContext("2d");
const colorInput = document.getElementById("brush-color");
const sizeInput = document.getElementById("brush-size");
const createVisibility = document.getElementById("create-visibility");
const createPasswordWrap = document.getElementById("create-password-wrap");

bootstrap();

guessInput.addEventListener("keydown", (event) => {
    if (event.key === "Enter" && !event.shiftKey) {
        event.preventDefault();
        sendGuess();
    }
});

guessInput.addEventListener("input", resizeGuessInput);
createVisibility.addEventListener("change", syncCreateForm);

canvas.addEventListener("mousedown", pointerDown);
canvas.addEventListener("mousemove", pointerMove);
window.addEventListener("mouseup", pointerUp);
canvas.addEventListener("touchstart", pointerDown, { passive: false });
canvas.addEventListener("touchmove", pointerMove, { passive: false });
window.addEventListener("touchend", pointerUp);

function bootstrap() {
    syncCreateForm();
    resizeGuessInput();

    fetch("api/session")
        .then((response) => response.json().then((data) => ({ ok: response.ok, data })))
        .then(({ ok, data }) => {
            if (!ok || !data.authenticated) {
                authError.classList.remove("hidden");
                return;
            }

            username = data.username;
            identityName.textContent = username;
            app.classList.remove("hidden");
            lobbyView.classList.remove("hidden");
            connect();
        })
        .catch(() => {
            authError.classList.remove("hidden");
        });
}

function connect() {
    const protocol = location.protocol === "https:" ? "wss:" : "ws:";
    ws = new WebSocket(`${protocol}//${location.host}/pictionaryapp/game`);

    ws.onopen = () => {
        requestRoomList();
    };

    ws.onmessage = (event) => {
        const parts = event.data.split("::");
        const type = parts[0];

        if (type === "WELCOME") {
            identityName.textContent = parts[1];
            return;
        }

        if (type === "ERROR") {
            alert(parts.slice(1).join("::"));
            return;
        }

        if (type === "ROOM_LIST") {
            renderRoomList(parts.slice(1).join("::"));
            return;
        }

        if (type === "ROOM_JOINED") {
            lobbyView.classList.add("hidden");
            roomView.classList.remove("hidden");
            return;
        }

        if (type === "LEFT_ROOM") {
            currentRoom = null;
            clearTimer();
            clearCanvasView();
            roomView.classList.add("hidden");
            lobbyView.classList.remove("hidden");
            requestRoomList();
            return;
        }

        if (type === "ROOM_STATE") {
            renderRoomState(parts);
            return;
        }

        if (type === "DRAW") {
            renderStroke(parts.slice(1).join("::"));
            return;
        }

        if (type === "CANVAS_CLEAR") {
            clearCanvasView();
        }
    };
}

function requestRoomList() {
    if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send("LIST_ROOMS");
    }
}

function createRoom() {
    const name = document.getElementById("create-name").value.trim();
    const visibility = createVisibility.value;
    const password = visibility === "PRIVATE" ? document.getElementById("create-password").value.trim() : "";
    const maxPlayers = document.getElementById("create-max").value;

    ws.send(`CREATE_ROOM::${name}::${visibility}::${password}::${maxPlayers}`);
}

function joinPrivateRoom() {
    const code = document.getElementById("join-code").value.trim().toUpperCase();
    const password = document.getElementById("join-password").value.trim();
    ws.send(`JOIN_ROOM::${code}::${password}`);
}

function joinPublicRoom(code) {
    ws.send(`JOIN_ROOM::${code}::`);
}

function leaveRoom() {
    ws.send("LEAVE_ROOM");
}

function startGame() {
    ws.send("START_GAME");
}

function nextRound() {
    ws.send("NEXT_ROUND");
}

function sendGuess() {
    const value = guessInput.value.trim();
    if (!value) {
        return;
    }

    ws.send(`CHAT::${value}`);
    guessInput.value = "";
    resizeGuessInput();
}

function clearCanvas() {
    ws.send("CLEAR_CANVAS");
}

function renderRoomList(rawRooms) {
    roomList.innerHTML = "";

    const rooms = rawRooms ? rawRooms.split(",").filter(Boolean) : [];
    publicCount.textContent = String(rooms.length);
    roomListEmpty.classList.toggle("hidden", rooms.length > 0);

    rooms.forEach((entry) => {
        const parts = entry.split("|");
        const code = parts[0];
        const name = parts[1];
        const players = parts[2];
        const status = parts[3];

        const row = document.createElement("div");
        row.className = "room-item";

        const main = document.createElement("div");
        main.className = "room-main";
        main.innerHTML = `
            <div class="room-title-row">
                <span class="room-title">${escapeHtml(name)}</span>
                <span class="room-code">${escapeHtml(code)}</span>
            </div>
            <div class="room-tags">
                <span class="room-tag">${escapeHtml(players)} players</span>
                <span class="room-tag">${escapeHtml(status)}</span>
                <span class="room-tag">Public room</span>
            </div>
        `;

        const button = document.createElement("button");
        button.type = "button";
        button.className = "action-btn primary-btn compact-btn";
        button.textContent = "Join";
        button.onclick = () => joinPublicRoom(code);

        row.appendChild(main);
        row.appendChild(button);
        roomList.appendChild(row);
    });
}

function renderRoomState(parts) {
    const code = decodeBase64(parts[1] || "");
    const name = decodeBase64(parts[2] || "");
    const host = decodeBase64(parts[3] || "");
    const status = decodeBase64(parts[4] || "");
    const drawer = decodeBase64(parts[5] || "");
    const visibleWord = decodeBase64(parts[6] || "");
    const visibility = decodeBase64(parts[10] || "");
    const rawPlayers = decodeBase64(parts[11] || "");
    const rawChat = decodeBase64(parts[12] || "");
    const rawStrokes = decodeBase64(parts[13] || "");

    currentRoom = {
        code,
        name,
        host,
        visibility
    };
    currentStatus = status;
    currentDrawer = drawer;
    roundEndsAt = Number(parts[8] || 0);
    isDrawer = username === currentDrawer && currentStatus === "playing";

    roomName.textContent = `${name} (${code})`;
    roomMeta.textContent = `${visibility} room | Host: ${host}`;
    roundInfo.textContent = parts[7];
    drawerInfo.textContent = currentDrawer || "Waiting";
    wordInfo.textContent = visibleWord || "-";
    statusBadge.textContent = currentStatus;
    playerCount.textContent = String(rawPlayers.split(",").filter(Boolean).length);
    startBtn.disabled = username !== host || currentStatus === "playing";
    nextBtn.disabled = username !== host;
    colorInput.disabled = !isDrawer;
    sizeInput.disabled = !isDrawer;

    renderPlayers(rawPlayers);
    renderChat(rawChat);
    renderCanvas(rawStrokes);
    startTimer();
}

function renderPlayers(rawPlayers) {
    playerList.innerHTML = "";

    rawPlayers.split(",").filter(Boolean).forEach((entry) => {
        const [name, score, role, state] = entry.split("|");
        const item = document.createElement("div");
        item.className = "player-item";
        item.innerHTML = `
            <div class="player-name-row">
                <span class="player-name">${escapeHtml(name)}</span>
                <span class="player-score">${escapeHtml(score)} pts</span>
            </div>
            <div class="player-meta">${escapeHtml(role)} • ${escapeHtml(state)}</div>
        `;
        playerList.appendChild(item);
    });
}

function renderChat(rawChat) {
    chatLog.innerHTML = "";

    rawChat.split(",").filter(Boolean).forEach((encoded) => {
        const decoded = decodeBase64(encoded);
        const parts = decoded.split("::");
        const type = parts[0];
        const line = document.createElement("div");
        line.className = `chat-line ${type === "SYSTEM" ? "system" : ""}`;

        if (type === "SYSTEM") {
            line.textContent = parts.slice(2).join("::");
        } else {
            line.innerHTML = `<span class="chat-author">${escapeHtml(parts[1])}:</span> ${escapeHtml(parts.slice(3).join("::"))}`;
        }

        chatLog.appendChild(line);
    });

    chatLog.scrollTop = chatLog.scrollHeight;
}

function renderCanvas(rawStrokes) {
    clearCanvasView();
    rawStrokes.split(",").filter(Boolean).forEach(renderStroke);
}

function renderStroke(payload) {
    const decoded = decodeBase64(payload);
    const [kind, x1, y1, x2, y2, color, size] = decoded.split("|");
    context.strokeStyle = color;
    context.lineWidth = Number(size);
    context.lineCap = "round";

    context.beginPath();
    if (kind === "dot") {
        context.moveTo(Number(x1), Number(y1));
        context.lineTo(Number(x1) + 0.1, Number(y1) + 0.1);
    } else {
        context.moveTo(Number(x1), Number(y1));
        context.lineTo(Number(x2), Number(y2));
    }
    context.stroke();
}

function clearCanvasView() {
    context.clearRect(0, 0, canvas.width, canvas.height);
}

function pointerDown(event) {
    if (!isDrawer) {
        return;
    }

    event.preventDefault();
    lastPoint = getCanvasPoint(event);
    sendStroke("dot", lastPoint, lastPoint);
}

function pointerMove(event) {
    if (!isDrawer || !lastPoint) {
        return;
    }

    event.preventDefault();
    const nextPoint = getCanvasPoint(event);
    sendStroke("line", lastPoint, nextPoint);
    lastPoint = nextPoint;
}

function pointerUp() {
    lastPoint = null;
}

function sendStroke(kind, from, to) {
    const payload = encodeBase64([
        kind,
        Math.round(from.x),
        Math.round(from.y),
        Math.round(to.x),
        Math.round(to.y),
        colorInput.value,
        sizeInput.value
    ].join("|"));

    ws.send(`DRAW::${payload}`);
    renderStroke(payload);
}

function getCanvasPoint(event) {
    const rect = canvas.getBoundingClientRect();
    const source = event.touches ? event.touches[0] : event;
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;

    return {
        x: (source.clientX - rect.left) * scaleX,
        y: (source.clientY - rect.top) * scaleY
    };
}

function startTimer() {
    clearTimer();

    const tick = () => {
        if (!roundEndsAt || currentStatus !== "playing") {
            timerInfo.textContent = "--";
            return;
        }

        const remaining = Math.max(0, Math.floor((roundEndsAt - Date.now()) / 1000));
        const minutes = String(Math.floor(remaining / 60)).padStart(2, "0");
        const seconds = String(remaining % 60).padStart(2, "0");
        timerInfo.textContent = `${minutes}:${seconds}`;
    };

    tick();
    timerInterval = window.setInterval(tick, 1000);
}

function clearTimer() {
    if (timerInterval) {
        window.clearInterval(timerInterval);
        timerInterval = null;
    }
}

function syncCreateForm() {
    const isPrivate = createVisibility.value === "PRIVATE";
    createPasswordWrap.classList.toggle("hidden", !isPrivate);
}

function resizeGuessInput() {
    guessInput.style.height = "auto";
    guessInput.style.height = `${Math.min(guessInput.scrollHeight, 160)}px`;
}

function decodeBase64(value) {
    if (!value) {
        return "";
    }

    const binary = window.atob(value);
    let encoded = "";

    for (let i = 0; i < binary.length; i += 1) {
        encoded += `%${(`00${binary.charCodeAt(i).toString(16)}`).slice(-2)}`;
    }

    try {
        return decodeURIComponent(encoded);
    } catch (error) {
        return binary;
    }
}

function encodeBase64(value) {
    return window.btoa(unescape(encodeURIComponent(value)));
}

function escapeHtml(value) {
    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");
}
