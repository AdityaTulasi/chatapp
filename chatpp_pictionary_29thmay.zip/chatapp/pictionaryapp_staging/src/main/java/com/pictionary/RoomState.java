package com.pictionary;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class RoomState {

    private final String code;
    private final String name;
    private final boolean isPublic;
    private final String password;
    private final int maxPlayers;
    private int totalRounds;
    private int roundSeconds;
    private String hostUsername;
    private final Map<String, PlayerState> players = new LinkedHashMap<>();
    private final List<String> chatLog = new ArrayList<>();
    private final List<String> strokes = new ArrayList<>();
    private final List<String> redoStrokes = new ArrayList<>();
    private final List<String> wordChoices = new ArrayList<>();
    private final Set<String> activeRoundPlayers = new LinkedHashSet<>();
    private final Set<Integer> revealedLetterIndexes = new LinkedHashSet<>();

    private String status = "lobby";
    private String drawerUsername = "";
    private String word = "";
    private int drawerIndex = -1;
    private int roundNumber = 0;
    private int turnNumber = 0;
    private long roundEndsAt = 0L;
    private long pickEndsAt = 0L;
    private long roundVersion = 0L;

    public RoomState(String code, String name, boolean isPublic, String password, int maxPlayers, int totalRounds, int roundSeconds, String hostUsername) {
        this.code = code;
        this.name = name;
        this.isPublic = isPublic;
        this.password = password;
        this.maxPlayers = maxPlayers;
        this.totalRounds = totalRounds;
        this.roundSeconds = roundSeconds;
        this.hostUsername = hostUsername;
    }

    public String getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public boolean isPublic() {
        return isPublic;
    }

    public String getPassword() {
        return password;
    }

    public int getMaxPlayers() {
        return maxPlayers;
    }

    public int getTotalRounds() {
        return totalRounds;
    }

    public void setTotalRounds(int totalRounds) {
        this.totalRounds = totalRounds;
    }

    public int getRoundSeconds() {
        return roundSeconds;
    }

    public void setRoundSeconds(int roundSeconds) {
        this.roundSeconds = roundSeconds;
    }

    public String getHostUsername() {
        return hostUsername;
    }

    public void setHostUsername(String hostUsername) {
        this.hostUsername = hostUsername;
    }

    public Map<String, PlayerState> getPlayers() {
        return players;
    }

    public List<String> getChatLog() {
        return chatLog;
    }

    public List<String> getStrokes() {
        return strokes;
    }

    public List<String> getRedoStrokes() {
        return redoStrokes;
    }

    public List<String> getWordChoices() {
        return wordChoices;
    }

    public Set<String> getActiveRoundPlayers() {
        return activeRoundPlayers;
    }

    public Set<Integer> getRevealedLetterIndexes() {
        return revealedLetterIndexes;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDrawerUsername() {
        return drawerUsername;
    }

    public void setDrawerUsername(String drawerUsername) {
        this.drawerUsername = drawerUsername;
    }

    public String getWord() {
        return word;
    }

    public void setWord(String word) {
        this.word = word;
    }

    public int getDrawerIndex() {
        return drawerIndex;
    }

    public void setDrawerIndex(int drawerIndex) {
        this.drawerIndex = drawerIndex;
    }

    public int getRoundNumber() {
        return roundNumber;
    }

    public void setRoundNumber(int roundNumber) {
        this.roundNumber = roundNumber;
    }

    public int getTurnNumber() {
        return turnNumber;
    }

    public void setTurnNumber(int turnNumber) {
        this.turnNumber = turnNumber;
    }

    public long getRoundEndsAt() {
        return roundEndsAt;
    }

    public void setRoundEndsAt(long roundEndsAt) {
        this.roundEndsAt = roundEndsAt;
    }

    public long getPickEndsAt() {
        return pickEndsAt;
    }

    public void setPickEndsAt(long pickEndsAt) {
        this.pickEndsAt = pickEndsAt;
    }

    public long getRoundVersion() {
        return roundVersion;
    }

    public void bumpRoundVersion() {
        this.roundVersion += 1L;
    }
}
