package com.pictionary;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/admin-api")
public class AdminServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/plain;charset=UTF-8");

        String action = request.getParameter("action");
        String password = request.getParameter("password");

        if ("rooms".equals(action)) {
            response.getWriter().write(GameManager.getAdminRooms(password));
            return;
        }

        if ("close".equals(action)) {
            response.getWriter().write(GameManager.closeRoomAsAdmin(password, request.getParameter("code")));
            return;
        }

        response.getWriter().write("ERROR::Unknown admin action.");
    }
}
