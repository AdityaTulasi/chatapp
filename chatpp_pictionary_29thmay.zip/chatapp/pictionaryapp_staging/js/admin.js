const storageKey = "pictionary-admin-session";
const reconnectGraceMs = 30000;

let adminPassword = "";

bootstrapAdmin();

function bootstrapAdmin() {
    const stored = readStoredAdmin();
    if (stored) {
        adminPassword = stored.password;
    } else {
        adminPassword = prompt("Enter admin password:") || "";
    }

    if (!adminPassword) {
        document.body.innerHTML = "";
        return;
    }

    persistAdmin();
    window.addEventListener("beforeunload", persistAdmin);
    loadAdminRooms();
}

function loadAdminRooms() {
    postAdmin({ action: "rooms", password: adminPassword })
        .then((text) => {
            const parts = text.split("::");
            if (parts[0] === "ERROR") {
                setAdminMessage(parts.slice(1).join("::"));
                return;
            }
            renderRooms(parts.slice(1).join("::"));
        })
        .catch(() => setAdminMessage("Unable to load rooms."));
}

function renderRooms(data) {
    const list = document.getElementById("admin-room-list");
    const empty = document.getElementById("admin-room-empty");
    list.innerHTML = "";

    const rooms = data.split(",").filter(Boolean);
    empty.classList.toggle("hidden", rooms.length > 0);
    setAdminMessage(`${rooms.length} active room${rooms.length === 1 ? "" : "s"}.`);

    rooms.forEach((entry) => {
        const [code, name, visibility, password, players, maxPlayers, rounds, seconds, status, host, currentWord] = entry.split("|");
        const row = document.createElement("div");
        row.className = "room-item";
        row.innerHTML = `
            <div class="room-main">
                <div class="room-title-row">
                    <span class="room-title">${escapeHtml(name)}</span>
                    <span class="room-code">${escapeHtml(code)}</span>
                </div>
                <div class="room-tags">
                    <span class="room-tag">${escapeHtml(visibility)}</span>
                    <span class="room-tag">${escapeHtml(players)}/${escapeHtml(maxPlayers)} players</span>
                    <span class="room-tag">${escapeHtml(rounds)} rounds</span>
                    <span class="room-tag">${escapeHtml(seconds)} sec</span>
                    <span class="room-tag">${escapeHtml(status)}</span>
                    <span class="room-tag">Host: ${escapeHtml(host)}</span>
                    <span class="room-tag">Word: ${escapeHtml(currentWord || "-")}</span>
                    <span class="room-tag">Password: ${visibility === "PRIVATE" ? escapeHtml(password || "-") : "-"}</span>
                </div>
            </div>
        `;

        const button = document.createElement("button");
        button.type = "button";
        button.className = "action-btn secondary-btn compact-btn";
        button.textContent = "Close Room";
        button.onclick = () => closeRoom(code);
        row.appendChild(button);
        list.appendChild(row);
    });
}

function closeRoom(code) {
    if (!confirm(`Close room ${code}?`)) {
        return;
    }

    postAdmin({ action: "close", password: adminPassword, code })
        .then((text) => {
            const parts = text.split("::");
            setAdminMessage(parts.slice(1).join("::"));
            loadAdminRooms();
        })
        .catch(() => setAdminMessage("Unable to close room."));
}

function postAdmin(data) {
    const body = new URLSearchParams(data);
    return fetch("admin-api", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body
    }).then((response) => response.text());
}

function logoutAdmin() {
    localStorage.removeItem(storageKey);
    document.body.innerHTML = "";
}

function setAdminMessage(message) {
    document.getElementById("admin-message").textContent = message;
}

function persistAdmin() {
    localStorage.setItem(storageKey, JSON.stringify({
        password: adminPassword,
        expiresAt: Date.now() + reconnectGraceMs
    }));
}

function readStoredAdmin() {
    try {
        const raw = localStorage.getItem(storageKey);
        if (!raw) {
            return null;
        }
        const parsed = JSON.parse(raw);
        if (!parsed.password || Date.now() > Number(parsed.expiresAt || 0)) {
            localStorage.removeItem(storageKey);
            return null;
        }
        return parsed;
    } catch (error) {
        localStorage.removeItem(storageKey);
        return null;
    }
}

function escapeHtml(value) {
    return String(value || "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");
}
