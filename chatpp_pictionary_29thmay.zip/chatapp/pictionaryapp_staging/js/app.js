let ws;
let username = "";
let currentRoom = null;
let currentDrawer = "";
let currentStatus = "lobby";
let roundEndsAt = 0;
let isDrawer = false;
let lastPoint = null;
let timerInterval = null;
let fillMode = false;
let eraserMode = false;
let currentBrush = "round";
let currentStrokeId = "";
let chatShouldStickToBottom = true;

const roomList = document.getElementById("room-list");
const roomListEmpty = document.getElementById("room-list-empty");
const publicCount = document.getElementById("public-count");
const identityName = document.getElementById("identity-name");
const authError = document.getElementById("auth-error");
const app = document.getElementById("app");
const lobbyView = document.getElementById("lobby-view");
const roomView = document.getElementById("room-view");
const roomName = document.getElementById("room-name");
const roomMeta = document.getElementById("room-meta");
const roundInfo = document.getElementById("round-info");
const drawerInfo = document.getElementById("drawer-info");
const wordInfo = document.getElementById("word-info");
const timerInfo = document.getElementById("timer-info");
const playerList = document.getElementById("player-list");
const playerCount = document.getElementById("player-count");
const chatLog = document.getElementById("chat-log");
const pictionaryEmojiPicker = document.getElementById("pictionary-emoji-picker");
const guessInput = document.getElementById("guess-input");
const statusBadge = document.getElementById("status-badge");
const startBtn = document.getElementById("start-btn");
const canvas = document.getElementById("draw-board");
const context = canvas.getContext("2d");
const colorInput = document.getElementById("brush-color");
const sizeInput = document.getElementById("brush-size");
const createVisibility = document.getElementById("create-visibility");
const createPasswordWrap = document.getElementById("create-password-wrap");
const createRounds = document.getElementById("create-rounds");
const createTime = document.getElementById("create-time");
const roomRounds = document.getElementById("room-rounds");
const roomTime = document.getElementById("room-time");
const wordPicker = document.getElementById("word-picker");
const wordChoiceList = document.getElementById("word-choice-list");
const wordPickerTimer = document.getElementById("word-picker-timer");
const scoreModal = document.getElementById("score-modal");
const scoreList = document.getElementById("score-list");
const scoreHostActions = document.getElementById("score-host-actions");
const pictionaryEmojiCatalog = ["😀", "😂", "😊", "😍", "😎", "🤔", "😮", "😭", "👍", "👏", "🙏", "🎉", "🔥", "💡", "✅", "❌", "❤️", "🚀", "⭐", "🏆", "🎨"];

bootstrap();

guessInput.addEventListener("keydown", (event) => {
    if (event.key === "Enter" && !event.shiftKey) {
        event.preventDefault();
        sendGuess();
    }
});

guessInput.addEventListener("input", resizeGuessInput);
if (createVisibility) {
    createVisibility.addEventListener("change", syncCreateForm);
}
if (chatLog) {
    chatLog.addEventListener("scroll", () => {
        chatShouldStickToBottom = isChatAtBottom();
    });
}

canvas.addEventListener("mousedown", pointerDown);
canvas.addEventListener("mousemove", pointerMove);
window.addEventListener("mouseup", pointerUp);
canvas.addEventListener("touchstart", pointerDown, { passive: false });
canvas.addEventListener("touchmove", pointerMove, { passive: false });
window.addEventListener("touchend", pointerUp);

function bootstrap() {
    ensureCreateSettingsFields();
    syncCreateForm();
    resizeGuessInput();
    renderPictionaryEmojiPicker();

    fetch("api/session")
        .then((response) => response.json().then((data) => ({ ok: response.ok, data })))
        .then(({ ok, data }) => {
            if (!ok || !data.authenticated) {
                authError.classList.remove("hidden");
                return;
            }

            username = data.username;
            identityName.textContent = username;
            app.classList.remove("hidden");
            lobbyView.classList.remove("hidden");
            connect();
        })
        .catch(() => {
            authError.classList.remove("hidden");
        });
}

function connect() {
    const protocol = location.protocol === "https:" ? "wss:" : "ws:";
    const contextPath = location.pathname.split("/").filter(Boolean)[0] || "pictionaryapp";
    ws = new WebSocket(`${protocol}//${location.host}/${contextPath}/game`);

    ws.onopen = () => {
        requestRoomList();
    };

    ws.onmessage = (event) => {
        const parts = event.data.split("::");
        const type = parts[0];

        if (type === "WELCOME") {
            identityName.textContent = parts[1];
            return;
        }

        if (type === "ERROR") {
            alert(parts.slice(1).join("::"));
            return;
        }

        if (type === "ROOM_LIST") {
            renderRoomList(parts.slice(1).join("::"));
            return;
        }

        if (type === "ROOM_JOINED") {
            lobbyView.classList.add("hidden");
            roomView.classList.remove("hidden");
            return;
        }

        if (type === "LEFT_ROOM") {
            currentRoom = null;
            clearTimer();
            clearCanvasView();
            hideWordPicker();
            hideScoreModal();
            roomView.classList.add("hidden");
            lobbyView.classList.remove("hidden");
            requestRoomList();
            return;
        }

        if (type === "ROOM_STATE") {
            renderRoomState(parts);
            return;
        }

        if (type === "DRAW") {
            renderStroke(parts.slice(1).join("::"));
            return;
        }

        if (type === "CANVAS_CLEAR") {
            clearCanvasView();
            return;
        }

        if (type === "PRIVATE_HINT") {
            appendPrivateHint(parts.slice(1).join("::"));
        }
    };
}

function requestRoomList() {
    if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send("LIST_ROOMS");
    }
}

function createRoom() {
    const name = readFieldValue("create-name", "").trim();
    const visibility = readFieldValue("create-visibility", "PUBLIC");
    const password = visibility === "PRIVATE" ? readFieldValue("create-password", "").trim() : "";
    const maxPlayers = readFieldValue("create-max", "8");
    const rounds = readFieldValue("create-rounds", "5");
    const roundSeconds = readFieldValue("create-time", "60");

    if (!ws || ws.readyState !== WebSocket.OPEN) {
        alert("Game connection is not ready yet. Please try again in a moment.");
        return;
    }

    ws.send(`CREATE_ROOM::${name}::${visibility}::${password}::${maxPlayers}::${rounds}::${roundSeconds}`);
}

function joinPrivateRoom() {
    const code = document.getElementById("join-code").value.trim().toUpperCase();
    const password = document.getElementById("join-password").value.trim();
    ws.send(`JOIN_ROOM::${code}::${password}`);
}

function joinPublicRoom(code) {
    ws.send(`JOIN_ROOM::${code}::`);
}

function leaveRoom() {
    ws.send("LEAVE_ROOM");
}

function startGame() {
    ws.send("START_GAME");
}

function updateRoomSettings() {
    if (!ws || ws.readyState !== WebSocket.OPEN) {
        return;
    }

    ws.send(`ROOM_SETTINGS::${roomRounds.value}::${roomTime.value}`);
}

function pickWord(word) {
    ws.send(`PICK_WORD::${word}`);
    hideWordPicker();
}

function sendGuess() {
    const value = guessInput.value.trim();
    if (!value) {
        return;
    }

    ws.send(`CHAT::${value}`);
    guessInput.value = "";
    resizeGuessInput();
}

function clearCanvas() {
    ws.send("CLEAR_CANVAS");
}

function undoDraw() {
    if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send("UNDO_DRAW");
    }
}

function redoDraw() {
    if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send("REDO_DRAW");
    }
}

function toggleFillMode() {
    fillMode = !fillMode;
    if (fillMode) {
        eraserMode = false;
    }
    updateFillButton();
    updateToolButtons();
}

function toggleEraser() {
    eraserMode = !eraserMode;
    if (eraserMode) {
        fillMode = false;
    }
    updateFillButton();
    updateToolButtons();
}

function selectBrush(brush) {
    currentBrush = brush;
    eraserMode = false;
    fillMode = false;
    updateFillButton();
    updateToolButtons();
}

function renderRoomList(rawRooms) {
    roomList.innerHTML = "";

    const rooms = rawRooms ? rawRooms.split(",").filter(Boolean) : [];
    publicCount.textContent = String(rooms.length);
    roomListEmpty.classList.toggle("hidden", rooms.length > 0);

    rooms.forEach((entry) => {
        const parts = entry.split("|");
        const code = parts[0];
        const name = parts[1];
        const players = parts[2];
        const status = parts[3];

        const row = document.createElement("div");
        row.className = "room-item";

        const main = document.createElement("div");
        main.className = "room-main";
        main.innerHTML = `
            <div class="room-title-row">
                <span class="room-title">${escapeHtml(name)}</span>
                <span class="room-code">${escapeHtml(code)}</span>
            </div>
            <div class="room-tags">
                <span class="room-tag">${escapeHtml(players)} players</span>
                <span class="room-tag">${escapeHtml(status)}</span>
                <span class="room-tag">Public room</span>
            </div>
        `;

        const button = document.createElement("button");
        button.type = "button";
        button.className = "action-btn primary-btn compact-btn";
        button.textContent = "Join";
        button.onclick = () => joinPublicRoom(code);

        row.appendChild(main);
        row.appendChild(button);
        roomList.appendChild(row);
    });
}

function renderRoomState(parts) {
    const code = decodeBase64(parts[1] || "");
    const name = decodeBase64(parts[2] || "");
    const host = decodeBase64(parts[3] || "");
    const status = decodeBase64(parts[4] || "");
    const drawer = decodeBase64(parts[5] || "");
    const visibleWord = decodeBase64(parts[6] || "");
    const visibility = decodeBase64(parts[10] || "");
    const rawPlayers = decodeBase64(parts[11] || "");
    const rawChat = decodeBase64(parts[12] || "");
    const rawStrokes = decodeBase64(parts[13] || "");
    const totalRounds = parts[14] || "5";
    const roundSeconds = parts[15] || "60";
    const pickEndsAt = Number(parts[16] || 0);
    const rawChoices = decodeBase64(parts[17] || "");
    const rawPodium = decodeBase64(parts[18] || "");

    currentRoom = {
        code,
        name,
        host,
        visibility
    };
    currentStatus = status;
    currentDrawer = drawer;
    roundEndsAt = Number(parts[8] || 0);
    isDrawer = username === currentDrawer && currentStatus === "playing";

    roomName.textContent = `${name} (${code})`;
    roomMeta.textContent = `${visibility} room | Host: ${host} | ${totalRounds} rounds | ${roundSeconds}s`;
    roundInfo.textContent = parts[7];
    drawerInfo.textContent = currentDrawer || "Waiting";
    wordInfo.textContent = visibleWord || "-";
    statusBadge.textContent = currentStatus;
    playerCount.textContent = String(rawPlayers.split(",").filter(Boolean).length);
    startBtn.disabled = username !== host || (currentStatus !== "lobby" && currentStatus !== "finished");
    roomRounds.value = totalRounds;
    roomTime.value = roundSeconds;
    roomRounds.disabled = username !== host || (currentStatus !== "lobby" && currentStatus !== "finished");
    roomTime.disabled = roomRounds.disabled;
    colorInput.disabled = !isDrawer;
    sizeInput.disabled = !isDrawer;
    document.querySelectorAll(".tool-icon").forEach((button) => {
        button.disabled = !isDrawer;
    });
    const currentFillButton = document.getElementById("fill-btn");
    if (currentFillButton) {
        currentFillButton.disabled = !isDrawer;
    }
    updateToolButtons();

    renderPlayers(rawPlayers);
    renderChat(rawChat);
    renderCanvas(rawStrokes);
    renderWordPicker(rawChoices, pickEndsAt);
    renderScoreModal(rawPodium, currentStatus === "finished", username === host);
    startTimer();
}

function renderPlayers(rawPlayers) {
    playerList.innerHTML = "";

    rawPlayers.split(",").filter(Boolean).forEach((entry) => {
        const [name, score, role, state] = entry.split("|");
        const item = document.createElement("div");
        item.className = "player-item";
        item.innerHTML = `
            <div class="player-name-row">
                <span class="player-name">${escapeHtml(name)}</span>
                <span class="player-score">${escapeHtml(score)} pts</span>
            </div>
            <div class="player-meta">${escapeHtml(role)} • ${escapeHtml(state)}</div>
        `;
        if (currentRoom && username === currentRoom.host && name !== username) {
            const button = document.createElement("button");
            button.type = "button";
            button.className = "player-kick-btn";
            button.textContent = "Kick";
            button.onclick = () => kickPlayer(name);
            item.appendChild(button);
        }
        playerList.appendChild(item);
    });
}

function kickPlayer(name) {
    if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send(`KICK_PLAYER::${name}`);
    }
}

function renderChat(rawChat) {
    const shouldScroll = !chatLog.dataset.rendered || chatShouldStickToBottom || isChatAtBottom();
    const previousScrollTop = chatLog.scrollTop;
    chatLog.innerHTML = "";

    rawChat.split(",").filter(Boolean).forEach((encoded) => {
        const decoded = decodeBase64(encoded);
        const parts = decoded.split("::");
        const type = parts[0];
        const line = document.createElement("div");
        line.className = `chat-line ${type === "SYSTEM" ? "system" : ""}`;

        if (type === "SYSTEM") {
            line.textContent = parts.slice(2).join("::");
        } else {
            line.innerHTML = `<span class="chat-author">${escapeHtml(parts[1])}:</span> ${escapeHtml(parts.slice(3).join("::"))}`;
        }

        chatLog.appendChild(line);
    });

    chatLog.dataset.rendered = "true";
    if (shouldScroll) {
        scrollChatToBottom();
    } else {
        chatLog.scrollTop = previousScrollTop;
    }
}

function appendPrivateHint(message) {
    const line = document.createElement("div");
    line.className = "chat-line system private-hint";
    line.textContent = message || "You are close!";
    chatLog.appendChild(line);
    if (chatShouldStickToBottom || isChatAtBottom()) {
        scrollChatToBottom();
    }
}

function isChatAtBottom() {
    return chatLog.scrollHeight - chatLog.scrollTop - chatLog.clientHeight <= 12;
}

function scrollChatToBottom() {
    chatLog.scrollTop = chatLog.scrollHeight;
    chatShouldStickToBottom = true;
}

function renderCanvas(rawStrokes) {
    clearCanvasView();
    rawStrokes.split(",").filter(Boolean).forEach(renderStroke);
}

function renderWordPicker(rawChoices, pickEndsAt) {
    const choices = rawChoices ? rawChoices.split(",").filter(Boolean) : [];
    wordChoiceList.innerHTML = "";

    if (currentStatus !== "picking" || choices.length === 0) {
        hideWordPicker();
        return;
    }

    choices.forEach((word) => {
        const button = document.createElement("button");
        button.type = "button";
        button.className = "word-choice";
        button.textContent = word;
        button.onclick = () => pickWord(word);
        wordChoiceList.appendChild(button);
    });

    wordPicker.dataset.endsAt = String(pickEndsAt || 0);
    wordPicker.classList.remove("hidden");
    updateWordPickerTimer();
}

function hideWordPicker() {
    wordPicker.classList.add("hidden");
    wordChoiceList.innerHTML = "";
    wordPicker.dataset.endsAt = "0";
}

function updateWordPickerTimer() {
    const endsAt = Number(wordPicker.dataset.endsAt || 0);
    if (!endsAt) {
        wordPickerTimer.textContent = "";
        return;
    }

    const remaining = Math.max(0, Math.ceil((endsAt - Date.now()) / 1000));
    wordPickerTimer.textContent = `${remaining}s`;
}

function renderScoreModal(rawPodium, shouldShow, isHost) {
    if (!shouldShow) {
        scoreModal.classList.add("hidden");
        return;
    }

    scoreList.innerHTML = "";
    rawPodium.split(",").filter(Boolean).slice(0, 3).forEach((entry, index) => {
        const [name, score] = entry.split("|");
        const row = document.createElement("div");
        row.className = "score-row";
        row.innerHTML = `<span>${index + 1}. ${escapeHtml(name)}</span><strong>${escapeHtml(score || "0")} pts</strong>`;
        scoreList.appendChild(row);
    });

    scoreHostActions.classList.toggle("hidden", !isHost);
    scoreModal.classList.remove("hidden");
}

function hideScoreModal() {
    scoreModal.classList.add("hidden");
}

function renderPictionaryEmojiPicker() {
    if (!pictionaryEmojiPicker) {
        return;
    }

    pictionaryEmojiPicker.innerHTML = "";
    pictionaryEmojiCatalog.forEach((emoji) => {
        const button = document.createElement("button");
        button.type = "button";
        button.className = "emoji-choice";
        button.textContent = emoji;
        button.onclick = () => {
            guessInput.value += emoji;
            resizeGuessInput();
            guessInput.focus();
        };
        pictionaryEmojiPicker.appendChild(button);
    });
}

function togglePictionaryEmojiPicker() {
    if (pictionaryEmojiPicker) {
        pictionaryEmojiPicker.classList.toggle("hidden");
    }
}

function renderStroke(payload) {
    const decoded = decodeBase64(payload);
    const parts = decoded.split("|");
    const [kind, x1, y1, x2, y2, color, size, tool] = parts;

    if (kind === "bucket") {
        floodFill(Number(parts[1]), Number(parts[2]), parts[3] || "#ffffff");
        return;
    }

    drawBrushStroke(
        kind,
        Number(x1),
        Number(y1),
        Number(x2),
        Number(y2),
        color,
        Number(size),
        tool || "round"
    );
}

function drawBrushStroke(kind, x1, y1, x2, y2, color, size, tool) {
    context.save();
    context.strokeStyle = tool === "eraser" ? "#ffffff" : color;
    context.fillStyle = tool === "eraser" ? "#ffffff" : color;
    context.lineWidth = brushLineWidth(tool, size);
    context.lineCap = tool === "square" || tool === "marker" ? "butt" : "round";
    context.lineJoin = tool === "square" || tool === "marker" ? "miter" : "round";

    if (tool === "highlighter") {
        context.globalAlpha = 0.34;
        context.lineWidth = size * 2.4;
    }

    if (tool === "calligraphy") {
        context.translate(x1, y1);
        context.scale(1.8, 0.55);
        context.translate(-x1, -y1);
    }

    if (tool === "spray") {
        drawSpray(kind, x1, y1, x2, y2, size, context.fillStyle);
        context.restore();
        return;
    }

    context.beginPath();
    if (kind === "dot") {
        context.moveTo(x1, y1);
        context.lineTo(x1 + 0.1, y1 + 0.1);
    } else {
        context.moveTo(x1, y1);
        context.lineTo(x2, y2);
    }
    context.stroke();
    context.restore();
}

function brushLineWidth(tool, size) {
    if (tool === "marker") {
        return size * 1.8;
    }
    if (tool === "square") {
        return size * 1.15;
    }
    return size;
}

function drawSpray(kind, x1, y1, x2, y2, size, color) {
    const steps = kind === "dot" ? 1 : Math.max(1, Math.ceil(distanceBetween(x1, y1, x2, y2) / 12));
    const radius = Math.max(6, size * 1.8);
    context.fillStyle = color;
    for (let step = 0; step <= steps; step += 1) {
        const t = steps === 0 ? 0 : step / steps;
        const cx = x1 + ((x2 - x1) * t);
        const cy = y1 + ((y2 - y1) * t);
        for (let dot = 0; dot < 8; dot += 1) {
            const seed = pseudoRandom(cx, cy, dot);
            const angle = seed * Math.PI * 2;
            const spread = pseudoRandom(cy, cx, dot + 13) * radius;
            context.fillRect(cx + Math.cos(angle) * spread, cy + Math.sin(angle) * spread, 1.6, 1.6);
        }
    }
}

function distanceBetween(x1, y1, x2, y2) {
    const dx = x2 - x1;
    const dy = y2 - y1;
    return Math.sqrt((dx * dx) + (dy * dy));
}

function pseudoRandom(x, y, salt) {
    const value = Math.sin((Math.round(x) * 12.9898) + (Math.round(y) * 78.233) + (salt * 37.719)) * 43758.5453;
    return value - Math.floor(value);
}

function clearCanvasView() {
    context.clearRect(0, 0, canvas.width, canvas.height);
}

function pointerDown(event) {
    if (!isDrawer) {
        return;
    }

    event.preventDefault();
    if (fillMode) {
        sendFill(getCanvasPoint(event));
        return;
    }

    currentStrokeId = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
    lastPoint = getCanvasPoint(event);
    sendStroke("dot", lastPoint, lastPoint);
}

function pointerMove(event) {
    if (!isDrawer || !lastPoint) {
        return;
    }

    event.preventDefault();
    const nextPoint = getCanvasPoint(event);
    sendStroke("line", lastPoint, nextPoint);
    lastPoint = nextPoint;
}

function pointerUp() {
    lastPoint = null;
    currentStrokeId = "";
}

function sendStroke(kind, from, to) {
    const payload = encodeBase64([
        kind,
        Math.round(from.x),
        Math.round(from.y),
        Math.round(to.x),
        Math.round(to.y),
        eraserMode ? "#ffffff" : colorInput.value,
        sizeInput.value,
        eraserMode ? "eraser" : currentBrush,
        currentStrokeId || `${Date.now()}`
    ].join("|"));

    ws.send(`DRAW::${payload}`);
    renderStroke(payload);
}

function sendFill(point) {
    const payload = encodeBase64(["bucket", Math.round(point.x), Math.round(point.y), colorInput.value, `${Date.now()}`].join("|"));
    ws.send(`DRAW::${payload}`);
    renderStroke(payload);
}

function floodFill(startX, startY, color) {
    const x0 = Math.max(0, Math.min(canvas.width - 1, Math.round(startX)));
    const y0 = Math.max(0, Math.min(canvas.height - 1, Math.round(startY)));
    const image = context.getImageData(0, 0, canvas.width, canvas.height);
    const data = image.data;
    const startIndex = ((y0 * canvas.width) + x0) * 4;
    const target = [data[startIndex], data[startIndex + 1], data[startIndex + 2], data[startIndex + 3]];
    const fill = hexToRgba(color);

    if (colorsMatch(target, fill)) {
        return;
    }

    const stack = [[x0, y0]];
    while (stack.length) {
        const point = stack.pop();
        const x = point[0];
        const y = point[1];
        if (x < 0 || y < 0 || x >= canvas.width || y >= canvas.height) {
            continue;
        }

        const index = ((y * canvas.width) + x) * 4;
        if (!colorsMatch([data[index], data[index + 1], data[index + 2], data[index + 3]], target)) {
            continue;
        }

        data[index] = fill[0];
        data[index + 1] = fill[1];
        data[index + 2] = fill[2];
        data[index + 3] = fill[3];
        stack.push([x + 1, y], [x - 1, y], [x, y + 1], [x, y - 1]);
    }

    context.putImageData(image, 0, 0);
}

function hexToRgba(hex) {
    const clean = hex.replace("#", "");
    return [
        parseInt(clean.slice(0, 2), 16),
        parseInt(clean.slice(2, 4), 16),
        parseInt(clean.slice(4, 6), 16),
        255
    ];
}

function colorsMatch(left, right) {
    return left[0] === right[0] && left[1] === right[1] && left[2] === right[2] && left[3] === right[3];
}

function updateFillButton() {
    const currentFillButton = document.getElementById("fill-btn");
    if (!currentFillButton) {
        return;
    }

    currentFillButton.textContent = fillMode ? "Fill On" : "Fill Off";
    currentFillButton.classList.toggle("active", fillMode);
}

function updateToolButtons() {
    document.querySelectorAll("[data-brush]").forEach((button) => {
        button.classList.toggle("active", button.dataset.brush === currentBrush && !eraserMode && !fillMode);
    });

    const eraserButton = document.getElementById("eraser-btn");
    if (eraserButton) {
        eraserButton.classList.toggle("active", eraserMode);
    }
}

function getCanvasPoint(event) {
    const rect = canvas.getBoundingClientRect();
    const source = event.touches ? event.touches[0] : event;
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;

    return {
        x: (source.clientX - rect.left) * scaleX,
        y: (source.clientY - rect.top) * scaleY
    };
}

function startTimer() {
    clearTimer();

    const tick = () => {
        updateWordPickerTimer();

        if (currentStatus === "picking") {
            const pickEndsAt = Number(wordPicker.dataset.endsAt || 0);
            const remainingPick = pickEndsAt ? Math.max(0, Math.ceil((pickEndsAt - Date.now()) / 1000)) : 0;
            timerInfo.textContent = remainingPick ? `${remainingPick}s` : "--";
            return;
        }

        if (!roundEndsAt || currentStatus !== "playing") {
            timerInfo.textContent = "--";
            return;
        }

        const remaining = Math.max(0, Math.floor((roundEndsAt - Date.now()) / 1000));
        const minutes = String(Math.floor(remaining / 60)).padStart(2, "0");
        const seconds = String(remaining % 60).padStart(2, "0");
        timerInfo.textContent = `${minutes}:${seconds}`;
    };

    tick();
    timerInterval = window.setInterval(tick, 1000);
}

function clearTimer() {
    if (timerInterval) {
        window.clearInterval(timerInterval);
        timerInterval = null;
    }
}

function syncCreateForm() {
    if (!createVisibility || !createPasswordWrap) {
        return;
    }

    const isPrivate = createVisibility.value === "PRIVATE";
    createPasswordWrap.classList.toggle("hidden", !isPrivate);
}

function readFieldValue(id, fallback) {
    const field = document.getElementById(id);
    return field ? field.value : fallback;
}

function ensureCreateSettingsFields() {
    const formGrid = document.querySelector(".create-card .form-grid");
    const maxField = document.getElementById("create-max");
    if (!formGrid || !maxField) {
        return;
    }

    if (!document.getElementById("create-rounds")) {
        maxField.closest(".field").insertAdjacentHTML("afterend", `
            <label class="field">
                <span>Rounds</span>
                <select id="create-rounds">
                    <option value="3">3 rounds</option>
                    <option value="5" selected>5 rounds</option>
                    <option value="8">8 rounds</option>
                    <option value="10">10 rounds</option>
                </select>
            </label>
        `);
    }

    if (!document.getElementById("create-time")) {
        document.getElementById("create-rounds").closest(".field").insertAdjacentHTML("afterend", `
            <label class="field">
                <span>Round time</span>
                <select id="create-time">
                    <option value="45">45 seconds</option>
                    <option value="60" selected>60 seconds</option>
                    <option value="90">90 seconds</option>
                    <option value="120">120 seconds</option>
                </select>
            </label>
        `);
    }

    const toolStrip = document.querySelector(".tool-strip");
    const clearButton = toolStrip ? Array.from(toolStrip.querySelectorAll("button")).find((button) => button.textContent.trim() === "Clear Canvas") : null;
    if (toolStrip && clearButton && !document.getElementById("fill-btn")) {
        clearButton.insertAdjacentHTML("beforebegin", `<button id="fill-btn" type="button" class="action-btn neutral-btn compact-btn fill-btn" onclick="toggleFillMode()">Fill Off</button>`);
    }
}

function resizeGuessInput() {
    guessInput.style.height = "auto";
    guessInput.style.height = `${Math.min(guessInput.scrollHeight, 160)}px`;
}

function decodeBase64(value) {
    if (!value) {
        return "";
    }

    const binary = window.atob(value);
    let encoded = "";

    for (let i = 0; i < binary.length; i += 1) {
        encoded += `%${(`00${binary.charCodeAt(i).toString(16)}`).slice(-2)}`;
    }

    try {
        return decodeURIComponent(encoded);
    } catch (error) {
        return binary;
    }
}

function encodeBase64(value) {
    return window.btoa(unescape(encodeURIComponent(value)));
}

function escapeHtml(value) {
    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");
}
